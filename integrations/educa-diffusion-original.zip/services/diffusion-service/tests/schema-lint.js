'use strict';
/**
 * Analyseur du schéma PostgreSQL.
 *
 * Rejoue les migrations dans l'ordre — sans serveur — pour construire l'état
 * final des tables, puis vérifie les règles que le projet s'est données :
 * frontières de service, cloisonnement, intégrité référentielle, index sur
 * les clés étrangères, contraintes de cycle.
 *
 *   node tests/schema-lint.js
 */
const fs = require('fs');
const path = require('path');

const DOSSIER = path.join(__dirname, '..', 'migrations');

/* --- Domaines appartenant à d'autres services de l'écosystème ------------- */
const DOMAINES_EXTERNES = ['utilisateurs', 'etablissements', 'classes'];

/* --- Tables portant du travail de classe : cloisonnement obligatoire ------ */
const TABLES_CLOISONNEES = [
  'travaux', 'quiz', 'assignations', 'remises', 'groupes', 'annonces', 'abonnements',
];

const CYCLES = ['maternelle', 'primaire', 'secondaire'];

/* --- Découpage en instructions, en respectant les corps $$ … $$ ----------- */
function instructions(sql) {
  const out = [];
  let courant = '';
  let dansCorps = false;
  for (const ligne of sql.split('\n')) {
    // Les commentaires sont retirés hors des corps $$ … $$ : une instruction
    // précédée d'un bandeau de commentaires doit commencer par son mot-clé.
    const sansCommentaire = dansCorps ? ligne : ligne.replace(/--.*$/, '');
    const marques = (sansCommentaire.match(/\$\$/g) || []).length;
    courant += sansCommentaire + '\n';
    if (marques % 2 === 1) dansCorps = !dansCorps;
    if (!dansCorps && /;\s*$/.test(sansCommentaire)) {
      out.push(courant.trim());
      courant = '';
    }
  }
  if (courant.trim()) out.push(courant.trim());
  return out;
}

/* --- Reconstruction de l'état du schéma ----------------------------------- */
const tables = new Map();   // nom → { colonnes:Set, pk:bool, fichier }
const vues = new Set();
const fks = [];             // { table, colonne, cible, cibleColonne, fichier }
const index = [];           // { table, colonnes:[], fichier }
const checks = [];          // { table, texte, fichier }
const problemes = [];

const signale = (regle, message) => problemes.push({ regle, message });

/** Découpe une liste de colonnes en respectant les parenthèses imbriquées. */
function decouperColonnes(texte) {
  const out = [];
  let profondeur = 0;
  let morceau = '';
  for (const c of texte) {
    if (c === '(') profondeur++;
    if (c === ')') profondeur--;
    if (c === ',' && profondeur === 0) { out.push(morceau); morceau = ''; continue; }
    morceau += c;
  }
  if (morceau.trim()) out.push(morceau);
  return out.map((c) => c.trim().toLowerCase().replace(/\s+(asc|desc)$/i, ''));
}

function colonnesDuCorps(corps) {
  const colonnes = new Set();
  let pk = false;
  let profondeur = 0;
  let morceau = '';
  const morceaux = [];
  for (const c of corps) {
    if (c === '(') profondeur++;
    if (c === ')') profondeur--;
    if (c === ',' && profondeur === 0) { morceaux.push(morceau); morceau = ''; continue; }
    morceau += c;
  }
  if (morceau.trim()) morceaux.push(morceau);

  for (const m of morceaux) {
    const t = m.trim();
    if (/^(PRIMARY\s+KEY|UNIQUE|CHECK|CONSTRAINT|FOREIGN\s+KEY)/i.test(t)) {
      if (/^PRIMARY\s+KEY/i.test(t)) pk = true;
      if (/^CONSTRAINT\s+\S+\s+PRIMARY\s+KEY/i.test(t)) pk = true;
      continue;
    }
    const nom = /^([a-z_][a-z0-9_]*)\s/i.exec(t);
    if (nom) {
      colonnes.add(nom[1].toLowerCase());
      if (/PRIMARY\s+KEY/i.test(t)) pk = true;
    }
  }
  return { colonnes, pk, morceaux };
}

const fichiers = fs.readdirSync(DOSSIER).filter((f) => f.endsWith('.sql')).sort();

for (const fichier of fichiers) {
  const sql = fs.readFileSync(path.join(DOSSIER, fichier), 'utf8');

  const ouvertures = (sql.match(/^\s*BEGIN\s*;/gmi) || []).length;
  const fermetures = (sql.match(/^\s*COMMIT\s*;/gmi) || []).length;
  if (ouvertures !== fermetures) {
    signale('transaction', `${fichier} : ${ouvertures} BEGIN pour ${fermetures} COMMIT`);
  }

  for (const inst of instructions(sql)) {
    const plat = inst.replace(/\s+/g, ' ');

    let m = /^CREATE TABLE (?:IF NOT EXISTS )?([a-z_]+)\s*\(([\s\S]*)\)\s*;?$/i.exec(inst);
    if (m) {
      const nom = m[1].toLowerCase();
      if (tables.has(nom)) signale('doublon', `table ${nom} définie deux fois (${fichier})`);
      const { colonnes, pk, morceaux } = colonnesDuCorps(m[2]);
      tables.set(nom, { colonnes, pk, fichier });
      for (const morceau of morceaux) {
        const ref = /REFERENCES\s+([a-z_]+)\s*\(\s*([a-z_]+)\s*\)/i.exec(morceau);
        if (ref) {
          const colonne = (/^([a-z_][a-z0-9_]*)\s/i.exec(morceau.trim()) || [])[1];
          fks.push({ table: nom, colonne: (colonne || '?').toLowerCase(),
                     cible: ref[1].toLowerCase(), cibleColonne: ref[2].toLowerCase(), fichier });
        }
        if (/^(CONSTRAINT\s+\S+\s+)?CHECK/i.test(morceau.trim())) {
          checks.push({ table: nom, texte: morceau, fichier });
        }
      }
      continue;
    }

    m = /^ALTER TABLE ([a-z_]+)\s+RENAME TO ([a-z_]+)/i.exec(plat);
    if (m) {
      const [, avant, apres] = m.map((x) => x.toLowerCase());
      const t = tables.get(avant);
      if (!t) signale('renommage', `ALTER TABLE ${avant} RENAME : table inconnue (${fichier})`);
      else { tables.delete(avant); tables.set(apres, t); }
      for (const fk of fks) { if (fk.table === avant) fk.table = apres; if (fk.cible === avant) fk.cible = apres; }
      for (const i of index) if (i.table === avant) i.table = apres;
      for (const c of checks) if (c.table === avant) c.table = apres;
      continue;
    }

    m = /^ALTER TABLE ([a-z_]+)\s+ADD COLUMN([\s\S]*)$/i.exec(inst);
    if (m) {
      const nom = m[1].toLowerCase();
      const t = tables.get(nom);
      if (!t) { signale('table', `ALTER TABLE ${nom} : table inconnue (${fichier})`); continue; }
      for (const ajout of m[2].split(/,\s*\n/)) {
        const c = /(?:ADD COLUMN\s+)?(?:IF NOT EXISTS\s+)?([a-z_][a-z0-9_]*)\s/i.exec(ajout.trim());
        if (c) t.colonnes.add(c[1].toLowerCase());
        const ref = /REFERENCES\s+([a-z_]+)\s*\(\s*([a-z_]+)\s*\)/i.exec(ajout);
        if (ref && c) fks.push({ table: nom, colonne: c[1].toLowerCase(),
                                 cible: ref[1].toLowerCase(), cibleColonne: ref[2].toLowerCase(), fichier });
      }
      continue;
    }

    m = /^ALTER TABLE ([a-z_]+) ADD (?:CONSTRAINT \S+ )?CHECK ([\s\S]*)$/i.exec(plat);
    if (m) { checks.push({ table: m[1].toLowerCase(), texte: m[2], fichier }); continue; }

    m = /^DROP TABLE (?:IF EXISTS )?([a-z_, ]+?)(?: CASCADE)?\s*;/i.exec(plat);
    if (m) {
      for (const nom of m[1].split(',').map((x) => x.trim().toLowerCase())) {
        tables.delete(nom);
        // CASCADE emporte les contraintes des autres tables qui la référencent.
        for (let i = fks.length - 1; i >= 0; i--) {
          if (fks[i].table === nom || fks[i].cible === nom) fks.splice(i, 1);
        }
        // Les index et les contraintes de la table disparaissent avec elle.
        for (let i = index.length - 1; i >= 0; i--) if (index[i].table === nom) index.splice(i, 1);
        for (let i = checks.length - 1; i >= 0; i--) if (checks[i].table === nom) checks.splice(i, 1);
      }
      continue;
    }

    m = /^CREATE (?:OR REPLACE )?VIEW ([a-z_]+)/i.exec(plat);
    if (m) { vues.add(m[1].toLowerCase()); continue; }

    m = /^CREATE INDEX (?:IF NOT EXISTS )?\S+ ON ([a-z_]+)\s*\((.*)\)\s*;?$/i.exec(plat);
    if (m) {
      index.push({
        table: m[1].toLowerCase(),
        colonnes: decouperColonnes(m[2]),
        fichier,
      });
      continue;
    }
  }
}

/* --- Règles ---------------------------------------------------------------- */

// 1. Toute clé étrangère vise une table existante et une colonne existante.
for (const fk of fks) {
  const cible = tables.get(fk.cible);
  if (!cible) {
    signale('reference', `${fk.table}.${fk.colonne} référence ${fk.cible}, table absente du schéma final (${fk.fichier})`);
    continue;
  }
  if (!cible.colonnes.has(fk.cibleColonne)) {
    signale('reference', `${fk.table}.${fk.colonne} référence ${fk.cible}.${fk.cibleColonne}, colonne inconnue`);
  }
}

// 2. Aucune clé étrangère vers un domaine d'un autre service.
for (const fk of fks) {
  if (DOMAINES_EXTERNES.includes(fk.cible)) {
    signale('frontiere', `${fk.table}.${fk.colonne} référence ${fk.cible} : domaine d'un autre service`);
  }
}
for (const nom of DOMAINES_EXTERNES) {
  if (tables.has(nom)) signale('frontiere', `la table ${nom} ne doit pas exister dans ce service`);
}

// 3. Chaque table a une clé primaire.
for (const [nom, t] of tables) {
  if (!t.pk) signale('cle', `la table ${nom} n'a pas de clé primaire (${t.fichier})`);
}

// 4. Les tables de travail de classe portent ecole_id.
for (const nom of TABLES_CLOISONNEES) {
  const t = tables.get(nom);
  if (!t) { signale('cloisonnement', `table cloisonnée attendue mais absente : ${nom}`); continue; }
  if (!t.colonnes.has('ecole_id')) signale('cloisonnement', `${nom} ne porte pas ecole_id`);
}

// 5. Toute clé étrangère est indexée (sauf si elle ouvre la clé primaire).
const aUnIndex = (table, colonne) =>
  index.some((i) => i.table === table && i.colonnes[0] === colonne) ||
  fks.some(() => false);
for (const fk of fks) {
  if (!tables.has(fk.table)) continue;
  const pkEnTete = new RegExp(`PRIMARY KEY\\s*\\(\\s*${fk.colonne}\\b`, 'i');
  const corpsPk = pkEnTete.test(fs.readFileSync(path.join(DOSSIER, fk.fichier), 'utf8'));
  if (!aUnIndex(fk.table, fk.colonne) && !corpsPk) {
    signale('index', `${fk.table}.${fk.colonne} est une clé étrangère sans index`);
  }
}

// 6. Les index portent sur des colonnes existantes.
for (const i of index) {
  const t = tables.get(i.table);
  if (!t) { signale('index', `index sur ${i.table}, table inconnue (${i.fichier})`); continue; }
  for (const c of i.colonnes) {
    const nom = /^[a-z_]+\(([a-z_]+)\)$/.exec(c);          // index d'expression
    const colonne = nom ? nom[1] : c;
    if (!t.colonnes.has(colonne)) {
      signale('index', `index sur ${i.table}(${colonne}) : colonne inconnue (${i.fichier})`);
    }
  }
}

// 7. Toute colonne « cycle » est contrainte aux trois cycles de l'écosystème.
for (const [nom, t] of tables) {
  if (!t.colonnes.has('cycle')) continue;
  const contrainte = checks.find((c) => c.table === nom && /cycle/i.test(c.texte));
  if (!contrainte) { signale('cycle', `${nom}.cycle sans contrainte de valeurs`); continue; }
  for (const cycle of CYCLES) {
    if (!contrainte.texte.includes(cycle)) signale('cycle', `${nom}.cycle : « ${cycle} » absent de la contrainte`);
  }
}

// 8. Toute colonne « visibilite » impose une école dès qu'elle n'est pas commune.
for (const [nom, t] of tables) {
  if (!t.colonnes.has('visibilite')) continue;
  const garde = checks.find((c) => c.table === nom && /visibilite\s*=\s*'commun'\s*OR/i.test(c.texte));
  if (!garde) signale('cloisonnement', `${nom} a une visibilité sans garde « commun OR ecole_id IS NOT NULL »`);
}

/* --- Rapport ---------------------------------------------------------------- */
console.log(`Schéma reconstruit depuis ${fichiers.length} migrations :`);
console.log(`  ${tables.size} tables · ${vues.size} vues · ${fks.length} clés étrangères · ${index.length} index\n`);

const parRegle = problemes.reduce((acc, p) => {
  (acc[p.regle] = acc[p.regle] || []).push(p.message);
  return acc;
}, {});

const REGLES = {
  transaction: 'Transactions équilibrées',
  doublon: 'Aucune table définie deux fois',
  table: 'Tables visées par ALTER existantes',
  renommage: 'Renommages cohérents',
  reference: 'Clés étrangères valides',
  frontiere: 'Frontières de service respectées',
  cle: 'Clé primaire sur chaque table',
  cloisonnement: 'Cloisonnement multi-école',
  index: 'Index sur les clés étrangères',
  cycle: 'Contrainte de cycle complète',
};

let echecs = 0;
for (const [regle, libelle] of Object.entries(REGLES)) {
  const liste = parRegle[regle];
  if (!liste) { console.log(`  ok   ${libelle}`); continue; }
  echecs += liste.length;
  console.log(` ÉCHEC ${libelle}`);
  for (const m of liste) console.log(`         · ${m}`);
}

console.log(echecs ? `\n${echecs} anomalie(s)` : '\nTous les contrôles passent');
process.exit(echecs ? 1 : 0);
