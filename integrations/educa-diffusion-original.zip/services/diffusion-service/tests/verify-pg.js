'use strict';
/**
 * Contrôles du client PostgreSQL — à relancer après toute modification de lib/pg.
 *   node tools/verify-pg.js
 *
 * 1. SCRAM-SHA-256 confronté au vecteur de test de la RFC 7677.
 * 2. Authentification md5 : forme du condensé.
 * 3. Encodage et découpage des messages du protocole.
 * 4. Conversion des types au format texte.
 * 5. Bout en bout contre un serveur factice : authentification, requête simple,
 *    requête préparée avec paramètres, erreur serveur, transaction, réserve.
 */
const assert = require('assert');
const pg = require('../src/utils/pg');
const { client, decouper } = require('../src/utils/pg/protocol');
const scram = require('../src/utils/pg/scram');
const types = require('../src/utils/pg/types');
const mock = require('./mock-pg');

let echecs = 0;
const verifie = (nom, fn) => {
  try { fn(); console.log(`  ok   ${nom}`); }
  catch (e) { console.log(` ÉCHEC ${nom} — ${e.message}`); echecs++; }
};
const verifieAsync = async (nom, fn) => {
  try { await fn(); console.log(`  ok   ${nom}`); }
  catch (e) { console.log(` ÉCHEC ${nom} — ${e.message}`); echecs++; }
};

/* 1. SCRAM contre la RFC 7677 --------------------------------------------- */
const VECTEUR = {
  motDePasse: 'pencil',
  utilisateur: 'user',
  nonceClient: 'rOprNGfwEbeRWgbNEkqO',
  serveurPremier: 'r=rOprNGfwEbeRWgbNEkqO%hvYDpWUa2RaTCAfuxFIlj)hNlF$k0,s=W22ZaJ0SNY7soEsUEjb6gQ==,i=4096',
  clientFinal: 'c=biws,r=rOprNGfwEbeRWgbNEkqO%hvYDpWUa2RaTCAfuxFIlj)hNlF$k0,p=dHzbZapWIk4jUhN+Ute9ytag9zjfMHgsqmmiz7AndVQ=',
  signatureServeur: '6rriTRBi23WpRR/wtup+mMhUZUn/dB5nLTJRsjl95G4=',
};

verifie('SCRAM : premier message client', () => {
  const e = scram.echange(VECTEUR.motDePasse, { utilisateur: VECTEUR.utilisateur, nonceClient: VECTEUR.nonceClient });
  assert.strictEqual(e.premierMessage().toString(), 'n,,n=user,r=rOprNGfwEbeRWgbNEkqO');
});
verifie('SCRAM : preuve client conforme à la RFC 7677', () => {
  const e = scram.echange(VECTEUR.motDePasse, { utilisateur: VECTEUR.utilisateur, nonceClient: VECTEUR.nonceClient });
  const r = e.reponse(VECTEUR.serveurPremier);
  assert.strictEqual(r.message.toString(), VECTEUR.clientFinal);
});
verifie('SCRAM : signature serveur conforme à la RFC 7677', () => {
  const e = scram.echange(VECTEUR.motDePasse, { utilisateur: VECTEUR.utilisateur, nonceClient: VECTEUR.nonceClient });
  const r = e.reponse(VECTEUR.serveurPremier);
  assert.strictEqual(r.signatureServeurAttendue, VECTEUR.signatureServeur);
  assert.strictEqual(e.verifier(`v=${VECTEUR.signatureServeur}`, r.signatureServeurAttendue), true);
});
verifie('SCRAM : nonce serveur falsifié rejeté', () => {
  const e = scram.echange('pencil', { nonceClient: 'abc' });
  assert.throws(() => e.reponse('r=zzz,s=W22ZaJ0SNY7soEsUEjb6gQ==,i=4096'), /nonce/);
});
verifie('SCRAM : signature serveur invalide rejetée', () => {
  const e = scram.echange('pencil', { nonceClient: 'abc' });
  assert.throws(() => e.verifier('v=faux', 'attendu'), /signature/);
});

/* 2. md5 ------------------------------------------------------------------- */
verifie('md5 : forme du condensé', () => {
  const d = scram.md5('educa', 'secret', Buffer.from([1, 2, 3, 4]));
  assert.ok(/^md5[0-9a-f]{32}$/.test(d), d);
});

/* 3. Protocole ------------------------------------------------------------- */
verifie('Protocole : longueur déclarée d’un message Query', () => {
  const m = client.requete('SELECT 1');
  assert.strictEqual(String.fromCharCode(m[0]), 'Q');
  assert.strictEqual(m.readInt32BE(1), m.length - 1);
});
verifie('Protocole : message de démarrage sans octet de type', () => {
  const m = client.demarrage({ user: 'educa', database: 'diffusion' });
  assert.strictEqual(m.readInt32BE(0), m.length);
  assert.strictEqual(m.readInt32BE(4), 196608);
  assert.ok(m.includes(Buffer.from('diffusion')));
});
verifie('Protocole : découpage d’un flux en trois messages', () => {
  const flux = Buffer.concat([client.requete('SELECT 1'), client.synchroniser(), client.terminer()]);
  // on rejoue côté « serveur » : les types Q, S et X ne sont pas décodés, mais le cadrage l’est
  const { messages, reliquat } = decouper(flux);
  assert.strictEqual(messages.length, 3);
  assert.strictEqual(reliquat.length, 0);
});
verifie('Protocole : message incomplet conservé en reliquat', () => {
  const complet = client.requete('SELECT 1');
  const { messages, reliquat } = decouper(complet.subarray(0, complet.length - 3));
  assert.strictEqual(messages.length, 0);
  assert.strictEqual(reliquat.length, complet.length - 3);
});

/* 4. Types ----------------------------------------------------------------- */
verifie('Types : booléen, entiers, flottant', () => {
  assert.strictEqual(types.decoder('t', 16), true);
  assert.strictEqual(types.decoder('f', 16), false);
  assert.strictEqual(types.decoder('42', 23), 42);
  assert.strictEqual(types.decoder('3.5', 701), 3.5);
});
verifie('Types : entier 64 bits au-delà de la précision sûre', () => {
  assert.strictEqual(types.decoder('9007199254740993', 20), 9007199254740993n);
  assert.strictEqual(types.decoder('42', 20), 42);
});
verifie('Types : numeric rendu en chaîne, sans perte', () => {
  assert.strictEqual(types.decoder('1234.50', 1700), '1234.50');
});
verifie('Types : jsonb analysé', () => {
  assert.deepStrictEqual(types.decoder('{"a":[1,2]}', 3802), { a: [1, 2] });
});
verifie('Types : tableau avec virgule échappée et NULL', () => {
  assert.deepStrictEqual(types.decoder('{x,"y,z",NULL}', 1009), ['x', 'y,z', null]);
});
verifie('Types : horodatage converti en Date', () => {
  const d = types.decoder('2026-08-14 13:55:20+00', 1184);
  assert.ok(d instanceof Date);
  assert.strictEqual(d.toISOString(), '2026-08-14T13:55:20.000Z');
});
verifie('Types : encodage des paramètres', () => {
  assert.strictEqual(types.encoder(true), 't');
  assert.strictEqual(types.encoder(null), null);
  assert.strictEqual(types.encoder({ a: 1 }), '{"a":1}');
  assert.strictEqual(types.encoder(Buffer.from([255])), '\\xff');
});

/* 5. Bout en bout ---------------------------------------------------------- */
(async () => {
  const serveur = await mock.demarrer({ utilisateur: 'educa', motDePasse: 'secret' });
  const config = {
    hote: '127.0.0.1', port: serveur.port,
    utilisateur: 'educa', motDePasse: 'secret', base: 'diffusion',
  };

  await verifieAsync('Bout en bout : connexion et authentification SCRAM', async () => {
    const c = pg.connexion(config);
    await c.connecter();
    assert.strictEqual(c.etat, 'prete');
    assert.ok(c.parametres.server_version);
    c.fermer();
  });

  await verifieAsync('Bout en bout : requête simple', async () => {
    const c = pg.connexion(config);
    const r = await c.requete('SELECT 1');
    assert.strictEqual(r.lignes.length, 1);
    assert.strictEqual(r.lignes[0]['?column?'], 1);
    c.fermer();
  });

  await verifieAsync('Bout en bout : requête préparée, paramètres transmis', async () => {
    const c = pg.connexion(config);
    const r = await c.requete('SELECT renvoie_params WHERE a = $1 AND b = $2', ['Secondaire 2', 7]);
    assert.deepStrictEqual(r.lignes.map((l) => l.recu), ['Secondaire 2', '7']);
    assert.deepStrictEqual(r.lignes.map((l) => l.nombre), [1, 2]);
    c.fermer();
  });

  await verifieAsync('Bout en bout : paramètre nul transmis', async () => {
    const c = pg.connexion(config);
    const r = await c.requete('SELECT renvoie_params WHERE a = $1', [null]);
    assert.strictEqual(r.lignes[0].recu, null);
    c.fermer();
  });

  await verifieAsync('Bout en bout : conversion de tous les types', async () => {
    const c = pg.connexion(config);
    const { lignes: [l] } = await c.requete('SELECT types_varies');
    assert.strictEqual(l.b, true);
    assert.strictEqual(l.n, 42);
    assert.strictEqual(l.grand, 9007199254740993n);
    assert.strictEqual(l.exact, '1234.50');
    assert.deepStrictEqual(l.doc, { a: [1, 2] });
    assert.deepStrictEqual(l.liste, ['x', 'y,z', null]);
    assert.ok(l.quand instanceof Date);
    assert.strictEqual(l.vide, null);
    c.fermer();
  });

  await verifieAsync('Bout en bout : erreur serveur convertie en exception', async () => {
    const c = pg.connexion(config);
    await assert.rejects(
      () => c.requete('SELECT * FROM ERREUR_TEST WHERE a = $1', [1]),
      (e) => e.name === 'ErreurPg' && e.code === '42P01' && /n’existe pas/.test(e.message)
    );
    // la connexion reste utilisable après l’erreur
    const r = await c.requete('SELECT 1');
    assert.strictEqual(r.lignes.length, 1);
    c.fermer();
  });

  await verifieAsync('Bout en bout : requêtes enchaînées dans l’ordre', async () => {
    const c = pg.connexion(config);
    const resultats = await Promise.all([
      c.requete('SELECT renvoie_params', ['a']),
      c.requete('SELECT renvoie_params', ['b']),
      c.requete('SELECT renvoie_params', ['c']),
    ]);
    assert.deepStrictEqual(resultats.map((r) => r.lignes[0].recu), ['a', 'b', 'c']);
    c.fermer();
  });

  await verifieAsync('Bout en bout : transaction validée', async () => {
    const bd = pg.reserve(config, { taille: 2 });
    const valeur = await bd.transaction(async (c) => {
      const r = await c.requete('SELECT renvoie_params', ['dans la transaction']);
      return r.lignes[0].recu;
    });
    assert.strictEqual(valeur, 'dans la transaction');
    await bd.fermer();
  });

  await verifieAsync('Bout en bout : transaction annulée sur exception', async () => {
    const bd = pg.reserve(config, { taille: 2 });
    await assert.rejects(() => bd.transaction(async (c) => {
      await c.requete('SELECT renvoie_params', ['x']);
      throw new Error('échec métier');
    }), /échec métier/);
    const r = await bd.requete('SELECT 1');
    assert.strictEqual(r.lignes.length, 1);
    await bd.fermer();
  });

  await verifieAsync('Bout en bout : réserve limitée à deux connexions', async () => {
    const bd = pg.reserve(config, { taille: 2 });
    const r = await Promise.all(
      Array.from({ length: 6 }, (_, i) => bd.requete('SELECT renvoie_params', [`r${i}`]))
    );
    assert.deepStrictEqual(r.map((x) => x.lignes[0].recu), ['r0', 'r1', 'r2', 'r3', 'r4', 'r5']);
    assert.ok(bd.libres.length + bd.occupees.size <= 2);
    await bd.fermer();
  });

  await verifieAsync('Bout en bout : mot de passe erroné refusé', async () => {
    const c = pg.connexion({ ...config, motDePasse: 'mauvais' });
    await assert.rejects(() => c.connecter());
  });

  serveur.arreter();
  console.log(echecs ? `\n${echecs} contrôle(s) en échec` : '\nTous les contrôles passent');
  process.exit(echecs ? 1 : 0);
})();
