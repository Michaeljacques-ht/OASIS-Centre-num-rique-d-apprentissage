'use strict';
/**
 * Serveur PostgreSQL factice — juste assez de protocole pour valider le client
 * de bout en bout sans installer de serveur réel : authentification
 * SCRAM-SHA-256 complète, requêtes simples et préparées, erreurs, transactions.
 *
 *   const { demarrer } = require('./tools/mock-pg');
 *   const s = await demarrer({ utilisateur: 'educa', motDePasse: 'secret' });
 */
const net = require('net');
const crypto = require('crypto');
const { Writer, Reader, message } = require('../src/utils/pg/protocol');

const hmac = (cle, d) => crypto.createHmac('sha256', cle).update(d).digest();
const sha256 = (d) => crypto.createHash('sha256').update(d).digest();
const xor = (a, b) => Buffer.from(a.map((o, i) => o ^ b[i]));

/* --- Messages serveur ----------------------------------------------------- */
const S = {
  auth: (code, charge) => message('R', (w) => { w.int32(code); if (charge) w.brut(charge); }),
  parametre: (n, v) => message('S', (w) => w.chaine(n).chaine(v)),
  cle: () => message('K', (w) => w.int32(4242).int32(987654)),
  pret: (etat) => message('Z', (w) => w.octet(etat.charCodeAt(0))),
  description: (colonnes) => message('T', (w) => {
    w.int16(colonnes.length);
    for (const c of colonnes) {
      w.chaine(c.nom).int32(0).int16(0).int32(c.oid).int16(-1).int32(-1).int16(0);
    }
  }),
  ligne: (valeurs) => message('D', (w) => {
    w.int16(valeurs.length);
    for (const v of valeurs) {
      if (v === null) { w.int32(-1); continue; }
      const b = Buffer.from(String(v), 'utf8');
      w.int32(b.length).brut(b);
    }
  }),
  fini: (etiquette) => message('C', (w) => w.chaine(etiquette)),
  erreur: (champs) => message('E', (w) => {
    for (const [code, valeur] of Object.entries(champs)) w.octet(code.charCodeAt(0)).chaine(valeur);
    w.octet(0);
  }),
  analyseOk: () => message('1', () => {}),
  liaisonOk: () => message('2', () => {}),
};

/** Jeu de réponses : la requête détermine ce que le serveur renvoie. */
function repondre(sql, params) {
  if (/ERREUR_TEST/.test(sql)) {
    return { erreur: { S: 'ERROR', V: 'ERROR', C: '42P01', M: 'relation « inexistante » n’existe pas', P: '15' } };
  }
  if (/^\s*(BEGIN|COMMIT|ROLLBACK)/i.test(sql)) {
    return { colonnes: [], lignes: [], etiquette: sql.trim().toUpperCase().split(/\s/)[0] };
  }
  if (/renvoie_params/i.test(sql)) {
    return {
      colonnes: [{ nom: 'recu', oid: 25 }, { nom: 'nombre', oid: 23 }],
      lignes: params.map((p, i) => [p, String(i + 1)]),
      etiquette: `SELECT ${params.length}`,
    };
  }
  if (/types_varies/i.test(sql)) {
    return {
      colonnes: [
        { nom: 'b', oid: 16 }, { nom: 'n', oid: 23 }, { nom: 'grand', oid: 20 },
        { nom: 'exact', oid: 1700 }, { nom: 'doc', oid: 3802 },
        { nom: 'liste', oid: 1009 }, { nom: 'quand', oid: 1184 }, { nom: 'vide', oid: 25 },
      ],
      lignes: [['t', '42', '9007199254740993', '1234.50', '{"a":[1,2]}', '{x,"y,z",NULL}', '2026-08-14 13:55:20+00', null]],
      etiquette: 'SELECT 1',
    };
  }
  return { colonnes: [{ nom: '?column?', oid: 23 }], lignes: [['1']], etiquette: 'SELECT 1' };
}

function envoyerResultat(socket, sql, params, avecAnalyse, journal) {
  if (journal) journal.push({ sql, params });
  const r = repondre(sql, params);
  const sortie = [];
  if (avecAnalyse) sortie.push(S.analyseOk(), S.liaisonOk());
  if (r.erreur) {
    sortie.push(S.erreur(r.erreur), S.pret('I'));
  } else {
    if (r.colonnes.length) sortie.push(S.description(r.colonnes));
    for (const l of r.lignes) sortie.push(S.ligne(l));
    sortie.push(S.fini(r.etiquette), S.pret('I'));
  }
  socket.write(Buffer.concat(sortie));
}

/* --- Serveur -------------------------------------------------------------- */
function demarrer(options = {}) {
  const journal = [];                      // requêtes reçues, pour les contrôles
  const utilisateur = options.utilisateur || 'educa';
  const motDePasse = options.motDePasse || 'secret';
  const sel = crypto.randomBytes(16);
  const iterations = 4096;

  const serveur = net.createServer((socket) => {
    let tampon = Buffer.alloc(0);
    let phase = 'demarrage';
    let scram = {};
    let sqlPrepare = '';
    let paramsLies = [];

    socket.on('data', (morceau) => {
      tampon = Buffer.concat([tampon, morceau]);

      // Message de démarrage : pas d'octet de type
      if (phase === 'demarrage') {
        if (tampon.length < 8) return;
        const longueur = tampon.readInt32BE(0);
        if (tampon.length < longueur) return;
        const code = tampon.readInt32BE(4);
        if (code === 80877103) {            // demande TLS : refusée par le factice
          socket.write(Buffer.from('N'));
          tampon = tampon.subarray(8);
          return;
        }
        tampon = tampon.subarray(longueur);
        phase = 'sasl';
        socket.write(message('R', (w) => { w.int32(10); w.chaine('SCRAM-SHA-256'); w.octet(0); }));
        return;
      }

      // Messages typés
      while (tampon.length >= 5) {
        const type = String.fromCharCode(tampon.readUInt8(0));
        const longueur = tampon.readInt32BE(1);
        if (tampon.length < longueur + 1) return;
        const corps = tampon.subarray(5, longueur + 1);
        tampon = tampon.subarray(longueur + 1);
        const r = new Reader(corps);

        if (phase === 'sasl' && type === 'p') {
          r.chaine();                       // nom du mécanisme
          const taille = r.int32();
          const donnees = r.brut(taille).toString('utf8');
          scram.clientPremierNu = donnees.replace(/^n,,/, '');
          const nonceClient = /r=([^,]+)/.exec(scram.clientPremierNu)[1];
          scram.nonce = nonceClient + crypto.randomBytes(18).toString('base64').replace(/[,=]/g, '');
          scram.serveurPremier = `r=${scram.nonce},s=${sel.toString('base64')},i=${iterations}`;
          phase = 'saslSuite';
          socket.write(S.auth(11, Buffer.from(scram.serveurPremier, 'utf8')));
          continue;
        }

        if (phase === 'saslSuite' && type === 'p') {
          const clientFinal = corps.toString('utf8');
          const sansPreuve = clientFinal.replace(/,p=.*$/, '');
          const preuve = Buffer.from(/p=(.+)$/.exec(clientFinal)[1], 'base64');

          const sale = crypto.pbkdf2Sync(Buffer.from(motDePasse, 'utf8'), sel, iterations, 32, 'sha256');
          const cleStockee = sha256(hmac(sale, 'Client Key'));
          const messageAuth = `${scram.clientPremierNu},${scram.serveurPremier},${sansPreuve}`;
          const signatureClient = hmac(cleStockee, messageAuth);
          const cleClientRetrouvee = xor(preuve, signatureClient);

          if (!sha256(cleClientRetrouvee).equals(cleStockee)) {
            socket.write(Buffer.concat([
              S.erreur({ S: 'FATAL', C: '28P01', M: 'authentification par mot de passe échouée' }),
            ]));
            socket.end();
            return;
          }

          const signatureServeur = hmac(hmac(sale, 'Server Key'), messageAuth).toString('base64');
          phase = 'prete';
          socket.write(Buffer.concat([
            S.auth(12, Buffer.from(`v=${signatureServeur}`, 'utf8')),
            S.auth(0),
            S.parametre('server_version', '16.2 (factice)'),
            S.parametre('client_encoding', 'UTF8'),
            S.cle(),
            S.pret('I'),
          ]));
          continue;
        }

        if (type === 'Q') { envoyerResultat(socket, r.chaine(), [], false, journal); continue; }
        if (type === 'P') { r.chaine(); sqlPrepare = r.chaine(); continue; }
        if (type === 'B') {
          r.chaine(); r.chaine();
          const nbFormats = r.int16();
          for (let i = 0; i < nbFormats; i++) r.int16();
          const nb = r.int16();
          paramsLies = [];
          for (let i = 0; i < nb; i++) {
            const taille = r.int32();
            paramsLies.push(taille === -1 ? null : r.brut(taille).toString('utf8'));
          }
          continue;
        }
        if (type === 'D' || type === 'E') continue;    // Describe et Execute : traités au Sync
        if (type === 'S') { envoyerResultat(socket, sqlPrepare, paramsLies, true, journal); continue; }
        if (type === 'X') { socket.end(); return; }
      }
    });

    socket.on('error', () => { /* client parti */ });
  });

  return new Promise((resoudre) => {
    serveur.listen(0, '127.0.0.1', () => {
      const { port } = serveur.address();
      resoudre({ port, utilisateur, motDePasse, journal, arreter: () => serveur.close() });
    });
  });
}

module.exports = { demarrer };
