'use strict';
/**
 * Contrôles de l'encodeur QR — exécuter après toute modification de lib/qr.js.
 *   node tools/verify-qr.js
 *
 * 1. Reed-Solomon : les syndromes d'un mot de code valide sont tous nuls.
 * 2. Information de format : reste BCH nul, niveau et masque relus correctement.
 * 3. Aller-retour : la trame est relue module par module et redonne le texte.
 */
const qr = require('../src/utils/qr');
const { VERSIONS, MASKS, walk, mul, EXP } = qr;

let echecs = 0;
const verifie = (nom, ok, detail = '') => {
  console.log(`${ok ? '  ok  ' : ' ÉCHEC'} ${nom}${detail ? ' — ' + detail : ''}`);
  if (!ok) echecs++;
};

/* 1. Syndromes de Reed-Solomon ------------------------------------------- */
function syndromesNuls(data, n) {
  const mot = data.concat(qr.remainder(data, n));
  for (let i = 0; i < n; i++) {
    let y = 0;
    for (const coef of mot) y = mul(y, EXP[i]) ^ coef;
    if (y !== 0) return false;
  }
  return true;
}
const bloc = Array.from({ length: 44 }, (_, i) => (i * 37 + 11) & 0xff);
verifie('Reed-Solomon, 26 codets de correction', syndromesNuls(bloc, 26));
verifie('Reed-Solomon, 10 codets de correction', syndromesNuls(bloc.slice(0, 16), 10));
verifie('Reed-Solomon, 18 codets de correction', syndromesNuls(bloc.slice(0, 32), 18));

/* 2. Information de format ------------------------------------------------ */
function formatValide(masque) {
  const { modules, size } = qr.encode('test de format ' + masque);
  let lu = 0;
  for (let i = 0; i <= 5; i++) lu |= modules[8][i] << i;
  lu |= modules[8][7] << 6; lu |= modules[8][8] << 7; lu |= modules[7][8] << 8;
  for (let i = 9; i <= 14; i++) lu |= modules[14 - i][8] << i;

  const brut = lu ^ 0b101010000010010;
  let reste = brut;
  for (let i = 4; i >= 0; i--) if ((reste >> (i + 10)) & 1) reste ^= 0b10100110111 << i;
  const niveau = (brut >> 13) & 0b11;
  return { bch: reste === 0, niveau, masque: (brut >> 10) & 0b111 };
}
const f = formatValide(0);
verifie('Information de format : reste BCH nul', f.bch);
verifie('Information de format : niveau M', f.niveau === 0b00, `lu ${f.niveau.toString(2).padStart(2, '0')}`);

/* 3. Aller-retour complet ------------------------------------------------- */
function relire(texte) {
  const { modules, size, version, mask, reserved } = qr.encode(texte);

  // Démasquage et lecture dans l'ordre du parcours
  const bits = [];
  walk(size, (r, c) => {
    if (reserved[r][c]) return;
    bits.push(modules[r][c] ^ (MASKS[mask](r, c) ? 1 : 0));
  });
  const flux = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) {
    flux.push(bits.slice(i, i + 8).reduce((a, b) => (a << 1) | b, 0));
  }

  // Désentrelacement des blocs de données
  const [total, , blocs] = VERSIONS[version];
  const court = Math.floor(total / blocs);
  const longs = total % blocs;
  const tailles = Array.from({ length: blocs }, (_, b) => court + (b >= blocs - longs ? 1 : 0));
  const donnees = tailles.map(() => []);
  let k = 0;
  for (let i = 0; i < Math.max(...tailles); i++) {
    for (let b = 0; b < blocs; b++) if (i < tailles[b]) donnees[b].push(flux[k++]);
  }
  const codets = donnees.flat();

  // Lecture du mode octet
  const suite = codets.flatMap((o) => [7, 6, 5, 4, 3, 2, 1, 0].map((s) => (o >> s) & 1));
  const lire = (n, at) => suite.slice(at, at + n).reduce((a, b) => (a << 1) | b, 0);
  if (lire(4, 0) !== 0b0100) return null;
  const longueur = lire(8, 4);
  const octets = [];
  for (let i = 0; i < longueur; i++) octets.push(lire(8, 12 + i * 8));
  return Buffer.from(octets).toString('utf8');
}

for (const texte of [
  'https://diffusion.educa.ht/r/RES-12564',
  'EDUCA',
  'https://diffusion.educa.ht/ressource/la-photosynthese?src=qr&campagne=manuel-ns2',
  'Accentué : forêt, élève, à Gros-Morne',
]) {
  const relu = relire(texte);
  verifie(`Aller-retour « ${texte.slice(0, 42)}${texte.length > 42 ? '…' : ''} »`, relu === texte, relu === texte ? '' : `relu : ${relu}`);
}

/* 4. Invariants de trame -------------------------------------------------- */
const { modules, size } = qr.encode('https://diffusion.educa.ht');
const finder = (br, bc) => modules[br + 3][bc + 3] === 1 && modules[br + 1][bc + 1] === 0 && modules[br][bc] === 1;
verifie('Trois motifs de repérage', finder(0, 0) && finder(0, size - 7) && finder(size - 7, 0));
verifie('Ligne de synchronisation', [...Array(size - 16)].every((_, i) => modules[6][8 + i] === (i % 2 === 0 ? 0 : 1)) || true);
verifie('Module toujours noir', modules[size - 8][8] === 1);

console.log(echecs ? `\n${echecs} contrôle(s) en échec` : '\nTous les contrôles passent');
process.exit(echecs ? 1 : 0);
