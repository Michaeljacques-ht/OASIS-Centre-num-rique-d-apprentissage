'use strict';
/**
 * Contrôles de cloisonnement et d'autorisation — exigence §8 et §15 du
 * contexte de développement EDUCA : une école ne doit jamais recevoir les
 * données d'une autre école, et le frontend n'est jamais source d'autorité.
 *
 *   node tests/tenant-isolation.js
 */
const assert = require('assert');
const http = require('http');
const crypto = require('crypto');

process.env.PORT = process.env.PORT || '0';
process.env.JWT_SECRET = 'secret-de-test';
process.env.NODE_ENV = 'test';

const { creerApplication } = require('../src/app');
const bd = require('../src/config/database');
const mock = require('./mock-pg');

let echecs = 0;
const verifie = async (nom, fn) => {
  try { await fn(); console.log(`  ok   ${nom}`); }
  catch (e) { console.log(` ÉCHEC ${nom} — ${e.message}`); echecs++; }
};

/* --- Outils ---------------------------------------------------------------- */
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64')
  .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

function jeton(charge, options = {}) {
  const enTete = b64({ alg: options.alg || 'HS256', typ: 'JWT' });
  const corps = b64({ exp: Math.floor(Date.now() / 1000) + 600, ...charge });
  if (options.alg === 'none') return `${enTete}.${corps}.`;
  const signature = crypto.createHmac('sha256', options.secret || process.env.JWT_SECRET)
    .update(`${enTete}.${corps}`).digest('base64')
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  return `${enTete}.${corps}.${signature}`;
}

const ECOLE_A = { sub: 'usr_a', role: 'enseignant', school_id: 'eco_A', academic_year_id: 'an_2026' };
const ECOLE_B = { sub: 'usr_b', role: 'enseignant', school_id: 'eco_B', academic_year_id: 'an_2026' };

let serveur; let base;
const appel = (chemin, options = {}) => new Promise((resoudre, rejeter) => {
  const req = http.request(`${base}${chemin}`, {
    method: options.methode || 'GET',
    headers: {
      ...(options.jeton ? { authorization: `Bearer ${options.jeton}` } : {}),
      ...(options.corps ? { 'content-type': 'application/json' } : {}),
      ...(options.entetes || {}),
    },
  }, (res) => {
    let texte = '';
    res.on('data', (d) => { texte += d; });
    res.on('end', () => {
      let charge = null;
      try { charge = JSON.parse(texte); } catch { charge = texte; }
      resoudre({ statut: res.statusCode, charge });
    });
  });
  req.on('error', rejeter);
  if (options.corps) req.write(JSON.stringify(options.corps));
  req.end();
});

(async () => {
  serveur = http.createServer(creerApplication());
  await new Promise((r) => serveur.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${serveur.address().port}/api/v1`;
  process.env.JOURNAL_HTTP = '0';

  /* --- Authentification --------------------------------------------------- */
  await verifie('Requête sans jeton refusée', async () => {
    const r = await appel('/ressources');
    assert.strictEqual(r.statut, 401);
    assert.strictEqual(r.charge.erreur.code, 'NON_AUTHENTIFIE');
  });

  await verifie('Jeton « alg: none » refusé', async () => {
    const r = await appel('/ressources', { jeton: jeton(ECOLE_A, { alg: 'none' }) });
    assert.strictEqual(r.statut, 401);
    assert.strictEqual(r.charge.erreur.code, 'ALGORITHME_REFUSE');
  });

  await verifie('Jeton signé avec un autre secret refusé', async () => {
    const r = await appel('/ressources', { jeton: jeton(ECOLE_A, { secret: 'mauvais-secret' }) });
    assert.strictEqual(r.statut, 401);
    assert.strictEqual(r.charge.erreur.code, 'SIGNATURE_INVALIDE');
  });

  await verifie('Jeton expiré refusé', async () => {
    const r = await appel('/ressources', { jeton: jeton({ ...ECOLE_A, exp: 1000 }) });
    assert.strictEqual(r.statut, 401);
    assert.strictEqual(r.charge.erreur.code, 'JETON_EXPIRE');
  });

  await verifie('Jeton valide accepté', async () => {
    const r = await appel('/ressources', { jeton: jeton(ECOLE_A) });
    assert.strictEqual(r.statut, 200);
    assert.ok(Array.isArray(r.charge.donnees));
  });

  /* --- Cloisonnement ------------------------------------------------------ */
  await verifie('Identifiant d’école fourni par le client refusé', async () => {
    const r = await appel('/travaux-diriges?school_id=eco_B', { jeton: jeton(ECOLE_A) });
    assert.strictEqual(r.statut, 403);
    assert.strictEqual(r.charge.erreur.code, 'TENANT_REFUSE');
  });

  await verifie('Jeton sans école refusé sur le travail de classe', async () => {
    const r = await appel('/travaux-diriges', { jeton: jeton({ sub: 'usr_x', role: 'enseignant' }) });
    assert.strictEqual(r.statut, 403);
    assert.strictEqual(r.charge.erreur.code, 'ECOLE_ABSENTE');
  });

  await verifie('Jeton sans école accepté sur le fonds commun', async () => {
    const r = await appel('/ressources', { jeton: jeton({ sub: 'usr_x', role: 'moderateur' }) });
    assert.strictEqual(r.statut, 200);
  });

  /* --- Rôles -------------------------------------------------------------- */
  await verifie('Un élève ne peut pas créer un travail dirigé', async () => {
    const r = await appel('/travaux-diriges', {
      methode: 'POST', jeton: jeton({ ...ECOLE_A, role: 'eleve' }),
      corps: { titre: 'Test', discipline: 'Mathématiques', niveau: 'Secondaire 3', cycle: 'secondaire' },
    });
    assert.strictEqual(r.statut, 403);
    assert.strictEqual(r.charge.erreur.code, 'ROLE_INSUFFISANT');
  });

  await verifie('Création refusée si les données sont invalides', async () => {
    const r = await appel('/travaux-diriges', {
      methode: 'POST', jeton: jeton(ECOLE_A),
      corps: { titre: '', discipline: 'Maths', niveau: 'Zorglub', cycle: 'lunaire' },
    });
    assert.strictEqual(r.statut, 422);
    assert.strictEqual(r.charge.erreur.code, 'VALIDATION');
    assert.ok(r.charge.erreur.details.titre && r.charge.erreur.details.cycle);
  });

  /* --- Accès public ------------------------------------------------------- */
  await verifie('Une ressource scannée s’ouvre sans compte', async () => {
    const r = await appel('/public/r/rp-001');
    assert.strictEqual(r.statut, 200);
    assert.strictEqual(r.charge.donnees.id, 'rp-001');
  });

  await verifie('Adresse courte inconnue : 404 explicite', async () => {
    const r = await appel('/public/r/inexistante');
    assert.strictEqual(r.statut, 404);
    assert.strictEqual(r.charge.erreur.code, 'LIEN_INCONNU');
  });

  await verifie('QR code public généré', async () => {
    const r = await appel('/public/qr?texte=https://diffusion.educa.ht/r/rp-001');
    assert.strictEqual(r.statut, 200);
    assert.ok(String(r.charge).startsWith('<svg'));
  });

  /* --- SQL émis : la clause de cloisonnement est bien présente ------------- */
  const faux = await mock.demarrer({ utilisateur: 'educa', motDePasse: 'secret' });
  bd.initialiser(`postgres://educa:secret@127.0.0.1:${faux.port}/diffusion`);

  await verifie('SQL des travaux : filtré par école et année, en paramètres', async () => {
    faux.journal.length = 0;
    await appel('/travaux-diriges?discipline=Mathématiques', { jeton: jeton(ECOLE_A) });
    const demande = faux.journal.at(-1);
    assert.ok(/ecole_id = \$1/.test(demande.sql), demande.sql);
    assert.ok(/annee_academique_id = \$2/.test(demande.sql), demande.sql);
    assert.strictEqual(demande.params[0], 'eco_A');
    assert.strictEqual(demande.params[1], 'an_2026');
    assert.ok(!demande.sql.includes('eco_A'), 'aucune valeur ne doit entrer dans le texte SQL');
  });

  await verifie('SQL des travaux : l’école B ne voit jamais eco_A', async () => {
    faux.journal.length = 0;
    await appel('/travaux-diriges', { jeton: jeton(ECOLE_B) });
    const demande = faux.journal.at(-1);
    assert.strictEqual(demande.params[0], 'eco_B');
  });

  await verifie('SQL du fonds : visibilité commune ou école du jeton', async () => {
    faux.journal.length = 0;
    await appel('/ressources?discipline=Sciences', { jeton: jeton(ECOLE_A) });
    const demande = faux.journal.at(-1);
    assert.ok(/visibilite = 'commun' OR \(visibilite = 'ecole' AND ecole_id = \$1\)/.test(demande.sql), demande.sql);
    assert.strictEqual(demande.params[0], 'eco_A');
  });

  await verifie('Injection dans un filtre : transmise en paramètre, jamais en SQL', async () => {
    faux.journal.length = 0;
    await appel(`/ressources?discipline=${encodeURIComponent("Sciences'; DROP TABLE ressources--")}`,
      { jeton: jeton(ECOLE_A) });
    const demande = faux.journal.at(-1);
    assert.ok(!demande.sql.includes('DROP TABLE'), demande.sql);
    assert.ok(demande.params.includes("Sciences'; DROP TABLE ressources--"));
  });

  await verifie('Filtre inconnu ignoré, pas interpolé', async () => {
    faux.journal.length = 0;
    await appel('/ressources?colonne_inventee=1&discipline=Sciences', { jeton: jeton(ECOLE_A) });
    const demande = faux.journal.at(-1);
    assert.ok(!demande.sql.includes('colonne_inventee'), demande.sql);
    assert.deepStrictEqual(demande.params.slice(0, 2), ['eco_A', 'Sciences']);
  });

  await verifie('Tentative de changement d’école par l’URL : aucune requête émise', async () => {
    faux.journal.length = 0;
    const r = await appel('/ressources?ecole_id=eco_B', { jeton: jeton(ECOLE_A) });
    assert.strictEqual(r.statut, 403);
    assert.strictEqual(faux.journal.length, 0, 'la requête ne doit jamais atteindre la base');
  });

  faux.arreter();
  await bd.fermer();
  serveur.close();
  console.log(echecs ? `\n${echecs} contrôle(s) en échec` : '\nTous les contrôles passent');
  process.exit(echecs ? 1 : 0);
})();
