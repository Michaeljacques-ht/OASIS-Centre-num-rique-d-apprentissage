'use strict';
/**
 * Point d'entrée du service de diffusion.
 *   PORT=... DATABASE_URL=... node src/server.js
 */
const http = require('http');
const env = require('./config/env');
const bd = require('./config/database');
const { creerApplication } = require('./app');

const port = env.port();
const socle = bd.initialiser();

if (env.production && !env.jwtSecret && !env.jwtClePublique) {
  console.error('[config] JWT_SECRET ou JWT_PUBLIC_KEY est requis en production.');
  process.exit(1);
}

const serveur = http.createServer(creerApplication());

serveur.listen(port, () => {
  console.log(`diffusion-service — http://localhost:${port}${env.prefixeApi}`);
  console.log(`  socle de données  : ${socle === 'postgres' ? 'PostgreSQL' : 'collections JSON (DATABASE_URL absent)'}`);
  if (!env.production && !env.jwtSecret && !env.jwtClePublique) {
    console.log('  authentification  : mode développement — en-tête X-Dev-Identite accepté');
  }
});

const arreter = async (signal) => {
  console.log(`\n${signal} — arrêt du service`);
  serveur.close();
  await bd.fermer();
  process.exit(0);
};
process.on('SIGINT', () => arreter('SIGINT'));
process.on('SIGTERM', () => arreter('SIGTERM'));

module.exports = { serveur };
