'use strict';
/**
 * Accès aux ressources. Le cloisonnement est appliqué ici, pas dans les
 * contrôleurs : aucune requête ne peut sortir du dépôt sans sa clause.
 *
 * Particularité du domaine : le fonds commun est partagé par tout
 * l'écosystème. Ce n'est pas une entorse à la règle multi-école, c'est la
 * raison d'être de la plateforme — une ressource « commune » est un contenu
 * édité et validé, sans donnée d'école. En revanche, toute ressource déposée
 * pour une école reste invisible des autres.
 */
const bd = require('../config/database');
const { COLONNES_RESSOURCE, completerRessource } = require('../models/mappers');

/** Clause de visibilité, paramétrée : jamais d'interpolation. */
function clauseVisibilite(contexte, valeurs) {
  valeurs.push(contexte.ecoleId || null);
  const place = `$${valeurs.length}`;
  return `(visibilite = 'commun' OR (visibilite = 'ecole' AND ecole_id = ${place}))`;
}

const CHAMPS_FILTRABLES = {
  discipline: 'discipline', niveau: 'niveau', type: 'type',
  format: 'format', famille: 'famille', cycle: 'cycle', public: 'audience',
};

async function lister(contexte, filtres = {}, options = {}) {
  if (!bd.estPostgres()) return listerJson(contexte, filtres, options);

  const valeurs = [];
  const conditions = [`statut = 'publiee'`, clauseVisibilite(contexte, valeurs)];

  for (const [cle, valeur] of Object.entries(filtres)) {
    const colonne = CHAMPS_FILTRABLES[cle];
    if (!colonne || !valeur || valeur === 'tous' || valeur === 'toutes') continue;
    valeurs.push(valeur);
    conditions.push(`unaccent_simple(${colonne}) = unaccent_simple($${valeurs.length})`);
  }
  if (contexte.cycle) {
    valeurs.push(contexte.cycle);
    conditions.push(`cycle = $${valeurs.length}`);
  }
  if (options.recherche) {
    valeurs.push(`%${options.recherche}%`);
    conditions.push(`(unaccent_simple(titre) LIKE unaccent_simple($${valeurs.length})
                      OR unaccent_simple(coalesce(resume,'')) LIKE unaccent_simple($${valeurs.length}))`);
  }

  const limite = Math.min(Number(options.limite) || 50, 200);
  const decalage = Math.max(Number(options.decalage) || 0, 0);
  valeurs.push(limite, decalage);

  const { lignes } = await bd.requete(
    `SELECT ${COLONNES_RESSOURCE}, count(*) OVER () AS total
       FROM ressources
      WHERE ${conditions.join(' AND ')}
      ORDER BY ajoute DESC, id
      LIMIT $${valeurs.length - 1} OFFSET $${valeurs.length}`,
    valeurs
  );
  const total = lignes.length ? Number(lignes[0].total) : 0;
  return { elements: lignes.map(({ total: _, ...r }) => r), total };
}

/** Repli JSON : même sémantique de cloisonnement, appliquée en mémoire. */
function listerJson(contexte, filtres, options) {
  const tous = bd.lireJson('ressources-pedagogiques').map(completerRessource);
  const slug = (v) => String(v ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

  let elements = tous.filter((r) =>
    r.visibilite === 'commun' || (r.visibilite === 'ecole' && r.ecoleId === contexte.ecoleId)
  );
  for (const [cle, valeur] of Object.entries(filtres)) {
    if (!CHAMPS_FILTRABLES[cle] || !valeur || valeur === 'tous' || valeur === 'toutes') continue;
    elements = elements.filter((r) => slug(r[cle]) === slug(valeur));
  }
  if (contexte.cycle) elements = elements.filter((r) => r.cycle === contexte.cycle);
  if (options.recherche) {
    const m = slug(options.recherche);
    elements = elements.filter((r) => slug(`${r.titre} ${r.resume || ''}`).includes(m));
  }
  const total = elements.length;
  const decalage = Math.max(Number(options.decalage) || 0, 0);
  const limite = Math.min(Number(options.limite) || 50, 200);
  return { elements: elements.slice(decalage, decalage + limite), total };
}

async function parId(contexte, id) {
  if (!bd.estPostgres()) {
    const { elements } = listerJson(contexte, {}, { limite: 200 });
    return elements.find((r) => r.id === id) || null;
  }
  const valeurs = [id];
  const clause = clauseVisibilite(contexte, valeurs);
  const { lignes } = await bd.requete(
    `SELECT ${COLONNES_RESSOURCE} FROM ressources WHERE id = $1 AND ${clause}`, valeurs
  );
  return lignes[0] || null;
}

/** Résolution d'une adresse courte imprimée : hors cloisonnement, par nature. */
async function parLienCourt(id) {
  if (!bd.estPostgres()) {
    return bd.lireJson('ressources-pedagogiques').map(completerRessource).find((r) => r.id === id) || null;
  }
  const { lignes } = await bd.requete(
    `SELECT ${COLONNES_RESSOURCE} FROM ressources
      WHERE id = $1 AND visibilite = 'commun' AND statut IN ('publiee','redirigee','archivee')`, [id]
  );
  return lignes[0] || null;
}

async function compterScan(id) {
  if (!bd.estPostgres()) return;
  await bd.requete(
    `INSERT INTO usages (ressource_id, jour, scans) VALUES ($1, CURRENT_DATE, 1)
     ON CONFLICT (ressource_id, jour) DO UPDATE SET scans = usages.scans + 1`, [id]
  );
}

module.exports = { lister, parId, parLienCourt, compterScan, CHAMPS_FILTRABLES };
