'use strict';
/**
 * Accès aux travaux dirigés. Contrairement au fonds documentaire, il s'agit de
 * travail de classe : ecole_id et annee_academique_id sont obligatoires en
 * lecture comme en écriture.
 */
const bd = require('../config/database');
const { COLONNES_TRAVAIL, completerTravail } = require('../models/mappers');

const CHAMPS_FILTRABLES = { discipline: 'discipline', niveau: 'niveau', difficulte: 'difficulte', cycle: 'cycle' };

async function lister(contexte, filtres = {}, options = {}) {
  if (!bd.estPostgres()) return listerJson(contexte, filtres, options);

  const valeurs = [contexte.ecoleId];
  const conditions = ['ecole_id = $1'];
  if (contexte.anneeAcademiqueId) {
    valeurs.push(contexte.anneeAcademiqueId);
    conditions.push(`annee_academique_id = $${valeurs.length}`);
  }
  for (const [cle, valeur] of Object.entries(filtres)) {
    const colonne = CHAMPS_FILTRABLES[cle];
    if (!colonne || !valeur || valeur === 'tous' || valeur === 'toutes') continue;
    valeurs.push(valeur);
    conditions.push(`unaccent_simple(${colonne}) = unaccent_simple($${valeurs.length})`);
  }
  if (options.recherche) {
    valeurs.push(`%${options.recherche}%`);
    conditions.push(`unaccent_simple(titre) LIKE unaccent_simple($${valeurs.length})`);
  }
  const limite = Math.min(Number(options.limite) || 50, 200);
  const decalage = Math.max(Number(options.decalage) || 0, 0);
  valeurs.push(limite, decalage);

  const { lignes } = await bd.requete(
    `SELECT ${COLONNES_TRAVAIL}, count(*) OVER () AS total
       FROM travaux_diriges WHERE ${conditions.join(' AND ')}
      ORDER BY modifie DESC, id
      LIMIT $${valeurs.length - 1} OFFSET $${valeurs.length}`,
    valeurs
  );
  return { elements: lignes.map(({ total: _, ...t }) => t), total: lignes.length ? Number(lignes[0].total) : 0 };
}

function listerJson(contexte, filtres, options) {
  const slug = (v) => String(v ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  let elements = bd.lireJson('travaux-diriges').map(completerTravail)
    .filter((t) => t.ecoleId === null || t.ecoleId === contexte.ecoleId);
  for (const [cle, valeur] of Object.entries(filtres)) {
    if (!CHAMPS_FILTRABLES[cle] || !valeur || valeur === 'tous' || valeur === 'toutes') continue;
    elements = elements.filter((t) => slug(t[cle]) === slug(valeur));
  }
  if (options.recherche) elements = elements.filter((t) => slug(t.titre).includes(slug(options.recherche)));
  const total = elements.length;
  const decalage = Math.max(Number(options.decalage) || 0, 0);
  const limite = Math.min(Number(options.limite) || 50, 200);
  return { elements: elements.slice(decalage, decalage + limite), total };
}

async function parId(contexte, id) {
  if (!bd.estPostgres()) {
    const { elements } = listerJson(contexte, {}, { limite: 200 });
    return elements.find((t) => t.id === id) || null;
  }
  const { lignes } = await bd.requete(
    `SELECT ${COLONNES_TRAVAIL} FROM travaux_diriges WHERE id = $1 AND ecole_id = $2`,
    [id, contexte.ecoleId]
  );
  return lignes[0] || null;
}

async function creer(contexte, travail) {
  if (!bd.estPostgres()) throw Object.assign(new Error('écriture indisponible sur socle JSON'), { statut: 503 });
  const { lignes } = await bd.requete(
    `INSERT INTO travaux_diriges
       (id, titre, discipline, niveau, cycle, chapitre, exercices, difficulte, duree,
        icon, tone, auteur_id, ecole_id, annee_academique_id, classe_id, statut)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,'brouillon')
     RETURNING ${COLONNES_TRAVAIL}`,
    [travail.id, travail.titre, travail.discipline, travail.niveau, travail.cycle,
     travail.chapitre || null, travail.exercices || 0, travail.difficulte || null,
     travail.duree || null, travail.icon || 'file', travail.tone || 'blue',
     contexte.utilisateurId, contexte.ecoleId, contexte.anneeAcademiqueId, travail.classeId || null]
  );
  return lignes[0];
}

module.exports = { lister, parId, creer, CHAMPS_FILTRABLES };
