'use strict';
/** Documents éditoriaux : navigation, contenus d'accueil, catalogues de familles. */
const bd = require('../config/database');

async function parCle(cle, defaut = null) {
  if (!bd.estPostgres()) return bd.lireJson(cle, defaut);
  const { lignes } = await bd.requete('SELECT contenu FROM documents WHERE cle = $1', [cle]);
  return lignes.length ? lignes[0].contenu : defaut;
}

async function enregistrer(cle, contenu) {
  if (!bd.estPostgres()) throw Object.assign(new Error('écriture indisponible sur socle JSON'), { statut: 503 });
  await bd.requete(
    `INSERT INTO documents (cle, contenu) VALUES ($1, $2)
     ON CONFLICT (cle) DO UPDATE SET contenu = EXCLUDED.contenu, modifie_le = now()`,
    [cle, JSON.stringify(contenu)]
  );
  return contenu;
}

module.exports = { parCle, enregistrer };
