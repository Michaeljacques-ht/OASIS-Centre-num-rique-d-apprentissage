'use strict';
/** Projection SQL ↔ objet métier. Les alias reproduisent les noms exposés par l'API. */

const COLONNES_RESSOURCE = `
  id, titre, resume, famille, type, type_tone AS "typeTone", format,
  format_tone AS "formatTone", action, discipline, niveau, cycle, auteur,
  auteur_id AS "auteurId", image, audience AS "public", visibilite,
  ecole_id AS "ecoleId", note, avis, vues, telechargements,
  lien_court AS "lienCourt", statut,
  to_char(ajoute, 'YYYY-MM-DD') AS ajoute`;

const COLONNES_TRAVAIL = `
  id, titre, discipline, niveau, cycle, chapitre, exercices, difficulte, duree,
  icon, tone, favori, vues, statut, classe_id AS "classeId",
  ecole_id AS "ecoleId", annee_academique_id AS "anneeAcademiqueId",
  to_char(cree, 'YYYY-MM-DD') AS cree,
  to_char(modifie, 'YYYY-MM-DD') AS modifie`;

/** Sur socle JSON, les collections ne portent pas les colonnes de cloisonnement. */
const completerRessource = (r) => ({
  visibilite: 'commun', ecoleId: null, cycle: r.cycle || 'secondaire', ...r,
});
const completerTravail = (t) => ({
  ecoleId: null, anneeAcademiqueId: null, cycle: t.cycle || 'secondaire', classeId: null, statut: 'publie', ...t,
});

module.exports = { COLONNES_RESSOURCE, COLONNES_TRAVAIL, completerRessource, completerTravail };
