'use strict';
/**
 * Utilitaires HTTP : routeur à motifs, lecture du corps, réponses normalisées.
 * Écrit à la main — le service reste sans dépendance npm, comme le reste de
 * l'écosystème EDUCA le permet pour un service de cette taille.
 */

/** Convertit « /ressources/:id » en expression régulière nommée. */
function motif(chemin) {
  const noms = [];
  const source = chemin
    .replace(/[.+*?^${}()|[\]\\]/g, '\\$&')
    .replace(/:([a-zA-Z_][a-zA-Z0-9_]*)/g, (_, nom) => { noms.push(nom); return '([^/]+)'; });
  return { regex: new RegExp(`^${source}$`), noms };
}

class Routeur {
  constructor(prefixe = '') { this.prefixe = prefixe; this.routes = []; }

  ajouter(methode, chemin, ...chaine) {
    const { regex, noms } = motif(this.prefixe + chemin);
    this.routes.push({ methode, regex, noms, chaine });
    return this;
  }
  get(c, ...h) { return this.ajouter('GET', c, ...h); }
  post(c, ...h) { return this.ajouter('POST', c, ...h); }
  patch(c, ...h) { return this.ajouter('PATCH', c, ...h); }
  delete(c, ...h) { return this.ajouter('DELETE', c, ...h); }

  /** @returns {boolean} vrai si une route a répondu */
  async traiter(req, res, url) {
    for (const route of this.routes) {
      if (route.methode !== req.method) continue;
      const m = route.regex.exec(url.pathname);
      if (!m) continue;
      req.params = Object.fromEntries(route.noms.map((n, i) => [n, decodeURIComponent(m[i + 1])]));
      req.query = Object.fromEntries(url.searchParams);
      for (const etape of route.chaine) {
        await etape(req, res);
        if (res.writableEnded) return true;
      }
      return true;
    }
    return false;
  }
}

async function lireCorps(req, maxOctets = 1_000_000) {
  const morceaux = [];
  let total = 0;
  for await (const m of req) {
    total += m.length;
    if (total > maxOctets) throw Object.assign(new Error('corps trop volumineux'), { statut: 413 });
    morceaux.push(m);
  }
  if (!total) return {};
  const texte = Buffer.concat(morceaux).toString('utf8');
  try { return JSON.parse(texte); }
  catch { throw Object.assign(new Error('corps JSON invalide'), { statut: 400 }); }
}

const json = (res, statut, charge, entetes = {}) => {
  const corps = JSON.stringify(charge);
  res.writeHead(statut, {
    'Content-Type': 'application/json; charset=utf-8',
    'X-Content-Type-Options': 'nosniff',
    'Content-Length': Buffer.byteLength(corps),
    ...entetes,
  });
  res.end(corps);
};

const ok = (res, donnees, meta) => json(res, 200, meta ? { donnees, meta } : { donnees });
const cree = (res, donnees) => json(res, 201, { donnees });
const erreur = (res, statut, code, message, details) =>
  json(res, statut, { erreur: { code, message, ...(details ? { details } : {}) } });

class ErreurHttp extends Error {
  constructor(statut, code, message, details) {
    super(message);
    this.statut = statut; this.code = code; this.details = details;
  }
}

module.exports = { Routeur, lireCorps, json, ok, cree, erreur, ErreurHttp, motif };
