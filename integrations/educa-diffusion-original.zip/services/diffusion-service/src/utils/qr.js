'use strict';
/**
 * Encodeur QR code — mode octet, correction de niveau M, versions 1 à 6
 * (jusqu'à 106 octets, largement suffisant pour une URL de ressource).
 * Écrit pour ce projet : aucune bibliothèque externe.
 *
 *   const { svg } = require('./lib/qr');
 *   svg('https://diffusion.educa.ht/r/RES-12564', { size: 220 });
 */

/* --- Corps de Galois GF(256), polynôme primitif 0x11D --------------------- */
const EXP = new Uint8Array(512);
const LOG = new Uint8Array(256);
(function initGf() {
  let x = 1;
  for (let i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 0x100) x ^= 0x11d; }
  for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
})();
const mul = (a, b) => (a === 0 || b === 0 ? 0 : EXP[LOG[a] + LOG[b]]);

/** Polynôme générateur de Reed-Solomon pour `n` codets de correction. */
function generator(n) {
  let g = [1];
  for (let i = 0; i < n; i++) {
    const next = new Array(g.length + 1).fill(0);
    for (let j = 0; j < g.length; j++) {
      next[j] ^= g[j];
      next[j + 1] ^= mul(g[j], EXP[i]);
    }
    g = next;
  }
  return g;
}

/** Reste de la division polynomiale : les codets de correction. */
function remainder(data, n) {
  const g = generator(n);
  const buf = data.concat(new Array(n).fill(0));
  for (let i = 0; i < data.length; i++) {
    const factor = buf[i];
    if (factor === 0) continue;
    for (let j = 0; j < g.length; j++) buf[i + j] ^= mul(g[j], factor);
  }
  return buf.slice(data.length);
}

/* --- Tables de version, niveau M ----------------------------------------- */
// [codets de données, codets de correction par bloc, nombre de blocs]
const VERSIONS = {
  1: [16, 10, 1], 2: [28, 16, 1], 3: [44, 26, 1],
  4: [64, 18, 2], 5: [86, 24, 2], 6: [108, 16, 4],
};
const ALIGNMENT = { 1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34] };

function pickVersion(byteLength) {
  for (const v of [1, 2, 3, 4, 5, 6]) {
    if (byteLength <= VERSIONS[v][0] - 2) return v;
  }
  throw new RangeError(`Contenu trop long pour un QR de version 6 : ${byteLength} octets (maximum 106).`);
}

/* --- Encodage du flux binaire -------------------------------------------- */
function encodeData(bytes, version) {
  const [dataCodewords] = VERSIONS[version];
  const bits = [];
  const push = (value, length) => { for (let i = length - 1; i >= 0; i--) bits.push((value >> i) & 1); };

  push(0b0100, 4);            // mode octet
  push(bytes.length, 8);      // longueur (8 bits pour les versions 1 à 9)
  for (const b of bytes) push(b, 8);

  const capacity = dataCodewords * 8;
  push(0, Math.min(4, capacity - bits.length));           // terminateur
  while (bits.length % 8) bits.push(0);                   // alignement sur l'octet

  const codewords = [];
  for (let i = 0; i < bits.length; i += 8) {
    codewords.push(bits.slice(i, i + 8).reduce((acc, bit) => (acc << 1) | bit, 0));
  }
  const PAD = [0xec, 0x11];
  for (let i = 0; codewords.length < dataCodewords; i++) codewords.push(PAD[i % 2]);
  return codewords;
}

/** Découpe en blocs, calcule la correction, puis entrelace. */
function interleave(codewords, version) {
  const [, eccPerBlock, blocks] = VERSIONS[version];
  const short = Math.floor(codewords.length / blocks);
  const longBlocks = codewords.length % blocks;

  const data = [];
  const ecc = [];
  let offset = 0;
  for (let b = 0; b < blocks; b++) {
    const size = short + (b >= blocks - longBlocks ? 1 : 0);
    const block = codewords.slice(offset, offset + size);
    offset += size;
    data.push(block);
    ecc.push(remainder(block, eccPerBlock));
  }

  const out = [];
  for (let i = 0; i < Math.max(...data.map((b) => b.length)); i++) {
    for (const block of data) if (i < block.length) out.push(block[i]);
  }
  for (let i = 0; i < eccPerBlock; i++) {
    for (const block of ecc) out.push(block[i]);
  }
  return { stream: out, data, ecc };
}

/* --- Trame ---------------------------------------------------------------- */
function newMatrix(size) {
  return { modules: Array.from({ length: size }, () => new Array(size).fill(0)),
           reserved: Array.from({ length: size }, () => new Array(size).fill(false)), size };
}

function drawFunctionPatterns(m, version) {
  const { size } = m;
  const set = (r, c, v) => { m.modules[r][c] = v; m.reserved[r][c] = true; };

  // Motifs de repérage et séparateurs
  for (const [br, bc] of [[0, 0], [0, size - 7], [size - 7, 0]]) {
    for (let r = -1; r <= 7; r++) {
      for (let c = -1; c <= 7; c++) {
        const rr = br + r; const cc = bc + c;
        if (rr < 0 || cc < 0 || rr >= size || cc >= size) continue;
        const edge = r === 0 || r === 6 || c === 0 || c === 6;
        const core = r >= 2 && r <= 4 && c >= 2 && c <= 4;
        set(rr, cc, r >= 0 && r <= 6 && c >= 0 && c <= 6 && (edge || core) ? 1 : 0);
      }
    }
  }

  // Motifs d'alignement
  const centers = ALIGNMENT[version];
  for (const r of centers) {
    for (const c of centers) {
      if (m.reserved[r][c]) continue; // chevauche un motif de repérage
      for (let dr = -2; dr <= 2; dr++) {
        for (let dc = -2; dc <= 2; dc++) {
          const ring = Math.max(Math.abs(dr), Math.abs(dc));
          set(r + dr, c + dc, ring === 1 ? 0 : 1);
        }
      }
    }
  }

  // Synchronisation
  for (let i = 8; i < size - 8; i++) {
    const bit = i % 2 === 0 ? 1 : 0;
    if (!m.reserved[6][i]) set(6, i, bit);
    if (!m.reserved[i][6]) set(i, 6, bit);
  }

  // Module toujours noir, puis réservation des zones de format
  set(size - 8, 8, 1);
  for (let i = 0; i < 9; i++) {
    if (!m.reserved[8][i]) set(8, i, 0);
    if (!m.reserved[i][8]) set(i, 8, 0);
  }
  for (let i = 0; i < 8; i++) {
    if (!m.reserved[8][size - 1 - i]) set(8, size - 1 - i, 0);
    if (!m.reserved[size - 1 - i][8]) set(size - 1 - i, 8, 0);
  }
}

/** Parcours en zigzag depuis le coin inférieur droit. */
function walk(size, visit) {
  let upward = true;
  for (let col = size - 1; col > 0; col -= 2) {
    if (col === 6) col--;
    const rows = upward
      ? Array.from({ length: size }, (_, i) => size - 1 - i)
      : Array.from({ length: size }, (_, i) => i);
    for (const row of rows) {
      for (const c of [col, col - 1]) visit(row, c);
    }
    upward = !upward;
  }
}

function placeData(m, stream) {
  let index = 0;
  walk(m.size, (row, col) => {
    if (m.reserved[row][col]) return;
    const byte = stream[index >> 3];
    const bit = byte === undefined ? 0 : (byte >> (7 - (index & 7))) & 1;
    m.modules[row][col] = bit;
    index++;
  });
}

const MASKS = [
  (i, j) => (i + j) % 2 === 0,
  (i) => i % 2 === 0,
  (i, j) => j % 3 === 0,
  (i, j) => (i + j) % 3 === 0,
  (i, j) => (Math.floor(i / 2) + Math.floor(j / 3)) % 2 === 0,
  (i, j) => ((i * j) % 2) + ((i * j) % 3) === 0,
  (i, j) => (((i * j) % 2) + ((i * j) % 3)) % 2 === 0,
  (i, j) => (((i + j) % 2) + ((i * j) % 3)) % 2 === 0,
];

function applyMask(m, mask) {
  const out = m.modules.map((row) => row.slice());
  for (let i = 0; i < m.size; i++) {
    for (let j = 0; j < m.size; j++) {
      if (!m.reserved[i][j] && MASKS[mask](i, j)) out[i][j] ^= 1;
    }
  }
  return out;
}

/** Information de format : 5 bits utiles + BCH(15,5), puis masque fixe. */
function formatBits(mask) {
  const data = (0b00 << 3) | mask; // 00 = niveau M
  let value = data << 10;
  for (let i = 4; i >= 0; i--) {
    if ((value >> (i + 10)) & 1) value ^= 0b10100110111 << i;
  }
  return ((data << 10) | value) ^ 0b101010000010010;
}

function placeFormat(modules, size, mask) {
  const bits = formatBits(mask);
  const bit = (i) => (bits >> i) & 1;
  for (let i = 0; i <= 5; i++) { modules[8][i] = bit(i); modules[size - 1 - i][8] = bit(i); }
  modules[8][7] = bit(6); modules[8][8] = bit(7); modules[7][8] = bit(8);
  modules[size - 7][8] = bit(6);
  modules[8][size - 8] = bit(7);
  modules[8][size - 7] = bit(8);
  for (let i = 9; i <= 14; i++) { modules[14 - i][8] = bit(i); modules[8][size - 15 + i] = bit(i); }
  modules[size - 8][8] = 1; // module toujours noir
}

/* --- Pénalités : choix du meilleur masque -------------------------------- */
function penalty(modules) {
  const size = modules.length;
  let score = 0;

  const runScore = (line) => {
    let total = 0; let run = 1;
    for (let i = 1; i < line.length; i++) {
      if (line[i] === line[i - 1]) { run++; } else { if (run >= 5) total += 3 + (run - 5); run = 1; }
    }
    if (run >= 5) total += 3 + (run - 5);
    return total;
  };
  for (let i = 0; i < size; i++) {
    score += runScore(modules[i]);
    score += runScore(modules.map((row) => row[i]));
  }

  for (let i = 0; i < size - 1; i++) {
    for (let j = 0; j < size - 1; j++) {
      const v = modules[i][j];
      if (v === modules[i][j + 1] && v === modules[i + 1][j] && v === modules[i + 1][j + 1]) score += 3;
    }
  }

  const PATTERN = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0];
  const hasPattern = (line, at) => PATTERN.every((v, k) => line[at + k] === v);
  for (let i = 0; i < size; i++) {
    const row = modules[i];
    const col = modules.map((r) => r[i]);
    for (let j = 0; j + 11 <= size; j++) {
      if (hasPattern(row, j)) score += 40;
      if (hasPattern(col, j)) score += 40;
    }
  }

  const dark = modules.flat().reduce((a, b) => a + b, 0);
  const ratio = (dark * 100) / (size * size);
  score += Math.floor(Math.abs(ratio - 50) / 5) * 10;
  return score;
}

/* --- API ------------------------------------------------------------------ */
/** @returns {{modules:number[][], size:number, version:number, mask:number}} */
function encode(text) {
  const bytes = Array.from(Buffer.from(String(text), 'utf8'));
  const version = pickVersion(bytes.length);
  const codewords = encodeData(bytes, version);
  const { stream } = interleave(codewords, version);

  const size = 17 + version * 4;
  const base = newMatrix(size);
  drawFunctionPatterns(base, version);
  placeData(base, stream);

  let best = null;
  for (let mask = 0; mask < 8; mask++) {
    const modules = applyMask(base, mask);
    placeFormat(modules, size, mask);
    const score = penalty(modules);
    if (!best || score < best.score) best = { modules, score, mask };
  }
  return { modules: best.modules, size, version, mask: best.mask, reserved: base.reserved };
}

/**
 * Rend le QR code en SVG.
 * @param {string} text
 * @param {{size?:number, margin?:number, dark?:string, light?:string, logo?:string}} [opts]
 */
function svg(text, opts = {}) {
  const { modules, size } = encode(text);
  const margin = opts.margin === undefined ? 4 : opts.margin;
  const total = size + margin * 2;
  const px = opts.size || 200;
  const dark = opts.dark || '#0f1b33';
  const light = opts.light || '#ffffff';

  let path = '';
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (modules[r][c]) path += `M${c + margin} ${r + margin}h1v1h-1z`;
    }
  }

  // Réserve centrale pour le logo : 16 % de la largeur, marge de sécurité couverte par le niveau M
  const hole = opts.logo
    ? (() => {
        const w = Math.round(size * 0.18);
        const at = (total - w) / 2;
        return `<rect x="${at - 0.6}" y="${at - 0.6}" width="${w + 1.2}" height="${w + 1.2}" rx="1.2" fill="${light}"/>` +
               `<image href="${opts.logo}" x="${at}" y="${at}" width="${w}" height="${w}"/>`;
      })()
    : '';

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${px}" height="${px}" viewBox="0 0 ${total} ${total}" shape-rendering="crispEdges" role="img" aria-label="QR code vers ${String(text).replace(/[<>&"]/g, '')}">` +
    `<rect width="${total}" height="${total}" fill="${light}"/>` +
    `<path d="${path}" fill="${dark}"/>${hole}</svg>`;
}

module.exports = { encode, svg, remainder, generator, VERSIONS, MASKS, walk, mul, EXP, LOG };
