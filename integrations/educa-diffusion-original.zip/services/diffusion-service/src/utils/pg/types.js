'use strict';
/**
 * Conversion des valeurs PostgreSQL, au format texte.
 *
 * Choix assumés :
 *  — numeric est rendu en chaîne, pour ne pas perdre de précision ;
 *  — bigint devient un Number tant qu'il reste exact, un BigInt au-delà ;
 *  — les dates deviennent des objets Date ;
 *  — json et jsonb sont analysés.
 */

const OID = {
  BOOL: 16, BYTEA: 17, CHAR: 18, NAME: 19, INT8: 20, INT2: 21, INT4: 23,
  TEXT: 25, OID: 26, JSON: 114, FLOAT4: 700, FLOAT8: 701, BPCHAR: 1042,
  VARCHAR: 1043, DATE: 1082, TIME: 1083, TIMESTAMP: 1114, TIMESTAMPTZ: 1184,
  INTERVAL: 1186, NUMERIC: 1700, UUID: 2950, JSONB: 3802,
  // tableaux
  BOOL_ARR: 1000, INT2_ARR: 1005, INT4_ARR: 1007, TEXT_ARR: 1009,
  VARCHAR_ARR: 1015, INT8_ARR: 1016, FLOAT8_ARR: 1022, NUMERIC_ARR: 1231,
  JSONB_ARR: 3807, UUID_ARR: 2951,
};

const TYPE_ELEMENT = {
  [OID.BOOL_ARR]: OID.BOOL, [OID.INT2_ARR]: OID.INT2, [OID.INT4_ARR]: OID.INT4,
  [OID.TEXT_ARR]: OID.TEXT, [OID.VARCHAR_ARR]: OID.VARCHAR, [OID.INT8_ARR]: OID.INT8,
  [OID.FLOAT8_ARR]: OID.FLOAT8, [OID.NUMERIC_ARR]: OID.NUMERIC,
  [OID.JSONB_ARR]: OID.JSONB, [OID.UUID_ARR]: OID.UUID,
};

/** Analyse la notation littérale des tableaux : {a,b,"c,d",NULL} */
function lireTableau(texte) {
  if (texte === '{}') return [];
  const out = [];
  let i = 1; // on saute l'accolade ouvrante
  let courant = '';
  let entreGuillemets = false;
  let etaitCite = false;

  while (i < texte.length) {
    const c = texte[i];
    if (entreGuillemets) {
      if (c === '\\') { courant += texte[i + 1]; i += 2; continue; }
      if (c === '"') { entreGuillemets = false; i += 1; continue; }
      courant += c; i += 1; continue;
    }
    if (c === '"') { entreGuillemets = true; etaitCite = true; i += 1; continue; }
    if (c === ',' || c === '}') {
      out.push(!etaitCite && courant === 'NULL' ? null : courant);
      courant = ''; etaitCite = false; i += 1;
      if (c === '}') break;
      continue;
    }
    courant += c; i += 1;
  }
  return out;
}

/** Convertit une valeur texte renvoyée par le serveur selon son OID. */
function decoder(valeur, oid) {
  if (valeur === null) return null;

  switch (oid) {
    case OID.BOOL: return valeur === 't';
    case OID.INT2:
    case OID.INT4:
    case OID.OID: return parseInt(valeur, 10);
    case OID.INT8: {
      const n = Number(valeur);
      return Number.isSafeInteger(n) ? n : BigInt(valeur);
    }
    case OID.FLOAT4:
    case OID.FLOAT8: return parseFloat(valeur);
    case OID.NUMERIC: return valeur;                   // précision préservée
    case OID.JSON:
    case OID.JSONB:
      try { return JSON.parse(valeur); } catch { return valeur; }
    case OID.DATE:
    case OID.TIMESTAMP:
    case OID.TIMESTAMPTZ: {
      const d = new Date(oid === OID.TIMESTAMP ? valeur + 'Z' : valeur);
      return Number.isNaN(d.getTime()) ? valeur : d;
    }
    case OID.BYTEA:
      return valeur.startsWith('\\x') ? Buffer.from(valeur.slice(2), 'hex') : Buffer.from(valeur, 'utf8');
    default:
      if (TYPE_ELEMENT[oid] !== undefined) {
        const element = TYPE_ELEMENT[oid];
        return lireTableau(valeur).map((v) => (v === null ? null : decoder(v, element)));
      }
      return valeur;
  }
}

/** Prépare un paramètre pour l'envoi : tout part au format texte. */
function encoder(valeur) {
  if (valeur === null || valeur === undefined) return null;
  if (Buffer.isBuffer(valeur)) return '\\x' + valeur.toString('hex');
  if (valeur instanceof Date) return valeur.toISOString();
  if (typeof valeur === 'boolean') return valeur ? 't' : 'f';
  if (Array.isArray(valeur) || (typeof valeur === 'object' && valeur !== null)) {
    return JSON.stringify(valeur);
  }
  return String(valeur);
}

module.exports = { OID, decoder, encoder, lireTableau };
