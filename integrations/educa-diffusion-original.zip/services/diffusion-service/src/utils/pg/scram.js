'use strict';
/**
 * Authentification SASL / SCRAM-SHA-256 (RFC 5802 et RFC 7677).
 * Sans liaison de canal : l'en-tête GS2 est « n,, ».
 *
 * Le mot de passe ne circule jamais : le client prouve qu'il le connaît
 * en signant un message d'authentification dérivé des deux nonces.
 */
const crypto = require('crypto');

const hmac = (cle, donnees) => crypto.createHmac('sha256', cle).update(donnees).digest();
const sha256 = (donnees) => crypto.createHash('sha256').update(donnees).digest();
const xor = (a, b) => Buffer.from(a.map((octet, i) => octet ^ b[i]));

/** Nonce client : 24 octets aléatoires en base64, sans caractère interdit. */
function nonce() {
  return crypto.randomBytes(24).toString('base64').replace(/[,=]/g, '');
}

/** Découpe « cle=valeur,cle=valeur » en objet. */
function attributs(chaine) {
  const out = {};
  for (const part of chaine.split(',')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i)] = part.slice(i + 1);
  }
  return out;
}

/**
 * Ouvre un échange SCRAM.
 * @param {string} motDePasse
 * @param {{utilisateur?: string, nonceClient?: string}} [opts]
 *   utilisateur — valeur du champ n= ; PostgreSQL attend une chaîne vide,
 *   le champ étant déjà transmis dans le message de démarrage.
 */
function echange(motDePasse, opts = {}) {
  const utilisateur = opts.utilisateur === undefined ? '' : opts.utilisateur;
  const nonceClient = opts.nonceClient || nonce();
  const enTeteGs2 = 'n,,';
  const clientPremierNu = `n=${utilisateur},r=${nonceClient}`;

  return {
    /** Premier message client, en-tête GS2 compris. */
    premierMessage() {
      return Buffer.from(enTeteGs2 + clientPremierNu, 'utf8');
    },

    /**
     * Traite le message serveur et produit le message final.
     * @returns {{message: Buffer, signatureServeurAttendue: string}}
     */
    reponse(serveurPremier) {
      const texte = Buffer.isBuffer(serveurPremier) ? serveurPremier.toString('utf8') : serveurPremier;
      const a = attributs(texte);
      if (!a.r || !a.s || !a.i) throw new Error('SCRAM : message serveur incomplet');
      if (!a.r.startsWith(nonceClient)) throw new Error('SCRAM : nonce serveur non conforme');

      const sel = Buffer.from(a.s, 'base64');
      const iterations = parseInt(a.i, 10);
      const motDePasseSale = crypto.pbkdf2Sync(
        Buffer.from(motDePasse, 'utf8'), sel, iterations, 32, 'sha256'
      );

      const cleClient = hmac(motDePasseSale, 'Client Key');
      const cleStockee = sha256(cleClient);
      const cleServeur = hmac(motDePasseSale, 'Server Key');

      const clientFinalSansPreuve = `c=${Buffer.from(enTeteGs2, 'utf8').toString('base64')},r=${a.r}`;
      const messageAuth = `${clientPremierNu},${texte},${clientFinalSansPreuve}`;

      const signatureClient = hmac(cleStockee, messageAuth);
      const preuve = xor(cleClient, signatureClient).toString('base64');
      const signatureServeur = hmac(cleServeur, messageAuth).toString('base64');

      return {
        message: Buffer.from(`${clientFinalSansPreuve},p=${preuve}`, 'utf8'),
        signatureServeurAttendue: signatureServeur,
      };
    },

    /** Vérifie la signature renvoyée par le serveur (message v=). */
    verifier(serveurFinal, attendue) {
      const texte = Buffer.isBuffer(serveurFinal) ? serveurFinal.toString('utf8') : serveurFinal;
      const a = attributs(texte);
      if (a.e) throw new Error(`SCRAM : le serveur a refusé l'authentification (${a.e})`);
      if (a.v !== attendue) throw new Error('SCRAM : signature du serveur invalide');
      return true;
    },
  };
}

/** Authentification md5 historique : md5(md5(motDePasse + utilisateur) + sel). */
function md5(utilisateur, motDePasse, sel) {
  const interne = crypto.createHash('md5').update(motDePasse + utilisateur, 'utf8').digest('hex');
  const externe = crypto.createHash('md5')
    .update(Buffer.concat([Buffer.from(interne, 'utf8'), sel]))
    .digest('hex');
  return 'md5' + externe;
}

module.exports = { echange, md5, nonce, attributs };
