'use strict';
/**
 * Client PostgreSQL en Node pur — aucune dépendance npm.
 *
 *   const pg = require('./lib/pg');
 *   const bd = pg.reserve(process.env.DATABASE_URL);
 *   const { lignes } = await bd.requete('SELECT * FROM ressources WHERE niveau = $1', ['Secondaire 2']);
 *
 * Portée : protocole v3, authentification en clair, md5 et SCRAM-SHA-256,
 * TLS, requêtes simples et préparées, transactions, réserve de connexions.
 */
const { Connexion, ErreurPg } = require('./connection');
const { Reserve } = require('./pool');
const types = require('./types');

/** Analyse une URL postgres://utilisateur:motdepasse@hote:port/base?sslmode=require */
function lireUrl(url) {
  const u = new URL(url);
  const sslmode = u.searchParams.get('sslmode');
  return {
    hote: decodeURIComponent(u.hostname),
    port: u.port ? parseInt(u.port, 10) : 5432,
    utilisateur: decodeURIComponent(u.username),
    motDePasse: decodeURIComponent(u.password),
    base: decodeURIComponent(u.pathname.slice(1)),
    tls: !sslmode || sslmode === 'disable'
      ? false
      : { exiger: sslmode === 'require' || sslmode === 'verify-full',
          rejectUnauthorized: sslmode === 'verify-full' },
  };
}

const normaliser = (config) => (typeof config === 'string' ? lireUrl(config) : config);

const connexion = (config) => new Connexion(normaliser(config));
const reserve = (config, options = {}) => new Reserve({ ...normaliser(config), ...options });

module.exports = { connexion, reserve, lireUrl, Connexion, Reserve, ErreurPg, types };
