'use strict';
/**
 * Une connexion PostgreSQL : socket, TLS facultatif, authentification,
 * puis exécution des requêtes, une à la fois, dans l'ordre d'arrivée.
 */
const net = require('net');
const tls = require('tls');
const { EventEmitter } = require('events');

const { client, decouper } = require('./protocol');
const scram = require('./scram');
const types = require('./types');

class ErreurPg extends Error {
  constructor(champs) {
    super(champs.M || 'erreur PostgreSQL');
    this.name = 'ErreurPg';
    this.code = champs.C;           // code SQLSTATE
    this.detail = champs.D;
    this.indice = champs.H;
    this.contrainte = champs.n;
    this.table = champs.t;
    this.colonne = champs.c;
    this.position = champs.P;
    this.severite = champs.S || champs.V;
  }
}

class Connexion extends EventEmitter {
  /**
   * @param {{hote?:string, port?:number, utilisateur:string, motDePasse?:string,
   *          base:string, tls?:boolean|object, application?:string, delai?:number}} config
   */
  constructor(config) {
    super();
    this.config = {
      hote: config.hote || 'localhost',
      port: config.port || 5432,
      utilisateur: config.utilisateur,
      motDePasse: config.motDePasse || '',
      base: config.base,
      tls: config.tls === undefined ? false : config.tls,
      application: config.application || 'educa-diffusion',
      delai: config.delai === undefined ? 10000 : config.delai,
    };
    this.socket = null;
    this.tampon = Buffer.alloc(0);
    this.parametres = {};
    this.etat = 'ferme';
    this.file = [];           // requêtes en attente
    this.courante = null;     // requête en cours
    this.pret = null;         // promesse de connexion
    this._scram = null;
  }

  /* --- Cycle de vie ------------------------------------------------------ */
  connecter() {
    if (this.pret) return this.pret;
    this.pret = new Promise((resoudre, rejeter) => {
      this._resoudreConnexion = resoudre;
      this._rejeterConnexion = rejeter;

      const brut = net.connect({ host: this.config.hote, port: this.config.port });
      brut.setNoDelay(true);
      if (this.config.delai) brut.setTimeout(this.config.delai, () => {
        brut.destroy(new Error('délai de connexion dépassé'));
      });

      brut.once('error', (e) => this._echec(e));
      brut.once('close', () => this._ferme());

      brut.once('connect', () => {
        brut.setTimeout(0);
        if (!this.config.tls) return this._installer(brut);
        // Négociation TLS : un seul octet de réponse, S ou N
        brut.write(client.demandeTls());
        brut.once('data', (reponse) => {
          if (reponse[0] === 0x53) {
            const options = typeof this.config.tls === 'object' ? this.config.tls : {};
            const chiffre = tls.connect({ socket: brut, servername: this.config.hote, ...options });
            chiffre.once('secureConnect', () => this._installer(chiffre));
            chiffre.once('error', (e) => this._echec(e));
          } else if (this.config.tls === 'exiger' || (this.config.tls && this.config.tls.exiger)) {
            this._echec(new Error('le serveur refuse TLS alors qu’il est exigé'));
          } else {
            this._installer(brut);
          }
        });
      });
    });
    return this.pret;
  }

  _installer(socket) {
    this.socket = socket;
    this.etat = 'authentification';
    socket.on('data', (morceau) => this._recevoir(morceau));
    socket.on('error', (e) => this._echec(e));
    socket.write(client.demarrage({
      user: this.config.utilisateur,
      database: this.config.base,
      application_name: this.config.application,
      client_encoding: 'UTF8',
      DateStyle: 'ISO',
    }));
  }

  _echec(erreur) {
    this.etat = 'ferme';
    if (this._rejeterConnexion) { this._rejeterConnexion(erreur); this._rejeterConnexion = null; }
    if (this.courante) { this.courante.rejeter(erreur); this.courante = null; }
    for (const r of this.file.splice(0)) r.rejeter(erreur);
    this.emit('erreur', erreur);
  }

  _ferme() {
    this.etat = 'ferme';
    this.emit('fermee');
  }

  fermer() {
    if (this.socket && this.etat !== 'ferme') {
      try { this.socket.write(client.terminer()); } catch { /* socket déjà tombé */ }
      this.socket.end();
    }
    this.etat = 'ferme';
  }

  /* --- Réception --------------------------------------------------------- */
  _recevoir(morceau) {
    this.tampon = this.tampon.length ? Buffer.concat([this.tampon, morceau]) : morceau;
    const { messages, reliquat } = decouper(this.tampon);
    this.tampon = reliquat;
    for (const m of messages) this._traiter(m);
  }

  _traiter(m) {
    switch (m.type) {
      /* Authentification */
      case 'authOk': this.etat = 'demarrage'; return;
      case 'authClair':
        return this.socket.write(client.motDePasse(this.config.motDePasse));
      case 'authMd5':
        return this.socket.write(client.motDePasse(
          scram.md5(this.config.utilisateur, this.config.motDePasse, m.sel)
        ));
      case 'authSasl': {
        if (!m.mecanismes.includes('SCRAM-SHA-256')) {
          return this._echec(new Error(`aucun mécanisme SASL pris en charge : ${m.mecanismes.join(', ')}`));
        }
        this._scram = scram.echange(this.config.motDePasse);
        return this.socket.write(client.saslDebut('SCRAM-SHA-256', this._scram.premierMessage()));
      }
      case 'saslSuite': {
        const r = this._scram.reponse(m.donnees);
        this._signatureAttendue = r.signatureServeurAttendue;
        return this.socket.write(client.saslSuite(r.message));
      }
      case 'saslFin':
        try { this._scram.verifier(m.donnees, this._signatureAttendue); }
        catch (e) { return this._echec(e); }
        return;

      /* Démarrage */
      case 'parametre': this.parametres[m.nom] = m.valeur; return;
      case 'cle': this.pid = m.pid; this.secret = m.secret; return;

      case 'pret':
        this.etatTransaction = m.etat;
        if (this.etat !== 'prete') {
          this.etat = 'prete';
          if (this._resoudreConnexion) { this._resoudreConnexion(this); this._resoudreConnexion = null; }
        } else {
          this._terminerRequete();
        }
        return this._suivante();

      /* Résultats */
      case 'description':
        if (this.courante) this.courante.champs = m.champs;
        return;
      case 'ligne': {
        if (!this.courante) return;
        const champs = this.courante.champs || [];
        const ligne = {};
        m.valeurs.forEach((v, i) => {
          const c = champs[i] || { nom: `colonne${i}`, typeOid: 25 };
          ligne[c.nom] = types.decoder(v, c.typeOid);
        });
        this.courante.lignes.push(ligne);
        return;
      }
      case 'fini':
        if (this.courante) {
          this.courante.etiquette = m.etiquette;
          const nb = /\s(\d+)$/.exec(m.etiquette);
          this.courante.nbLignes = nb ? parseInt(nb[1], 10) : this.courante.lignes.length;
        }
        return;

      case 'erreur': {
        const erreur = new ErreurPg(m.champs);
        if (this.courante) this.courante.erreur = erreur;
        else this._echec(erreur);
        return;
      }
      case 'avis': this.emit('avis', m.champs); return;
      case 'notification': this.emit('notification', m); return;

      default: return; // analyseOk, liaisonOk, aucuneDonnee, etc.
    }
  }

  _terminerRequete() {
    const r = this.courante;
    this.courante = null;
    if (!r) return;
    if (r.erreur) r.rejeter(r.erreur);
    else r.resoudre({ lignes: r.lignes, champs: r.champs || [], nbLignes: r.nbLignes, etiquette: r.etiquette });
  }

  _suivante() {
    if (this.courante || this.etat !== 'prete' || !this.file.length) return;
    const r = this.file.shift();
    this.courante = r;
    this.socket.write(r.octets);
  }

  /* --- Requêtes ----------------------------------------------------------- */
  /**
   * @param {string} sql        requête, paramètres numérotés $1, $2…
   * @param {Array} [params]    valeurs des paramètres
   */
  async requete(sql, params = []) {
    await this.connecter();
    const octets = params.length
      ? Buffer.concat([
          client.analyser('', sql, []),
          client.lier('', '', params.map(types.encoder)),
          client.decrire('P', ''),
          client.executer('', 0),
          client.synchroniser(),
        ])
      // Le protocole simple répond déjà par ReadyForQuery : un Sync
      // supplémentaire provoquerait une seconde réponse qui décalerait le flux.
      : client.requete(sql);

    return new Promise((resoudre, rejeter) => {
      this.file.push({ sql, octets, lignes: [], resoudre, rejeter });
      this._suivante();
    });
  }
}

module.exports = { Connexion, ErreurPg };
