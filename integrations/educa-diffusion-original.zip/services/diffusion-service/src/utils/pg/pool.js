'use strict';
/**
 * Réserve de connexions. Une requête prend une connexion libre, en ouvre une
 * nouvelle si la limite n'est pas atteinte, sinon attend son tour.
 */
const { Connexion } = require('./connection');

class Reserve {
  /** @param {object} config  configuration de connexion + { taille, attenteMax } */
  constructor(config) {
    this.config = config;
    this.taille = config.taille || 4;
    this.attenteMax = config.attenteMax === undefined ? 15000 : config.attenteMax;
    this.libres = [];
    this.occupees = new Set();
    this.attente = [];
    this.fermee = false;
  }

  async prendre() {
    if (this.fermee) throw new Error('réserve fermée');

    const libre = this.libres.pop();
    if (libre) { this.occupees.add(libre); return libre; }

    if (this.occupees.size < this.taille) {
      const c = new Connexion(this.config);
      c.on('erreur', () => this._retirer(c));
      c.on('fermee', () => this._retirer(c));
      this.occupees.add(c);
      try { await c.connecter(); } catch (e) { this._retirer(c); throw e; }
      return c;
    }

    return new Promise((resoudre, rejeter) => {
      const minuteur = this.attenteMax
        ? setTimeout(() => {
            this.attente = this.attente.filter((a) => a.resoudre !== resoudre);
            rejeter(new Error('aucune connexion disponible : délai d’attente dépassé'));
          }, this.attenteMax)
        : null;
      this.attente.push({ resoudre, rejeter, minuteur });
    });
  }

  rendre(c) {
    this.occupees.delete(c);
    if (this.fermee || c.etat === 'ferme') { try { c.fermer(); } catch { /* déjà fermée */ } return; }
    const suivant = this.attente.shift();
    if (suivant) {
      if (suivant.minuteur) clearTimeout(suivant.minuteur);
      this.occupees.add(c);
      return suivant.resoudre(c);
    }
    this.libres.push(c);
  }

  _retirer(c) {
    this.occupees.delete(c);
    this.libres = this.libres.filter((x) => x !== c);
  }

  /** Exécute une requête sur une connexion empruntée puis rendue. */
  async requete(sql, params) {
    const c = await this.prendre();
    try { return await c.requete(sql, params); }
    finally { this.rendre(c); }
  }

  /** Exécute `travail` dans une transaction ; annule en cas d'exception. */
  async transaction(travail) {
    const c = await this.prendre();
    try {
      await c.requete('BEGIN');
      const resultat = await travail(c);
      await c.requete('COMMIT');
      return resultat;
    } catch (e) {
      try { await c.requete('ROLLBACK'); } catch { /* connexion perdue */ }
      throw e;
    } finally {
      this.rendre(c);
    }
  }

  async fermer() {
    this.fermee = true;
    for (const a of this.attente.splice(0)) {
      if (a.minuteur) clearTimeout(a.minuteur);
      a.rejeter(new Error('réserve fermée'));
    }
    for (const c of [...this.libres, ...this.occupees]) { try { c.fermer(); } catch { /* ignore */ } }
    this.libres = [];
    this.occupees.clear();
  }
}

module.exports = { Reserve };
