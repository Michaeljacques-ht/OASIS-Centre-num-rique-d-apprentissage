'use strict';
/**
 * Protocole PostgreSQL v3 — encodage et décodage des messages.
 * Référence : documentation « Frontend/Backend Protocol », messages formats.
 *
 * Chaque message porte : un octet de type (sauf le message de démarrage),
 * puis un entier 32 bits de longueur qui s'inclut lui-même, puis le corps.
 */

/* --- Écriture ------------------------------------------------------------- */
class Writer {
  constructor(taille = 256) {
    this.buf = Buffer.alloc(taille);
    this.pos = 0;
  }

  /** Garantit `n` octets libres, en doublant le tampon si nécessaire. */
  place(n) {
    if (this.pos + n <= this.buf.length) return;
    let taille = this.buf.length * 2;
    while (taille < this.pos + n) taille *= 2;
    const agrandi = Buffer.alloc(taille);
    this.buf.copy(agrandi, 0, 0, this.pos);
    this.buf = agrandi;
  }

  octet(v) { this.place(1); this.buf.writeUInt8(v, this.pos); this.pos += 1; return this; }
  int16(v) { this.place(2); this.buf.writeInt16BE(v, this.pos); this.pos += 2; return this; }
  int32(v) { this.place(4); this.buf.writeInt32BE(v, this.pos); this.pos += 4; return this; }

  /** Chaîne terminée par un octet nul. */
  chaine(s) {
    const octets = Buffer.byteLength(s, 'utf8');
    this.place(octets + 1);
    this.buf.write(s, this.pos, 'utf8');
    this.pos += octets;
    this.buf.writeUInt8(0, this.pos);
    this.pos += 1;
    return this;
  }

  brut(b) { this.place(b.length); b.copy(this.buf, this.pos); this.pos += b.length; return this; }

  contenu() { return this.buf.subarray(0, this.pos); }
}

/** Compose un message client : type + longueur + corps. */
function message(type, construire) {
  const corps = new Writer();
  construire(corps);
  const c = corps.contenu();
  const sortie = new Writer(c.length + 5);
  if (type) sortie.octet(type.charCodeAt(0));
  sortie.int32(c.length + 4);
  sortie.brut(c);
  return sortie.contenu();
}

/* --- Messages client ---------------------------------------------------- */
const client = {
  /** Message de démarrage : pas d'octet de type, protocole 3.0. */
  demarrage(params) {
    const corps = new Writer();
    corps.int32(196608); // 3 << 16
    for (const [cle, valeur] of Object.entries(params)) {
      if (valeur === undefined || valeur === null) continue;
      corps.chaine(cle).chaine(String(valeur));
    }
    corps.octet(0);
    const c = corps.contenu();
    const sortie = new Writer(c.length + 4);
    sortie.int32(c.length + 4).brut(c);
    return sortie.contenu();
  },

  /** Demande de passage en TLS avant toute autre chose. */
  demandeTls() {
    const w = new Writer(8);
    w.int32(8).int32(80877103);
    return w.contenu();
  },

  motDePasse(texte) { return message('p', (w) => w.chaine(texte)); },

  saslDebut(mecanisme, donnees) {
    return message('p', (w) => {
      w.chaine(mecanisme);
      if (donnees === null) w.int32(-1);
      else { w.int32(donnees.length); w.brut(donnees); }
    });
  },

  saslSuite(donnees) { return message('p', (w) => w.brut(donnees)); },

  requete(sql) { return message('Q', (w) => w.chaine(sql)); },

  analyser(nom, sql, typesParam = []) {
    return message('P', (w) => {
      w.chaine(nom).chaine(sql).int16(typesParam.length);
      for (const oid of typesParam) w.int32(oid);
    });
  },

  /** Lie les paramètres ; tout est transmis au format texte. */
  lier(portail, nom, valeurs) {
    return message('B', (w) => {
      w.chaine(portail).chaine(nom);
      w.int16(0);                       // aucun code de format : texte pour tous
      w.int16(valeurs.length);
      for (const v of valeurs) {
        if (v === null) { w.int32(-1); continue; }
        const b = Buffer.isBuffer(v) ? v : Buffer.from(String(v), 'utf8');
        w.int32(b.length).brut(b);
      }
      w.int16(1).int16(0);              // un seul code de format pour les résultats : texte
    });
  },

  decrire(genre, nom) { return message('D', (w) => w.octet(genre.charCodeAt(0)).chaine(nom)); },
  executer(portail, maxLignes = 0) { return message('E', (w) => w.chaine(portail).int32(maxLignes)); },
  fermer(genre, nom) { return message('C', (w) => w.octet(genre.charCodeAt(0)).chaine(nom)); },
  synchroniser() { return message('S', () => {}); },
  terminer() { return message('X', () => {}); },
};

/* --- Lecture -------------------------------------------------------------- */
class Reader {
  constructor(buf) { this.buf = buf; this.pos = 0; }
  octet() { return this.buf.readUInt8(this.pos++); }
  int16() { const v = this.buf.readInt16BE(this.pos); this.pos += 2; return v; }
  int32() { const v = this.buf.readInt32BE(this.pos); this.pos += 4; return v; }
  chaine() {
    const fin = this.buf.indexOf(0, this.pos);
    const s = this.buf.toString('utf8', this.pos, fin);
    this.pos = fin + 1;
    return s;
  }
  brut(n) { const b = this.buf.subarray(this.pos, this.pos + n); this.pos += n; return b; }
  reste() { return this.buf.subarray(this.pos); }
  fini() { return this.pos >= this.buf.length; }
}

/** Décode le corps d'un message serveur selon son type. */
function decoder(type, corps) {
  const r = new Reader(corps);
  switch (type) {
    case 'R': { // authentification
      const code = r.int32();
      if (code === 0) return { type: 'authOk' };
      if (code === 2) return { type: 'authKerberos' };
      if (code === 3) return { type: 'authClair' };
      if (code === 5) return { type: 'authMd5', sel: r.brut(4) };
      if (code === 10) {
        const mecanismes = [];
        while (!r.fini()) { const m = r.chaine(); if (!m) break; mecanismes.push(m); }
        return { type: 'authSasl', mecanismes };
      }
      if (code === 11) return { type: 'saslSuite', donnees: r.reste() };
      if (code === 12) return { type: 'saslFin', donnees: r.reste() };
      return { type: 'authInconnue', code };
    }
    case 'S': return { type: 'parametre', nom: r.chaine(), valeur: r.chaine() };
    case 'K': return { type: 'cle', pid: r.int32(), secret: r.int32() };
    case 'Z': return { type: 'pret', etat: String.fromCharCode(r.octet()) };
    case 'T': {
      const n = r.int16();
      const champs = [];
      for (let i = 0; i < n; i++) {
        champs.push({
          nom: r.chaine(), tableOid: r.int32(), colonne: r.int16(),
          typeOid: r.int32(), taille: r.int16(), modificateur: r.int32(), format: r.int16(),
        });
      }
      return { type: 'description', champs };
    }
    case 'D': {
      const n = r.int16();
      const valeurs = [];
      for (let i = 0; i < n; i++) {
        const taille = r.int32();
        valeurs.push(taille === -1 ? null : r.brut(taille).toString('utf8'));
      }
      return { type: 'ligne', valeurs };
    }
    case 'C': return { type: 'fini', etiquette: r.chaine() };
    case 'I': return { type: 'requeteVide' };
    case 'n': return { type: 'aucuneDonnee' };
    case 's': return { type: 'portailSuspendu' };
    case '1': return { type: 'analyseOk' };
    case '2': return { type: 'liaisonOk' };
    case '3': return { type: 'fermetureOk' };
    case 't': {
      const n = r.int16();
      const oids = [];
      for (let i = 0; i < n; i++) oids.push(r.int32());
      return { type: 'descriptionParams', oids };
    }
    case 'E':
    case 'N': {
      const champs = {};
      while (!r.fini()) {
        const code = r.octet();
        if (code === 0) break;
        champs[String.fromCharCode(code)] = r.chaine();
      }
      return { type: type === 'E' ? 'erreur' : 'avis', champs };
    }
    case 'A': return { type: 'notification', pid: r.int32(), canal: r.chaine(), charge: r.chaine() };
    default: return { type: 'inconnu', octetType: type, corps };
  }
}

/**
 * Découpe un flux d'octets en messages complets.
 * Renvoie les messages décodés et le reliquat non consommé.
 */
function decouper(tampon) {
  const messages = [];
  let pos = 0;
  while (tampon.length - pos >= 5) {
    const type = String.fromCharCode(tampon.readUInt8(pos));
    const longueur = tampon.readInt32BE(pos + 1);
    if (tampon.length - pos < longueur + 1) break;      // message incomplet
    const corps = tampon.subarray(pos + 5, pos + 1 + longueur);
    messages.push(decoder(type, corps));
    pos += longueur + 1;
  }
  return { messages, reliquat: tampon.subarray(pos) };
}

module.exports = { Writer, Reader, client, decoder, decouper, message };
