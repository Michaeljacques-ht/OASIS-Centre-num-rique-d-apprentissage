'use strict';
/**
 * Contrat d'API du service de diffusion.
 *
 * Le préfixe est configurable : l'écosystème n'est pas homogène
 * (activity-service expose /api/v1, calendar-service expose /api). La valeur
 * définitive doit être confirmée avec l'équipe du gateway.
 */
const { Routeur } = require('../utils/http');
const env = require('../config/env');
const { authentifier, exigerRole } = require('../middleware/auth.middleware');
const { contexteTenant } = require('../middleware/tenant.middleware');

const ressources = require('../controllers/ressources.controller');
const travaux = require('../controllers/travaux.controller');
const documents = require('../controllers/documents.controller');
const qr = require('../controllers/qr.controller');

const routeur = new Routeur(env.prefixeApi);

/* --- Ouvert : ce qui doit fonctionner sans compte ------------------------- */
// Une ressource scannée depuis un manuel imprimé s'ouvre sans authentification.
routeur.get('/public/r/:id', ressources.lienCourt);
routeur.get('/public/qr', qr.generer);
routeur.get('/public/qr/:id', qr.generer);
routeur.get('/public/documents/:cle', documents.lire);
routeur.get('/sante', async (req, res) => {
  const bd = require('../config/database');
  require('../utils/http').ok(res, { service: 'diffusion-service', socle: bd.socle(), etat: 'ok' });
});

/* --- Authentifié : fonds documentaire ------------------------------------ */
// L'école n'est pas exigée : un compte sans école (éditeur, modérateur)
// consulte le fonds commun.
const authLecture = [authentifier(), contexteTenant(false)];
routeur.get('/ressources', ...authLecture, ressources.lister);
routeur.get('/ressources/familles', ...authLecture, ressources.familles);
routeur.get('/ressources/:id', ...authLecture, ressources.detail);
routeur.get('/documents/:cle', ...authLecture, documents.lire);

/* --- Authentifié : travail de classe, cloisonné par école ---------------- */
const authClasse = [authentifier(), contexteTenant(true)];
routeur.get('/travaux-diriges', ...authClasse, travaux.lister);
routeur.get('/travaux-diriges/:id', ...authClasse, travaux.detail);
routeur.post('/travaux-diriges', ...authClasse, exigerRole('enseignant', 'editeur'), travaux.creer);

module.exports = { routeur };
