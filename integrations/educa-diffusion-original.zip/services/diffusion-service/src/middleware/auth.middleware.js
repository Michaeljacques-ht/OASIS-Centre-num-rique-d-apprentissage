'use strict';
/**
 * Vérification du jeton émis par le gateway.
 *
 * Le service ne délivre aucun jeton : il vérifie celui que porte la requête.
 * Deux algorithmes sont acceptés, HS256 et RS256, selon la configuration.
 *
 * ATTENTION — le nom exact des revendications (sub, role, school_id,
 * academic_year_id) doit être confronté au contrat réel du gateway EDUCA
 * avant toute mise en service. Les valeurs ci-dessous sont celles décrites
 * dans le contexte de développement, pas un contrat vérifié.
 */
const crypto = require('crypto');
const env = require('../config/env');
const { ErreurHttp } = require('../utils/http');

const base64url = (b) => Buffer.from(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const depuisBase64url = (s) => Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/'), 'base64');

/** Vérifie la signature et les dates d'un jeton JWT. */
function verifierJeton(jeton) {
  const parts = jeton.split('.');
  if (parts.length !== 3) throw new ErreurHttp(401, 'JETON_MALFORME', 'jeton illisible');
  const [enTeteB64, chargeB64, signatureB64] = parts;

  let enTete;
  try { enTete = JSON.parse(depuisBase64url(enTeteB64).toString('utf8')); }
  catch { throw new ErreurHttp(401, 'JETON_MALFORME', 'en-tête illisible'); }

  const signe = `${enTeteB64}.${chargeB64}`;
  const signature = depuisBase64url(signatureB64);

  if (enTete.alg === 'HS256') {
    if (!env.jwtSecret) throw new ErreurHttp(500, 'CONFIG', 'JWT_SECRET non configuré');
    const attendue = crypto.createHmac('sha256', env.jwtSecret).update(signe).digest();
    if (signature.length !== attendue.length || !crypto.timingSafeEqual(signature, attendue)) {
      throw new ErreurHttp(401, 'SIGNATURE_INVALIDE', 'signature du jeton invalide');
    }
  } else if (enTete.alg === 'RS256') {
    if (!env.jwtClePublique) throw new ErreurHttp(500, 'CONFIG', 'JWT_PUBLIC_KEY non configurée');
    const valide = crypto.createVerify('RSA-SHA256').update(signe).verify(env.jwtClePublique, signature);
    if (!valide) throw new ErreurHttp(401, 'SIGNATURE_INVALIDE', 'signature du jeton invalide');
  } else {
    // « alg: none » et consorts : refus explicite.
    throw new ErreurHttp(401, 'ALGORITHME_REFUSE', `algorithme non accepté : ${enTete.alg}`);
  }

  let charge;
  try { charge = JSON.parse(depuisBase64url(chargeB64).toString('utf8')); }
  catch { throw new ErreurHttp(401, 'JETON_MALFORME', 'charge illisible'); }

  const maintenant = Math.floor(Date.now() / 1000);
  if (charge.exp && charge.exp < maintenant) throw new ErreurHttp(401, 'JETON_EXPIRE', 'jeton expiré');
  if (charge.nbf && charge.nbf > maintenant) throw new ErreurHttp(401, 'JETON_PAS_ENCORE_VALIDE', 'jeton pas encore valide');
  if (env.jwtEmetteur && charge.iss !== env.jwtEmetteur) {
    throw new ErreurHttp(401, 'EMETTEUR_REFUSE', 'émetteur du jeton inattendu');
  }
  return charge;
}

/** Identité de développement, uniquement hors production. */
function identiteDeveloppement(req) {
  const entete = req.headers['x-dev-identite'];
  if (!entete) return null;
  try { return JSON.parse(Buffer.from(entete, 'base64').toString('utf8')); }
  catch { return null; }
}

const authentifier = (obligatoire = true) => (req) => {
  const entete = req.headers.authorization || '';
  const jeton = entete.startsWith('Bearer ') ? entete.slice(7) : null;

  if (jeton) {
    req.identite = verifierJeton(jeton);
  } else if (!env.production && !env.jwtSecret && !env.jwtClePublique) {
    // L'identité de développement n'est acceptée que si aucun contrat JWT
    // n'est configuré : dès qu'une clé existe, seul un jeton signé passe.
    req.identite = identiteDeveloppement(req);
  }

  if (!req.identite && obligatoire) {
    throw new ErreurHttp(401, 'NON_AUTHENTIFIE', 'jeton d’authentification requis');
  }
};

/** Restreint une route à certains rôles. */
const exigerRole = (...roles) => (req) => {
  const role = req.identite && req.identite.role;
  if (!roles.includes(role)) {
    throw new ErreurHttp(403, 'ROLE_INSUFFISANT', `rôle requis : ${roles.join(', ')}`);
  }
};

module.exports = { authentifier, exigerRole, verifierJeton, base64url };
