'use strict';
/** Conversion des exceptions en réponses JSON, sans fuite de trace technique. */
const { erreur } = require('../utils/http');
const env = require('../config/env');

function gererErreur(res, e, contexte = {}) {
  const statut = e.statut || (e.name === 'ErreurPg' ? 500 : 500);
  const code = e.code || 'ERREUR_INTERNE';

  if (statut >= 500) {
    console.error('[erreur]', contexte.methode, contexte.chemin, '—', e.message, e.stack ? `\n${e.stack.split('\n')[1]}` : '');
    return erreur(res, statut, 'ERREUR_INTERNE', 'erreur interne du service');
  }
  return erreur(res, statut, code, e.message, env.production ? undefined : e.details);
}

module.exports = { gererErreur };
