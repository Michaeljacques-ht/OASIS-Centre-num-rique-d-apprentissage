'use strict';
/**
 * Contexte de cloisonnement.
 *
 * Règle absolue de l'écosystème : l'école et l'année académique proviennent
 * du jeton vérifié, jamais d'un paramètre de requête. Un school_id envoyé par
 * le navigateur est ignoré, et sa présence est signalée comme tentative.
 */
const { ErreurHttp } = require('../utils/http');

const CYCLES = ['maternelle', 'primaire', 'secondaire'];

const contexteTenant = (exigerEcole = true) => (req) => {
  const i = req.identite || {};
  const ecoleId = i.school_id || i.ecole_id || null;
  const anneeId = i.academic_year_id || i.annee_academique_id || null;

  // Un identifiant d'école transmis par le client est refusé, jamais utilisé.
  const revendique = (req.query && (req.query.school_id || req.query.ecole_id)) || null;
  if (revendique && revendique !== ecoleId) {
    throw new ErreurHttp(403, 'TENANT_REFUSE',
      'l’identifiant d’école ne peut pas être fourni par le client');
  }

  if (exigerEcole && !ecoleId) {
    throw new ErreurHttp(403, 'ECOLE_ABSENTE', 'le jeton ne porte aucune école');
  }

  const cycle = req.query && req.query.cycle ? String(req.query.cycle) : null;
  if (cycle && !CYCLES.includes(cycle)) {
    throw new ErreurHttp(400, 'CYCLE_INVALIDE', `cycle attendu parmi : ${CYCLES.join(', ')}`);
  }

  req.contexte = {
    utilisateurId: i.sub || i.user_id || null,
    role: i.role || null,
    ecoleId,
    anneeAcademiqueId: anneeId,
    cycle,
  };
};

module.exports = { contexteTenant, CYCLES };
