'use strict';
/**
 * Configuration du service. Aucune valeur inventée : les variables sans
 * valeur par défaut évidente doivent être fournies par l'exploitant.
 */
const requis = (nom, aide) => {
  const v = process.env[nom];
  if (!v) {
    console.error(`[config] ${nom} manquant. ${aide}`);
    process.exit(1);
  }
  return v;
};

module.exports = {
  // Le port n'a pas de valeur par défaut : il doit être attribué par
  // l'écosystème, comme 3001 pour ecole-service ou 8103 pour activity-service.
  port: () => Number(requis('PORT', 'Numéro à attribuer dans le plan de ports EDUCA.')),
  prefixeApi: process.env.API_PREFIX || '/api/v1',
  urlBase: process.env.BASE_URL || '',
  databaseUrl: process.env.DATABASE_URL || '',
  tailleReserve: Number(process.env.DB_POOL) || 4,
  // Contrat d'authentification du gateway — à confirmer avant intégration.
  jwtSecret: process.env.JWT_SECRET || '',
  jwtClePublique: process.env.JWT_PUBLIC_KEY || '',
  jwtEmetteur: process.env.JWT_ISSUER || '',
  environnement: process.env.NODE_ENV || 'development',
  production: process.env.NODE_ENV === 'production',
};
