'use strict';
/**
 * Accès à PostgreSQL, via le client écrit pour le projet (src/utils/pg).
 * Sans DATABASE_URL, le service bascule sur les collections JSON : le projet
 * reste lançable sans serveur de base pour le développement et la recette.
 */
const fs = require('fs');
const path = require('path');
const pg = require('../utils/pg');
const env = require('./env');

const DOSSIER_JSON = path.join(__dirname, '..', '..', '..', '..', 'data');

let reserve = null;
let socle = 'json';

function initialiser(url = env.databaseUrl) {
  if (!url) { socle = 'json'; return socle; }
  reserve = pg.reserve(url, { taille: env.tailleReserve });
  socle = 'postgres';
  return socle;
}

const estPostgres = () => socle === 'postgres';
const bd = () => {
  if (!reserve) throw new Error('PostgreSQL non initialisé (DATABASE_URL absent)');
  return reserve;
};

const requete = (sql, params) => bd().requete(sql, params);
const transaction = (travail) => bd().transaction(travail);

/** Repli : lecture d'une collection JSON. */
function lireJson(collection, defaut = []) {
  try {
    return JSON.parse(fs.readFileSync(path.join(DOSSIER_JSON, `${collection}.json`), 'utf8'));
  } catch (e) {
    if (e.code !== 'ENOENT') console.error(`[bd] ${collection} illisible :`, e.message);
    return defaut;
  }
}

async function fermer() { if (reserve) await reserve.fermer(); }

module.exports = { initialiser, estPostgres, socle: () => socle, bd, requete, transaction, lireJson, fermer };
