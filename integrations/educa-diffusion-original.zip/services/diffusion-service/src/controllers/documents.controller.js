'use strict';
const depot = require('../repositories/documents.repository');
const { ok } = require('../utils/http');
const { ErreurHttp } = require('../utils/http');

/** Clés exposées en lecture : liste fermée, pour ne pas ouvrir la table entière. */
const PUBLIQUES = new Set([
  'nav', 'accueil', 'tableau-de-bord', 'methodologiques-eleve',
  'methodologiques-enseignant', 'ressources-eleves', 'ressources-pedagogiques-meta',
]);

const lire = async (req, res) => {
  const { cle } = req.params;
  if (!PUBLIQUES.has(cle)) throw new ErreurHttp(404, 'DOCUMENT_INCONNU', 'document inconnu');
  ok(res, await depot.parCle(cle, {}));
};

module.exports = { lire, PUBLIQUES };
