'use strict';
const service = require('../services/travaux.service');
const { ok, cree, lireCorps } = require('../utils/http');

const lister = async (req, res) => {
  const { discipline, niveau, difficulte, q, limite, decalage } = req.query;
  const { elements, total } = await service.lister(
    req.contexte, { discipline, niveau, difficulte }, { recherche: q, limite, decalage }
  );
  ok(res, elements, { total, limite: Number(limite) || 50, decalage: Number(decalage) || 0 });
};

const detail = async (req, res) => ok(res, await service.detail(req.contexte, req.params.id));

const creer = async (req, res) => {
  const corps = await lireCorps(req);
  cree(res, await service.creer(req.contexte, corps));
};

module.exports = { lister, detail, creer };
