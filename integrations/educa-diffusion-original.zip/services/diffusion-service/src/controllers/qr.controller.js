'use strict';
/** Génération des QR codes : cœur du lien imprimé-numérique. */
const fs = require('fs');
const path = require('path');
const qr = require('../utils/qr');
const env = require('../config/env');
const { ErreurHttp } = require('../utils/http');

const CHEMIN_LOGO = path.join(__dirname, '..', '..', '..', '..', 'frontend', 'public', 'img', 'logo.svg');
let logoDataUri = null;
const logo = () => {
  if (logoDataUri === null) {
    try { logoDataUri = 'data:image/svg+xml;base64,' + fs.readFileSync(CHEMIN_LOGO).toString('base64'); }
    catch { logoDataUri = ''; }
  }
  return logoDataUri;
};

const generer = async (req, res) => {
  const texte = req.query.texte || (req.params.id ? `${env.urlBase}/r/${req.params.id}` : null);
  if (!texte) throw new ErreurHttp(400, 'TEXTE_MANQUANT', 'paramètre « texte » requis');

  const taille = Math.min(1024, Math.max(80, Number(req.query.taille) || 200));
  let image;
  try {
    image = qr.svg(texte, { size: taille, logo: req.query.logo ? logo() : null });
  } catch (e) {
    throw new ErreurHttp(413, 'CONTENU_TROP_LONG', e.message);
  }

  const entetes = {
    'Content-Type': 'image/svg+xml',
    'Cache-Control': 'public, max-age=86400',
    'X-Content-Type-Options': 'nosniff',
  };
  if (req.query.telecharger) entetes['Content-Disposition'] = 'attachment; filename="qr-code.svg"';
  res.writeHead(200, entetes);
  res.end(image);
};

module.exports = { generer };
