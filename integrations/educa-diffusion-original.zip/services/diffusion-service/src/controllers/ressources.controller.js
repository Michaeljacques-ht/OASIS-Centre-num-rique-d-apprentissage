'use strict';
const service = require('../services/ressources.service');
const { ok } = require('../utils/http');

const lister = async (req, res) => {
  const { discipline, niveau, type, format, famille, public: audience, q, limite, decalage } = req.query;
  const { elements, total } = await service.lister(
    req.contexte,
    { discipline, niveau, type, format, famille, public: audience },
    { recherche: q, limite, decalage }
  );
  ok(res, elements, { total, limite: Number(limite) || 50, decalage: Number(decalage) || 0 });
};

const detail = async (req, res) => ok(res, await service.detail(req.contexte, req.params.id));
const familles = async (req, res) => ok(res, await service.familles());
const lienCourt = async (req, res) => ok(res, await service.resoudreLienCourt(req.params.id));

module.exports = { lister, detail, familles, lienCourt };
