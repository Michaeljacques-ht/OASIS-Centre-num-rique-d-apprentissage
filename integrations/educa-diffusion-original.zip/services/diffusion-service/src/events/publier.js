'use strict';
/**
 * Publication d'événements métier.
 *
 * L'écosystème EDUCA utilise des échanges asynchrones entre services
 * (activity-service → calendar-service → communication-core-service).
 * Le transport réel — file, bus, webhook — n'est pas décrit dans le contexte
 * de développement : il n'est donc pas inventé ici. Les événements sont
 * journalisés et prêts à être branchés sur le transport retenu.
 */
const abonnes = [];

function publier(nom, charge) {
  const evenement = { nom, charge, au: new Date().toISOString(), source: 'diffusion-service' };
  for (const a of abonnes) {
    try { a(evenement); } catch (e) { console.error('[evenement] abonné en erreur :', e.message); }
  }
  if (process.env.EVENEMENTS_JOURNAL === '1') console.log('[evenement]', JSON.stringify(evenement));
  return evenement;
}

const abonner = (fn) => { abonnes.push(fn); return () => abonnes.splice(abonnes.indexOf(fn), 1); };

module.exports = { publier, abonner };
