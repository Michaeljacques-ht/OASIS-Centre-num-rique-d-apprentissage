'use strict';
/** Logique métier du fonds documentaire. */
const depot = require('../repositories/ressources.repository');
const documents = require('../repositories/documents.repository');
const { publier } = require('../events/publier');
const { ErreurHttp } = require('../utils/http');

const lister = (contexte, filtres, options) => depot.lister(contexte, filtres, options);

async function detail(contexte, id) {
  const r = await depot.parId(contexte, id);
  if (!r) throw new ErreurHttp(404, 'RESSOURCE_INTROUVABLE', 'ressource introuvable');
  return r;
}

/**
 * Résolution d'une adresse courte imprimée sur un manuel.
 * Une ressource retirée ne renvoie jamais 404 : des exemplaires en circulation
 * pointent vers elle. Elle renvoie son chapitre de remplacement.
 */
async function resoudreLienCourt(id) {
  const r = await depot.parLienCourt(id);
  if (!r) throw new ErreurHttp(404, 'LIEN_INCONNU', 'adresse courte inconnue');
  await depot.compterScan(id).catch(() => {});
  publier('ressource.scannee', { ressourceId: id });
  if (r.statut === 'archivee' || r.statut === 'redirigee') {
    return { ...r, redirection: { motif: r.statut, chapitre: r.chapitre || null } };
  }
  return r;
}

const familles = () => documents.parCle('ressources-pedagogiques-meta', {});

module.exports = { lister, detail, resoudreLienCourt, familles };
