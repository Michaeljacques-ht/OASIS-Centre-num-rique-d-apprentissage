'use strict';
/** Logique métier des travaux dirigés. */
const depot = require('../repositories/travaux.repository');
const { valider } = require('../validators/travaux.validator');
const { publier } = require('../events/publier');
const { ErreurHttp } = require('../utils/http');

const lister = (contexte, filtres, options) => depot.lister(contexte, filtres, options);

async function detail(contexte, id) {
  const t = await depot.parId(contexte, id);
  if (!t) throw new ErreurHttp(404, 'TRAVAIL_INTROUVABLE', 'travail dirigé introuvable');
  return t;
}

async function creer(contexte, corps) {
  const travail = valider(corps);
  travail.id = `trv_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  const cree = await depot.creer(contexte, travail);
  publier('travail.cree', {
    travailId: cree.id, ecoleId: contexte.ecoleId,
    anneeAcademiqueId: contexte.anneeAcademiqueId, auteurId: contexte.utilisateurId,
  });
  return cree;
}

module.exports = { lister, detail, creer };
