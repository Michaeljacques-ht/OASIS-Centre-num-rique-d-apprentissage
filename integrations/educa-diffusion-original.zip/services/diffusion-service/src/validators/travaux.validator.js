'use strict';
const { ErreurHttp } = require('../utils/http');
const { CYCLES } = require('../middleware/tenant.middleware');

const NIVEAUX = /^(Maternelle|Primaire|Secondaire)\s?[1-6]?$/i;

function valider(corps = {}) {
  const details = {};
  const texte = (cle, max, obligatoire = true) => {
    const v = corps[cle];
    if (!v || typeof v !== 'string' || !v.trim()) {
      if (obligatoire) details[cle] = 'champ obligatoire';
      return null;
    }
    if (v.length > max) details[cle] = `au plus ${max} caractères`;
    return v.trim();
  };

  const travail = {
    titre: texte('titre', 200),
    discipline: texte('discipline', 80),
    niveau: texte('niveau', 40),
    cycle: texte('cycle', 20),
    chapitre: texte('chapitre', 120, false),
    difficulte: texte('difficulte', 20, false),
    classeId: texte('classeId', 60, false),
    exercices: Number(corps.exercices) || 0,
    duree: corps.duree === undefined ? null : Number(corps.duree),
    icon: typeof corps.icon === 'string' ? corps.icon : 'file',
    tone: typeof corps.tone === 'string' ? corps.tone : 'blue',
  };

  if (travail.cycle && !CYCLES.includes(travail.cycle)) {
    details.cycle = `attendu parmi : ${CYCLES.join(', ')}`;
  }
  if (travail.niveau && !NIVEAUX.test(travail.niveau)) {
    details.niveau = 'niveau non reconnu (ex. « Secondaire 3 »)';
  }
  if (travail.exercices < 0 || travail.exercices > 200) details.exercices = 'entre 0 et 200';
  if (travail.duree !== null && (Number.isNaN(travail.duree) || travail.duree < 0)) {
    details.duree = 'durée en minutes, positive';
  }
  if (Object.keys(details).length) {
    throw new ErreurHttp(422, 'VALIDATION', 'données invalides', details);
  }
  return travail;
}

module.exports = { valider };
