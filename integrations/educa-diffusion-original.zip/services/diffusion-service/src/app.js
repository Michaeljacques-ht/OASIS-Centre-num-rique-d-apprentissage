'use strict';
/** Assemblage du service : journalisation, routage, gestion des erreurs. */
const { Routeur, erreur } = require('./utils/http');
const { routeur } = require('./routes/v1.routes');
const { gererErreur } = require('./middleware/erreurs.middleware');

function creerApplication() {
  return async function traiter(req, res) {
    const debut = process.hrtime.bigint();
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

    try {
      const traitee = await routeur.traiter(req, res, url);
      if (!traitee) erreur(res, 404, 'ROUTE_INCONNUE', `aucune route pour ${req.method} ${url.pathname}`);
    } catch (e) {
      gererErreur(res, e, { methode: req.method, chemin: url.pathname });
    } finally {
      const ms = Number(process.hrtime.bigint() - debut) / 1e6;
      if (process.env.JOURNAL_HTTP !== '0') {
        console.log(`${req.method} ${url.pathname} ${res.statusCode} ${ms.toFixed(1)}ms`);
      }
    }
  };
}

module.exports = { creerApplication, Routeur };
