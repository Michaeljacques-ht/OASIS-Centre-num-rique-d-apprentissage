-- ============================================================================
-- 002 — Alignement sur l'architecture EDUCA
--
-- Deux corrections imposées par le contexte de développement de l'écosystème :
--
--  1. Frontières de service. Les utilisateurs appartiennent à
--     utilisateur-service, les écoles et les classes à ecole-service. Le
--     service de diffusion ne doit pas posséder ces tables : il ne conserve
--     que des identifiants de référence, sans clé étrangère inter-service.
--
--  2. Cloisonnement. Toute donnée de travail scolaire porte ecole_id,
--     annee_academique_id et cycle. Le fonds documentaire commun fait
--     exception et porte une visibilité explicite (voir plus bas).
-- ============================================================================

BEGIN;

-- --- 1. Retrait des domaines appartenant à d'autres services ---------------
ALTER TABLE ressources        DROP CONSTRAINT IF EXISTS ressources_auteur_id_fkey;
ALTER TABLE travaux_diriges   DROP CONSTRAINT IF EXISTS travaux_diriges_auteur_id_fkey;
ALTER TABLE depots            DROP CONSTRAINT IF EXISTS depots_auteur_id_fkey;
ALTER TABLE depots            DROP CONSTRAINT IF EXISTS depots_decide_par_fkey;
ALTER TABLE favoris           DROP CONSTRAINT IF EXISTS favoris_utilisateur_id_fkey;

DROP TABLE IF EXISTS classes;
DROP TABLE IF EXISTS etablissements CASCADE;
DROP TABLE IF EXISTS utilisateurs  CASCADE;

COMMENT ON COLUMN ressources.auteur_id IS
  'Identifiant utilisateur-service. Aucune clé étrangère : domaine d''un autre service.';

-- --- 2. Cloisonnement multi-école ------------------------------------------
-- Visibilité d'une ressource :
--   commun → fonds partagé par tout l'écosystème (contenus édités et validés)
--   ecole  → visible des seuls comptes de ecole_id
--   prive  → visible du seul auteur
ALTER TABLE ressources
  ADD COLUMN IF NOT EXISTS ecole_id   TEXT,
  ADD COLUMN IF NOT EXISTS cycle      TEXT,
  ADD COLUMN IF NOT EXISTS visibilite TEXT NOT NULL DEFAULT 'commun';

ALTER TABLE ressources DROP CONSTRAINT IF EXISTS ressources_visibilite_valide;
ALTER TABLE ressources ADD  CONSTRAINT ressources_visibilite_valide
  CHECK (visibilite IN ('commun', 'ecole', 'prive'));

ALTER TABLE ressources DROP CONSTRAINT IF EXISTS ressources_cycle_valide;
ALTER TABLE ressources ADD  CONSTRAINT ressources_cycle_valide
  CHECK (cycle IS NULL OR cycle IN ('maternelle', 'primaire', 'secondaire'));

-- Une ressource non commune doit nommer son école : sans quoi le filtrage
-- de cloisonnement la rendrait invisible ou, pire, visible de tous.
ALTER TABLE ressources DROP CONSTRAINT IF EXISTS ressources_ecole_obligatoire;
ALTER TABLE ressources ADD  CONSTRAINT ressources_ecole_obligatoire
  CHECK (visibilite = 'commun' OR ecole_id IS NOT NULL);

ALTER TABLE travaux_diriges
  ADD COLUMN IF NOT EXISTS ecole_id             TEXT,
  ADD COLUMN IF NOT EXISTS annee_academique_id  TEXT,
  ADD COLUMN IF NOT EXISTS cycle                TEXT,
  ADD COLUMN IF NOT EXISTS classe_id            TEXT;

ALTER TABLE travaux_diriges DROP CONSTRAINT IF EXISTS td_cycle_valide;
ALTER TABLE travaux_diriges ADD  CONSTRAINT td_cycle_valide
  CHECK (cycle IS NULL OR cycle IN ('maternelle', 'primaire', 'secondaire'));

ALTER TABLE depots  ADD COLUMN IF NOT EXISTS ecole_id TEXT;
ALTER TABLE favoris ADD COLUMN IF NOT EXISTS ecole_id TEXT;
ALTER TABLE journal_audit
  ADD COLUMN IF NOT EXISTS ecole_id            TEXT,
  ADD COLUMN IF NOT EXISTS annee_academique_id TEXT;

-- --- 3. Index de cloisonnement ---------------------------------------------
CREATE INDEX IF NOT EXISTS idx_ressources_visibilite ON ressources(visibilite, ecole_id);
CREATE INDEX IF NOT EXISTS idx_ressources_cycle      ON ressources(cycle);
CREATE INDEX IF NOT EXISTS idx_td_tenant             ON travaux_diriges(ecole_id, annee_academique_id);
CREATE INDEX IF NOT EXISTS idx_td_classe             ON travaux_diriges(classe_id);
CREATE INDEX IF NOT EXISTS idx_depots_ecole          ON depots(ecole_id);
CREATE INDEX IF NOT EXISTS idx_audit_ecole           ON journal_audit(ecole_id, au DESC);

COMMIT;
