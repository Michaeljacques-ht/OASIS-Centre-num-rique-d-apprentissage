-- ============================================================================
-- 005 — Laboratoire numérique et communauté.
-- ============================================================================

BEGIN;

-- --- Laboratoires ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS laboratoires (
  id          TEXT PRIMARY KEY,
  titre       TEXT NOT NULL,
  resume      TEXT,
  discipline  TEXT,
  niveau      TEXT,
  cycle       TEXT,
  type        TEXT NOT NULL DEFAULT 'guidee',
  scenario    JSONB NOT NULL DEFAULT '{}'::jsonb,
  duree       INTEGER,
  image       TEXT,
  visibilite  TEXT NOT NULL DEFAULT 'commun',
  ecole_id    TEXT,
  statut      TEXT NOT NULL DEFAULT 'brouillon',
  auteur_id   TEXT,
  vues        INTEGER NOT NULL DEFAULT 0,
  cree_le     TIMESTAMPTZ NOT NULL DEFAULT now(),
  modifie_le  TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE laboratoires DROP CONSTRAINT IF EXISTS laboratoires_type_valide;
ALTER TABLE laboratoires ADD  CONSTRAINT laboratoires_type_valide
  CHECK (type IN ('experience_guidee', 'exploration_libre', 'simulation_theorique', 'demo_interactive', 'guidee'));

ALTER TABLE laboratoires DROP CONSTRAINT IF EXISTS laboratoires_visibilite_valide;
ALTER TABLE laboratoires ADD  CONSTRAINT laboratoires_visibilite_valide
  CHECK (visibilite IN ('commun', 'ecole', 'prive'));

ALTER TABLE laboratoires DROP CONSTRAINT IF EXISTS laboratoires_ecole_obligatoire;
ALTER TABLE laboratoires ADD  CONSTRAINT laboratoires_ecole_obligatoire
  CHECK (visibilite = 'commun' OR ecole_id IS NOT NULL);

ALTER TABLE laboratoires DROP CONSTRAINT IF EXISTS laboratoires_cycle_valide;
ALTER TABLE laboratoires ADD  CONSTRAINT laboratoires_cycle_valide
  CHECK (cycle IS NULL OR cycle IN ('maternelle', 'primaire', 'secondaire'));

DROP TRIGGER IF EXISTS trg_laboratoires_modifie ON laboratoires;
CREATE TRIGGER trg_laboratoires_modifie BEFORE UPDATE ON laboratoires
  FOR EACH ROW EXECUTE FUNCTION maj_modifie_le();

CREATE INDEX IF NOT EXISTS idx_laboratoires_discipline ON laboratoires(discipline, cycle);
CREATE INDEX IF NOT EXISTS idx_laboratoires_visibilite ON laboratoires(visibilite, ecole_id);

CREATE TABLE IF NOT EXISTS laboratoire_sessions (
  id             TEXT PRIMARY KEY,
  laboratoire_id TEXT NOT NULL REFERENCES laboratoires(id) ON DELETE CASCADE,
  utilisateur_id TEXT NOT NULL,
  ecole_id       TEXT,
  debut          TIMESTAMPTZ NOT NULL DEFAULT now(),
  fin            TIMESTAMPTZ,
  mesures        JSONB NOT NULL DEFAULT '{}'::jsonb,
  CONSTRAINT session_duree_coherente CHECK (fin IS NULL OR fin >= debut)
);
CREATE INDEX IF NOT EXISTS idx_lab_sessions_labo  ON laboratoire_sessions(laboratoire_id);
CREATE INDEX IF NOT EXISTS idx_lab_sessions_ecole ON laboratoire_sessions(ecole_id, debut DESC);

-- --- Groupes -------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS groupes (
  id                  TEXT PRIMARY KEY,
  nom                 TEXT NOT NULL,
  description         TEXT,
  type                TEXT NOT NULL,
  ecole_id            TEXT NOT NULL,
  annee_academique_id TEXT,
  classe_id           TEXT,
  cree_par            TEXT,
  archive             BOOLEAN NOT NULL DEFAULT false,
  cree_le             TIMESTAMPTZ NOT NULL DEFAULT now(),
  derniere_activite   TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE groupes DROP CONSTRAINT IF EXISTS groupes_type_valide;
ALTER TABLE groupes ADD  CONSTRAINT groupes_type_valide
  CHECK (type IN ('classe', 'collaboratif', 'personnel', 'etude'));

CREATE INDEX IF NOT EXISTS idx_groupes_tenant ON groupes(ecole_id, annee_academique_id);
CREATE INDEX IF NOT EXISTS idx_groupes_type   ON groupes(type, archive);

CREATE TABLE IF NOT EXISTS groupe_membres (
  groupe_id      TEXT NOT NULL REFERENCES groupes(id) ON DELETE CASCADE,
  utilisateur_id TEXT NOT NULL,
  role           TEXT NOT NULL DEFAULT 'membre',
  rejoint_le     TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (groupe_id, utilisateur_id)
);

ALTER TABLE groupe_membres DROP CONSTRAINT IF EXISTS membres_role_valide;
ALTER TABLE groupe_membres ADD  CONSTRAINT membres_role_valide
  CHECK (role IN ('animateur', 'membre'));

CREATE INDEX IF NOT EXISTS idx_membres_utilisateur ON groupe_membres(utilisateur_id);

-- --- Forum ----------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sujets (
  id         TEXT PRIMARY KEY,
  categorie  TEXT NOT NULL,
  titre      TEXT NOT NULL,
  auteur_id  TEXT NOT NULL,
  groupe_id  TEXT REFERENCES groupes(id) ON DELETE CASCADE,
  ecole_id   TEXT,
  resolu     BOOLEAN NOT NULL DEFAULT false,
  epingle    BOOLEAN NOT NULL DEFAULT false,
  vues       INTEGER NOT NULL DEFAULT 0,
  cree_le    TIMESTAMPTZ NOT NULL DEFAULT now(),
  modifie_le TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_sujets_categorie ON sujets(categorie, cree_le DESC);
CREATE INDEX IF NOT EXISTS idx_sujets_groupe    ON sujets(groupe_id);
CREATE INDEX IF NOT EXISTS idx_sujets_ecole     ON sujets(ecole_id);

CREATE TABLE IF NOT EXISTS messages (
  id         TEXT PRIMARY KEY,
  sujet_id   TEXT NOT NULL REFERENCES sujets(id) ON DELETE CASCADE,
  auteur_id  TEXT NOT NULL,
  contenu    TEXT NOT NULL,
  masque     BOOLEAN NOT NULL DEFAULT false,
  reponse_a  TEXT REFERENCES messages(id) ON DELETE SET NULL,
  cree_le    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_messages_sujet    ON messages(sujet_id, cree_le);
CREATE INDEX IF NOT EXISTS idx_messages_reponse  ON messages(reponse_a);

-- --- Signalements et annonces -------------------------------------------------
CREATE TABLE IF NOT EXISTS signalements (
  id          TEXT PRIMARY KEY,
  objet_type  TEXT NOT NULL,
  objet_id    TEXT NOT NULL,
  auteur_id   TEXT NOT NULL,
  motif       TEXT NOT NULL,
  statut      TEXT NOT NULL DEFAULT 'ouvert',
  traite_par  TEXT,
  traite_le   TIMESTAMPTZ,
  cree_le     TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE signalements DROP CONSTRAINT IF EXISTS signalements_objet_valide;
ALTER TABLE signalements ADD  CONSTRAINT signalements_objet_valide
  CHECK (objet_type IN ('ressource', 'message', 'sujet', 'laboratoire'));

ALTER TABLE signalements DROP CONSTRAINT IF EXISTS signalements_statut_valide;
ALTER TABLE signalements ADD  CONSTRAINT signalements_statut_valide
  CHECK (statut IN ('ouvert', 'retenu', 'rejete'));

ALTER TABLE signalements DROP CONSTRAINT IF EXISTS signalements_traitement_complet;
ALTER TABLE signalements ADD  CONSTRAINT signalements_traitement_complet
  CHECK (statut = 'ouvert' OR (traite_par IS NOT NULL AND traite_le IS NOT NULL));

CREATE INDEX IF NOT EXISTS idx_signalements_statut ON signalements(statut, cree_le);
CREATE INDEX IF NOT EXISTS idx_signalements_objet  ON signalements(objet_type, objet_id);

CREATE TABLE IF NOT EXISTS annonces (
  id                  TEXT PRIMARY KEY,
  titre               TEXT NOT NULL,
  contenu             TEXT NOT NULL,
  auteur_id           TEXT NOT NULL,
  ecole_id            TEXT NOT NULL,
  classe_id           TEXT,
  annee_academique_id TEXT,
  publie_le           TIMESTAMPTZ NOT NULL DEFAULT now(),
  expire_le           TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_annonces_tenant ON annonces(ecole_id, publie_le DESC);

COMMIT;
