-- ============================================================================
-- 006 — Diffusion imprimée : manuels, chapitres, adresses courtes, scans.
--
-- C'est le domaine où une erreur ne se corrige pas par un correctif logiciel :
-- un QR code parti à l'impression reste en circulation des années. Le schéma
-- porte donc l'essentiel des garanties.
-- ============================================================================

BEGIN;

-- --- Manuels -------------------------------------------------------------------
ALTER TABLE manuels
  ADD COLUMN IF NOT EXISTS editeur_id    TEXT,
  ADD COLUMN IF NOT EXISTS annee_edition INTEGER,
  ADD COLUMN IF NOT EXISTS statut        TEXT NOT NULL DEFAULT 'prepare',
  ADD COLUMN IF NOT EXISTS cree_le       TIMESTAMPTZ NOT NULL DEFAULT now();

ALTER TABLE manuels DROP CONSTRAINT IF EXISTS manuels_statut_valide;
ALTER TABLE manuels ADD  CONSTRAINT manuels_statut_valide
  CHECK (statut IN ('prepare', 'imprime', 'epuise'));

CREATE TABLE IF NOT EXISTS chapitres (
  id        TEXT PRIMARY KEY,
  manuel_id TEXT NOT NULL REFERENCES manuels(id) ON DELETE CASCADE,
  position  INTEGER NOT NULL,
  titre     TEXT NOT NULL,
  page      INTEGER,
  UNIQUE (manuel_id, position)
);
CREATE INDEX IF NOT EXISTS idx_chapitres_manuel ON chapitres(manuel_id);

-- Une ressource peut figurer dans plusieurs manuels, un chapitre en porte
-- plusieurs : la relation est donc une table à part entière.
CREATE TABLE IF NOT EXISTS manuel_ressources (
  manuel_id    TEXT NOT NULL REFERENCES manuels(id) ON DELETE CASCADE,
  ressource_id TEXT NOT NULL REFERENCES ressources(id) ON DELETE RESTRICT,
  chapitre_id  TEXT REFERENCES chapitres(id) ON DELETE SET NULL,
  page         INTEGER,
  position     INTEGER,
  PRIMARY KEY (manuel_id, ressource_id)
);
CREATE INDEX IF NOT EXISTS idx_manuel_res_ressource ON manuel_ressources(ressource_id);
CREATE INDEX IF NOT EXISTS idx_manuel_res_chapitre  ON manuel_ressources(chapitre_id);

-- --- Adresses courtes -------------------------------------------------------
-- Le code imprimé vit dans sa propre table : une ressource peut en porter
-- plusieurs au fil des tirages, et un code retiré doit continuer de répondre.
CREATE TABLE IF NOT EXISTS liens_courts (
  code         TEXT PRIMARY KEY,
  ressource_id TEXT REFERENCES ressources(id) ON DELETE RESTRICT,
  manuel_id    TEXT REFERENCES manuels(id) ON DELETE SET NULL,
  chapitre_id  TEXT REFERENCES chapitres(id) ON DELETE SET NULL,
  tirage       TEXT,
  actif        BOOLEAN NOT NULL DEFAULT true,
  redirige_vers TEXT REFERENCES ressources(id) ON DELETE SET NULL,
  cree_le      TIMESTAMPTZ NOT NULL DEFAULT now(),
  imprime_le   DATE
);

-- Un code inactif doit dire où aller : sans cible ni redirection, un lecteur
-- se retrouve devant une page morte, un manuel à la main.
ALTER TABLE liens_courts DROP CONSTRAINT IF EXISTS lien_cible_obligatoire;
ALTER TABLE liens_courts ADD  CONSTRAINT lien_cible_obligatoire
  CHECK (ressource_id IS NOT NULL OR redirige_vers IS NOT NULL);

CREATE INDEX IF NOT EXISTS idx_liens_ressource ON liens_courts(ressource_id);
CREATE INDEX IF NOT EXISTS idx_liens_manuel    ON liens_courts(manuel_id);
CREATE INDEX IF NOT EXISTS idx_liens_redirige  ON liens_courts(redirige_vers);
CREATE INDEX IF NOT EXISTS idx_liens_chapitre  ON liens_courts(chapitre_id);

-- Un code déjà imprimé ne peut plus être supprimé, quelle qu'en soit la raison.
CREATE OR REPLACE FUNCTION interdire_suppression_lien_imprime() RETURNS trigger AS $$
BEGIN
  IF OLD.imprime_le IS NOT NULL THEN
    RAISE EXCEPTION 'le code % est imprimé depuis le % : désactivez-le ou redirigez-le, ne le supprimez pas',
      OLD.code, OLD.imprime_le;
  END IF;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_liens_suppression ON liens_courts;
CREATE TRIGGER trg_liens_suppression BEFORE DELETE ON liens_courts
  FOR EACH ROW EXECUTE FUNCTION interdire_suppression_lien_imprime();

-- --- Scans --------------------------------------------------------------------
-- Agrégat quotidien : aucune trace individuelle n'est conservée pour un
-- visiteur non connecté.
CREATE TABLE IF NOT EXISTS scans (
  code        TEXT NOT NULL REFERENCES liens_courts(code) ON DELETE CASCADE,
  jour        DATE NOT NULL DEFAULT CURRENT_DATE,
  manuel_id   TEXT,
  chapitre_id TEXT,
  nombre      INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (code, jour)
);
CREATE INDEX IF NOT EXISTS idx_scans_manuel ON scans(manuel_id, jour DESC);
CREATE INDEX IF NOT EXISTS idx_scans_jour   ON scans(jour DESC);

COMMIT;
