-- ============================================================================
-- 007 — Commerce et journalisation.
--
-- Les paiements sont délégués à la passerelle PLOP PLOP : la base conserve la
-- trace des commandes, jamais un moyen de paiement.
-- ============================================================================

BEGIN;

-- --- Commandes ------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS commandes (
  id             TEXT PRIMARY KEY,
  utilisateur_id TEXT,
  ecole_id       TEXT,
  montant_htg    NUMERIC(12,2) NOT NULL,
  methode        TEXT,
  statut         TEXT NOT NULL DEFAULT 'en_attente',
  transaction_id TEXT UNIQUE,
  cree_le        TIMESTAMPTZ NOT NULL DEFAULT now(),
  payee_le       TIMESTAMPTZ
);

ALTER TABLE commandes DROP CONSTRAINT IF EXISTS commandes_statut_valide;
ALTER TABLE commandes ADD  CONSTRAINT commandes_statut_valide
  CHECK (statut IN ('en_attente', 'payee', 'annulee', 'remboursee'));

ALTER TABLE commandes DROP CONSTRAINT IF EXISTS commandes_montant_positif;
ALTER TABLE commandes ADD  CONSTRAINT commandes_montant_positif
  CHECK (montant_htg >= 0);

-- Une commande payée porte forcément sa référence de transaction : c'est ce
-- qui rend la finalisation idempotente.
ALTER TABLE commandes DROP CONSTRAINT IF EXISTS commandes_paiement_trace;
ALTER TABLE commandes ADD  CONSTRAINT commandes_paiement_trace
  CHECK (statut <> 'payee' OR (transaction_id IS NOT NULL AND payee_le IS NOT NULL));

CREATE INDEX IF NOT EXISTS idx_commandes_utilisateur ON commandes(utilisateur_id, cree_le DESC);
CREATE INDEX IF NOT EXISTS idx_commandes_statut      ON commandes(statut);

CREATE TABLE IF NOT EXISTS commande_lignes (
  id           TEXT PRIMARY KEY,
  commande_id  TEXT NOT NULL REFERENCES commandes(id) ON DELETE CASCADE,
  objet_type   TEXT NOT NULL,
  objet_id     TEXT NOT NULL,
  libelle      TEXT NOT NULL,
  quantite     INTEGER NOT NULL DEFAULT 1,
  prix_htg     NUMERIC(12,2) NOT NULL,
  CONSTRAINT ligne_quantite_positive CHECK (quantite > 0),
  CONSTRAINT ligne_objet_valide CHECK (objet_type IN ('ressource', 'manuel', 'abonnement'))
);
CREATE INDEX IF NOT EXISTS idx_lignes_commande ON commande_lignes(commande_id);

-- --- Abonnements d'établissement --------------------------------------------
CREATE TABLE IF NOT EXISTS abonnements (
  id          TEXT PRIMARY KEY,
  ecole_id    TEXT NOT NULL,
  formule     TEXT NOT NULL,
  effectif    INTEGER,
  montant_htg NUMERIC(12,2),
  debut       DATE NOT NULL,
  fin         DATE NOT NULL,
  statut      TEXT NOT NULL DEFAULT 'actif',
  commande_id TEXT REFERENCES commandes(id) ON DELETE SET NULL,
  CONSTRAINT abonnement_periode_coherente CHECK (fin > debut),
  CONSTRAINT abonnement_formule_valide CHECK (formule IN ('libre', 'enseignant', 'etablissement', 'editeur')),
  CONSTRAINT abonnement_statut_valide CHECK (statut IN ('actif', 'suspendu', 'expire'))
);
CREATE INDEX IF NOT EXISTS idx_abonnements_ecole    ON abonnements(ecole_id, statut);
CREATE INDEX IF NOT EXISTS idx_abonnements_commande ON abonnements(commande_id);

-- --- Journal d'audit -----------------------------------------------------------
-- Fenêtre glissante de 5 000 entrées, tenue par la base.
CREATE OR REPLACE FUNCTION elaguer_journal_audit() RETURNS trigger AS $$
BEGIN
  DELETE FROM journal_audit
   WHERE id <= (SELECT max(id) - 5000 FROM journal_audit);
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_audit_elagage ON journal_audit;
CREATE TRIGGER trg_audit_elagage AFTER INSERT ON journal_audit
  FOR EACH STATEMENT EXECUTE FUNCTION elaguer_journal_audit();

-- --- Vues de lecture courante ---------------------------------------------------
-- Couverture du fonds : ce que la direction éditoriale regarde en premier,
-- parce qu'elle montre les trous du catalogue.
CREATE OR REPLACE VIEW vue_couverture_fonds AS
  SELECT discipline, niveau, cycle,
         count(*) FILTER (WHERE statut = 'publiee') AS publiees,
         count(*) FILTER (WHERE statut = 'en_verification') AS en_verification,
         sum(vues) AS vues_cumulees
    FROM ressources
   GROUP BY discipline, niveau, cycle;

-- Usage d'un manuel, par chapitre et par mois.
CREATE OR REPLACE VIEW vue_usage_manuels AS
  SELECT l.manuel_id,
         l.chapitre_id,
         date_trunc('month', s.jour)::date AS mois,
         sum(s.nombre) AS scans
    FROM scans s
    JOIN liens_courts l ON l.code = s.code
   GROUP BY l.manuel_id, l.chapitre_id, date_trunc('month', s.jour);

COMMIT;
