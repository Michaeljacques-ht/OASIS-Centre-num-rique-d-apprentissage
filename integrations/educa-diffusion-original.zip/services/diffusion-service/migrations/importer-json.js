'use strict';
/**
 * Migration des collections JSON vers PostgreSQL.
 *
 *   DATABASE_URL=postgres://… node tools/migrate-to-pg.js --schema
 *   DATABASE_URL=postgres://… node tools/migrate-to-pg.js
 *
 * --schema  applique db/schema.sql avant l'import
 * --vider   vide les tables concernées avant l'import
 *
 * L'import est idempotent : chaque enregistrement est inséré ou mis à jour
 * selon sa clé primaire. Rejouer la migration ne crée pas de doublon.
 */
const fs = require('fs');
const path = require('path');
const pg = require('../lib/pg');

const racine = path.join(__dirname, '..');
const lire = (nom) => JSON.parse(fs.readFileSync(path.join(racine, 'data', `${nom}.json`), 'utf8'));

/** Collections rangées telles quelles dans la table documents. */
const DOCUMENTS = [
  'nav', 'accueil', 'tableau-de-bord',
  'methodologiques-eleve', 'methodologiques-enseignant',
  'ressources-eleves', 'ressources-pedagogiques-meta',
];

async function principal() {
  const url = process.env.DATABASE_URL;
  if (!url) {
    console.error('DATABASE_URL non défini. Exemple :');
    console.error('  DATABASE_URL=postgres://educa:secret@localhost:5432/diffusion node tools/migrate-to-pg.js --schema');
    process.exit(1);
  }

  const bd = pg.reserve(url, { taille: 2 });
  const options = new Set(process.argv.slice(2));

  try {
    if (options.has('--schema')) {
      const schema = fs.readFileSync(path.join(racine, 'db', 'schema.sql'), 'utf8');
      await bd.requete(schema);
      console.log('schéma appliqué');
    }

    if (options.has('--vider')) {
      await bd.requete('TRUNCATE documents, favoris, usages, depots, travaux_diriges, ressources, utilisateurs RESTART IDENTITY CASCADE');
      console.log('tables vidées');
    }

    await bd.transaction(async (c) => {
      /* Documents éditoriaux */
      for (const cle of DOCUMENTS) {
        await c.requete(
          `INSERT INTO documents (cle, contenu) VALUES ($1, $2)
           ON CONFLICT (cle) DO UPDATE SET contenu = EXCLUDED.contenu, modifie_le = now()`,
          [cle, JSON.stringify(lire(cle))]
        );
      }
      console.log(`documents : ${DOCUMENTS.length} clés`);

      /* Utilisateurs */
      const users = lire('users');
      for (const u of users) {
        await c.requete(
          `INSERT INTO utilisateurs (id, role, nom, role_label, avatar, niveau, discipline, notifications, messages)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
           ON CONFLICT (id) DO UPDATE SET
             role = EXCLUDED.role, nom = EXCLUDED.nom, role_label = EXCLUDED.role_label,
             avatar = EXCLUDED.avatar, niveau = EXCLUDED.niveau, discipline = EXCLUDED.discipline,
             notifications = EXCLUDED.notifications, messages = EXCLUDED.messages`,
          [u.id, u.role, u.name || u.nom, u.roleLabel, u.avatar, u.niveau || null,
           u.discipline || null, u.notifications || 0, u.messages || 0]
        );
      }
      console.log(`utilisateurs : ${users.length}`);

      /* Ressources pédagogiques */
      const ressources = lire('ressources-pedagogiques');
      for (const r of ressources) {
        await c.requete(
          `INSERT INTO ressources
             (id, titre, famille, type, type_tone, format, format_tone, action, discipline, niveau,
              auteur, image, audience, note, avis, vues, telechargements, ajoute, lien_court, statut)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,'publiee')
           ON CONFLICT (id) DO UPDATE SET
             titre = EXCLUDED.titre, famille = EXCLUDED.famille, type = EXCLUDED.type,
             type_tone = EXCLUDED.type_tone, format = EXCLUDED.format, format_tone = EXCLUDED.format_tone,
             action = EXCLUDED.action, discipline = EXCLUDED.discipline, niveau = EXCLUDED.niveau,
             auteur = EXCLUDED.auteur, image = EXCLUDED.image, audience = EXCLUDED.audience,
             note = EXCLUDED.note, avis = EXCLUDED.avis, vues = EXCLUDED.vues,
             telechargements = EXCLUDED.telechargements, modifie_le = now()`,
          [r.id, r.titre, r.famille, r.type, r.typeTone, r.format, r.formatTone, r.action || null,
           r.discipline, r.niveau, r.auteur, r.image, r.public || 'enseignants',
           r.note, r.avis, r.vues, r.telechargements, r.ajoute, `/r/${r.id}`]
        );
      }
      console.log(`ressources : ${ressources.length}`);

      /* Travaux dirigés */
      const travaux = lire('travaux-diriges');
      for (const t of travaux) {
        await c.requete(
          `INSERT INTO travaux_diriges
             (id, titre, discipline, niveau, chapitre, exercices, difficulte, duree, icon, tone, favori, vues, cree, modifie)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
           ON CONFLICT (id) DO UPDATE SET
             titre = EXCLUDED.titre, discipline = EXCLUDED.discipline, niveau = EXCLUDED.niveau,
             chapitre = EXCLUDED.chapitre, exercices = EXCLUDED.exercices, difficulte = EXCLUDED.difficulte,
             duree = EXCLUDED.duree, icon = EXCLUDED.icon, tone = EXCLUDED.tone,
             favori = EXCLUDED.favori, vues = EXCLUDED.vues, modifie = EXCLUDED.modifie`,
          [t.id, t.titre, t.discipline, t.niveau, t.chapitre, t.exercices, t.difficulte,
           t.duree, t.icon, t.tone, t.favori, t.vues, t.cree, t.modifie]
        );
      }
      console.log(`travaux dirigés : ${travaux.length}`);
    });

    const { lignes } = await bd.requete(
      `SELECT (SELECT count(*) FROM documents) AS documents,
              (SELECT count(*) FROM utilisateurs) AS utilisateurs,
              (SELECT count(*) FROM ressources) AS ressources,
              (SELECT count(*) FROM travaux_diriges) AS travaux`
    );
    console.log('\nÉtat de la base :', lignes[0]);
    console.log('Migration terminée.');
  } finally {
    await bd.fermer();
  }
}

principal().catch((e) => { console.error('Échec de la migration :', e.message); process.exit(1); });
