-- ============================================================================
-- ÉDUCA DIFFUSION — schéma PostgreSQL
--   psql "$DATABASE_URL" -f db/schema.sql
--
-- Deux natures de données coexistent volontairement :
--   • les entités relationnelles — utilisateurs, ressources, travaux… ;
--   • les documents éditoriaux — navigation, contenu de l'accueil, catalogues
--     de familles — rangés dans une table « documents » en JSONB. Normaliser un
--     menu de navigation coûterait plus qu'il ne rapporte.
-- ============================================================================

BEGIN;

-- --- Comparaison insensible aux accents et à la casse ----------------------
-- Écrite en SQL pur plutôt qu'avec l'extension unaccent : tous les hébergeurs
-- ne l'autorisent pas, et le jeu de caractères du français tient en une ligne.
CREATE OR REPLACE FUNCTION unaccent_simple(t TEXT) RETURNS TEXT AS $$
  SELECT lower(translate(coalesce(t, ''),
    'àáâãäåçèéêëìíîïñòóôõöùúûüýÿÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝ',
    'aaaaaaceeeeiiiinooooouuuuyyAAAAAACEEEEIIIINOOOOOUUUUY'));
$$ LANGUAGE sql IMMUTABLE STRICT PARALLEL SAFE;

-- --- Documents éditoriaux ---------------------------------------------------
CREATE TABLE IF NOT EXISTS documents (
  cle          TEXT PRIMARY KEY,
  contenu      JSONB NOT NULL,
  modifie_le   TIMESTAMPTZ NOT NULL DEFAULT now()
);
COMMENT ON TABLE documents IS 'Contenus de configuration et d''édition, un par clé.';

-- --- Établissements et comptes ---------------------------------------------
CREATE TABLE IF NOT EXISTS etablissements (
  id           TEXT PRIMARY KEY,
  nom          TEXT NOT NULL,
  type         TEXT,
  departement  TEXT,
  abonnement   TEXT NOT NULL DEFAULT 'essai',
  cree_le      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS utilisateurs (
  id               TEXT PRIMARY KEY,
  role             TEXT NOT NULL CHECK (role IN ('eleve','enseignant','editeur','admin_etab','moderateur')),
  nom              TEXT NOT NULL,
  role_label       TEXT,
  email            TEXT UNIQUE,
  mot_de_passe     TEXT,                    -- scrypt : sel$condensé
  avatar           TEXT,
  niveau           TEXT,                    -- pour les élèves
  discipline       TEXT,                    -- pour les enseignants
  etablissement_id TEXT REFERENCES etablissements(id) ON DELETE SET NULL,
  notifications    INTEGER NOT NULL DEFAULT 0,
  messages         INTEGER NOT NULL DEFAULT 0,
  cree_le          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_utilisateurs_etab ON utilisateurs(etablissement_id);

CREATE TABLE IF NOT EXISTS classes (
  id               TEXT PRIMARY KEY,
  etablissement_id TEXT NOT NULL REFERENCES etablissements(id) ON DELETE CASCADE,
  nom              TEXT NOT NULL,
  niveau           TEXT NOT NULL
);

-- --- Manuels imprimés -------------------------------------------------------
CREATE TABLE IF NOT EXISTS manuels (
  id         TEXT PRIMARY KEY,
  isbn       TEXT UNIQUE,
  titre      TEXT NOT NULL,
  niveau     TEXT,
  discipline TEXT,
  chapitres  JSONB NOT NULL DEFAULT '[]'::jsonb,
  tirage     TEXT
);

-- --- Fonds documentaire -----------------------------------------------------
CREATE TABLE IF NOT EXISTS ressources (
  id              TEXT PRIMARY KEY,
  titre           TEXT NOT NULL,
  resume          TEXT,
  famille         TEXT,
  type            TEXT,
  type_tone       TEXT,
  format          TEXT,
  format_tone     TEXT,
  action          TEXT,                     -- libellé du bouton (« Commencer »)
  discipline      TEXT,
  niveau          TEXT,
  auteur          TEXT,
  auteur_id       TEXT REFERENCES utilisateurs(id) ON DELETE SET NULL,
  image           TEXT,
  audience        TEXT NOT NULL DEFAULT 'enseignants',
  statut          TEXT NOT NULL DEFAULT 'publiee'
                  CHECK (statut IN ('brouillon','en_verification','publiee','archivee','redirigee')),
  lien_court      TEXT UNIQUE,              -- gravé sur le papier : jamais réattribué
  manuel_id       TEXT REFERENCES manuels(id) ON DELETE SET NULL,
  chapitre        TEXT,
  licence         TEXT,
  note            REAL,
  avis            INTEGER NOT NULL DEFAULT 0,
  vues            INTEGER NOT NULL DEFAULT 0,
  telechargements INTEGER NOT NULL DEFAULT 0,
  ajoute          DATE NOT NULL DEFAULT CURRENT_DATE,
  modifie_le      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ressources_filtres ON ressources(discipline, niveau, type, format);
CREATE INDEX IF NOT EXISTS idx_ressources_famille ON ressources(famille);
CREATE INDEX IF NOT EXISTS idx_ressources_statut  ON ressources(statut);
CREATE INDEX IF NOT EXISTS idx_ressources_manuel  ON ressources(manuel_id);
-- Index d'expression : le filtrage de l'interface compare sans accent ni casse.
CREATE INDEX IF NOT EXISTS idx_ressources_discipline_ua ON ressources(unaccent_simple(discipline));
CREATE INDEX IF NOT EXISTS idx_ressources_niveau_ua     ON ressources(unaccent_simple(niveau));
CREATE INDEX IF NOT EXISTS idx_ressources_type_ua       ON ressources(unaccent_simple(type));
CREATE INDEX IF NOT EXISTS idx_ressources_famille_ua    ON ressources(unaccent_simple(famille));

-- Une ressource liée à un manuel imprimé ne peut pas être supprimée :
-- des QR codes en circulation pointent vers elle.
CREATE OR REPLACE FUNCTION interdire_suppression_imprimee() RETURNS trigger AS $$
BEGIN
  IF OLD.manuel_id IS NOT NULL THEN
    RAISE EXCEPTION 'ressource % liée au manuel % : archivez-la au lieu de la supprimer',
      OLD.id, OLD.manuel_id;
  END IF;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_ressources_suppression ON ressources;
CREATE TRIGGER trg_ressources_suppression
  BEFORE DELETE ON ressources
  FOR EACH ROW EXECUTE FUNCTION interdire_suppression_imprimee();

-- --- Mesure des usages ------------------------------------------------------
CREATE TABLE IF NOT EXISTS usages (
  ressource_id    TEXT NOT NULL REFERENCES ressources(id) ON DELETE CASCADE,
  jour            DATE NOT NULL DEFAULT CURRENT_DATE,
  vues            INTEGER NOT NULL DEFAULT 0,
  scans           INTEGER NOT NULL DEFAULT 0,
  telechargements INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (ressource_id, jour)
);

-- --- Contribution et modération ---------------------------------------------
CREATE TABLE IF NOT EXISTS depots (
  id           TEXT PRIMARY KEY,
  ressource_id TEXT NOT NULL REFERENCES ressources(id) ON DELETE CASCADE,
  auteur_id    TEXT REFERENCES utilisateurs(id) ON DELETE SET NULL,
  statut       TEXT NOT NULL DEFAULT 'en_verification'
               CHECK (statut IN ('en_verification','approuve','renvoye')),
  commentaire  TEXT,
  decide_par   TEXT REFERENCES utilisateurs(id) ON DELETE SET NULL,
  decide_le    TIMESTAMPTZ,
  CONSTRAINT commentaire_obligatoire_si_renvoi
    CHECK (statut <> 'renvoye' OR (commentaire IS NOT NULL AND length(btrim(commentaire)) > 0)),
  CONSTRAINT moderateur_distinct_de_auteur
    CHECK (decide_par IS NULL OR decide_par <> auteur_id)
);

-- --- Travail de classe ------------------------------------------------------
CREATE TABLE IF NOT EXISTS travaux_diriges (
  id          TEXT PRIMARY KEY,
  titre       TEXT NOT NULL,
  discipline  TEXT,
  niveau      TEXT,
  chapitre    TEXT,
  exercices   INTEGER NOT NULL DEFAULT 0,
  difficulte  TEXT,
  duree       INTEGER,
  icon        TEXT,
  tone        TEXT,
  favori      BOOLEAN NOT NULL DEFAULT false,
  vues        INTEGER NOT NULL DEFAULT 0,
  auteur_id   TEXT REFERENCES utilisateurs(id) ON DELETE SET NULL,
  statut      TEXT NOT NULL DEFAULT 'publie',
  cree        DATE NOT NULL DEFAULT CURRENT_DATE,
  modifie     DATE NOT NULL DEFAULT CURRENT_DATE
);
CREATE INDEX IF NOT EXISTS idx_td_filtres ON travaux_diriges(discipline, niveau, difficulte);
CREATE INDEX IF NOT EXISTS idx_td_discipline_ua ON travaux_diriges(unaccent_simple(discipline));
CREATE INDEX IF NOT EXISTS idx_td_niveau_ua     ON travaux_diriges(unaccent_simple(niveau));

CREATE TABLE IF NOT EXISTS favoris (
  utilisateur_id TEXT NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
  ressource_id   TEXT NOT NULL REFERENCES ressources(id) ON DELETE CASCADE,
  ajoute_le      TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (utilisateur_id, ressource_id)
);

-- --- Journal d'audit --------------------------------------------------------
CREATE TABLE IF NOT EXISTS journal_audit (
  id         BIGSERIAL PRIMARY KEY,
  au         TIMESTAMPTZ NOT NULL DEFAULT now(),
  acteur_id  TEXT,
  action     TEXT NOT NULL,
  cible      TEXT,
  details    JSONB
);
CREATE INDEX IF NOT EXISTS idx_audit_au ON journal_audit(au DESC);

COMMIT;
