-- ============================================================================
-- 003 — Évaluation : travaux, exercices, banque de questions, quiz,
--       assignations et remises.
--
-- Décision d'architecture : les cinq formes de travail décrites au document de
-- projet — travail dirigé, travail pratique, exposé, dissertation, examen —
-- partagent le même cycle de vie (brouillon → publié → assigné → corrigé), la
-- même assignation et la même remise. Elles deviennent donc UNE table portant
-- un discriminant `type`, et non cinq tables presque identiques. Ce qui leur
-- est propre — matériel d'un TP, nombre de mots d'une dissertation — vit dans
-- la colonne `details`.
-- ============================================================================

BEGIN;

-- --- Horodatage de modification, partagé par plusieurs tables ---------------
CREATE OR REPLACE FUNCTION maj_modifie_le() RETURNS trigger AS $$
BEGIN
  NEW.modifie_le = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- --- Travaux ----------------------------------------------------------------
ALTER TABLE travaux_diriges RENAME TO travaux;

ALTER TABLE travaux
  ADD COLUMN IF NOT EXISTS type          TEXT NOT NULL DEFAULT 'td',
  ADD COLUMN IF NOT EXISTS objectifs     TEXT,
  ADD COLUMN IF NOT EXISTS consignes     TEXT,
  ADD COLUMN IF NOT EXISTS bareme_total  INTEGER,
  ADD COLUMN IF NOT EXISTS seuil         INTEGER,
  ADD COLUMN IF NOT EXISTS details       JSONB NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS modifie_le    TIMESTAMPTZ NOT NULL DEFAULT now();

ALTER TABLE travaux DROP CONSTRAINT IF EXISTS travaux_type_valide;
ALTER TABLE travaux ADD  CONSTRAINT travaux_type_valide
  CHECK (type IN ('td', 'tp', 'expose', 'dissertation', 'examen'));

ALTER TABLE travaux DROP CONSTRAINT IF EXISTS travaux_statut_valide;
ALTER TABLE travaux ADD  CONSTRAINT travaux_statut_valide
  CHECK (statut IN ('brouillon', 'publie', 'archive'));

-- Un travail publié doit être rattaché à une école : c'est du travail de classe.
ALTER TABLE travaux DROP CONSTRAINT IF EXISTS travaux_ecole_si_publie;
ALTER TABLE travaux ADD  CONSTRAINT travaux_ecole_si_publie
  CHECK (statut = 'brouillon' OR ecole_id IS NOT NULL);

DROP TRIGGER IF EXISTS trg_travaux_modifie ON travaux;
CREATE TRIGGER trg_travaux_modifie BEFORE UPDATE ON travaux
  FOR EACH ROW EXECUTE FUNCTION maj_modifie_le();

CREATE INDEX IF NOT EXISTS idx_travaux_type   ON travaux(type);
CREATE INDEX IF NOT EXISTS idx_travaux_auteur ON travaux(auteur_id);

-- Compatibilité : le dépôt applicatif interroge toujours « travaux_diriges ».
-- La vue est modifiable, et WITH CHECK OPTION interdit d'y insérer autre
-- chose qu'un travail dirigé.
CREATE OR REPLACE VIEW travaux_diriges AS
  SELECT id, titre, discipline, niveau, cycle, chapitre, exercices, difficulte,
         duree, icon, tone, favori, vues, statut, classe_id, ecole_id,
         annee_academique_id, auteur_id, cree, modifie
    FROM travaux
   WHERE type = 'td'
  WITH CHECK OPTION;

-- --- Exercices d'un travail -------------------------------------------------
CREATE TABLE IF NOT EXISTS exercices (
  id          TEXT PRIMARY KEY,
  travail_id  TEXT NOT NULL REFERENCES travaux(id) ON DELETE CASCADE,
  position    INTEGER NOT NULL,
  enonce      TEXT NOT NULL,
  corrige     TEXT,
  points      NUMERIC(5,2) NOT NULL DEFAULT 0,
  UNIQUE (travail_id, position)
);
CREATE INDEX IF NOT EXISTS idx_exercices_travail ON exercices(travail_id);

-- --- Banque de questions ----------------------------------------------------
CREATE TABLE IF NOT EXISTS questions (
  id           TEXT PRIMARY KEY,
  enonce       TEXT NOT NULL,
  type         TEXT NOT NULL,
  choix        JSONB NOT NULL DEFAULT '[]'::jsonb,
  reponse      JSONB,
  explication  TEXT,
  discipline   TEXT,
  niveau       TEXT,
  cycle        TEXT,
  chapitre     TEXT,
  difficulte   TEXT,
  duree        INTEGER,
  auteur_id    TEXT,
  ecole_id     TEXT,
  visibilite   TEXT NOT NULL DEFAULT 'ecole',
  version      INTEGER NOT NULL DEFAULT 1,
  source_id    TEXT REFERENCES questions(id) ON DELETE SET NULL,
  cree_le      TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE questions DROP CONSTRAINT IF EXISTS questions_type_valide;
ALTER TABLE questions ADD  CONSTRAINT questions_type_valide
  CHECK (type IN ('choix_unique', 'choix_multiple', 'vrai_faux', 'texte_a_trous',
                  'appariement', 'reponse_courte', 'question_ouverte'));

ALTER TABLE questions DROP CONSTRAINT IF EXISTS questions_visibilite_valide;
ALTER TABLE questions ADD  CONSTRAINT questions_visibilite_valide
  CHECK (visibilite IN ('commun', 'ecole', 'prive'));

ALTER TABLE questions DROP CONSTRAINT IF EXISTS questions_ecole_obligatoire;
ALTER TABLE questions ADD  CONSTRAINT questions_ecole_obligatoire
  CHECK (visibilite = 'commun' OR ecole_id IS NOT NULL);

ALTER TABLE questions DROP CONSTRAINT IF EXISTS questions_cycle_valide;
ALTER TABLE questions ADD  CONSTRAINT questions_cycle_valide
  CHECK (cycle IS NULL OR cycle IN ('maternelle', 'primaire', 'secondaire'));

CREATE INDEX IF NOT EXISTS idx_questions_filtres    ON questions(discipline, niveau, chapitre);
CREATE INDEX IF NOT EXISTS idx_questions_visibilite ON questions(visibilite, ecole_id);
CREATE INDEX IF NOT EXISTS idx_questions_source     ON questions(source_id);

-- --- Quiz --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS quiz (
  id                  TEXT PRIMARY KEY,
  titre               TEXT NOT NULL,
  discipline          TEXT,
  niveau              TEXT,
  cycle               TEXT,
  bareme_total        INTEGER,
  seuil               INTEGER,
  reprises            INTEGER NOT NULL DEFAULT 0,   -- 0 = illimité
  melange_questions   BOOLEAN NOT NULL DEFAULT true,
  melange_propositions BOOLEAN NOT NULL DEFAULT true,
  correction          TEXT NOT NULL DEFAULT 'immediate',
  statut              TEXT NOT NULL DEFAULT 'brouillon',
  auteur_id           TEXT,
  ecole_id            TEXT,
  annee_academique_id TEXT,
  cree_le             TIMESTAMPTZ NOT NULL DEFAULT now(),
  modifie_le          TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE quiz DROP CONSTRAINT IF EXISTS quiz_correction_valide;
ALTER TABLE quiz ADD  CONSTRAINT quiz_correction_valide
  CHECK (correction IN ('immediate', 'differee'));

ALTER TABLE quiz DROP CONSTRAINT IF EXISTS quiz_statut_valide;
ALTER TABLE quiz ADD  CONSTRAINT quiz_statut_valide
  CHECK (statut IN ('brouillon', 'publie', 'archive'));

ALTER TABLE quiz DROP CONSTRAINT IF EXISTS quiz_cycle_valide;
ALTER TABLE quiz ADD  CONSTRAINT quiz_cycle_valide
  CHECK (cycle IS NULL OR cycle IN ('maternelle', 'primaire', 'secondaire'));

DROP TRIGGER IF EXISTS trg_quiz_modifie ON quiz;
CREATE TRIGGER trg_quiz_modifie BEFORE UPDATE ON quiz
  FOR EACH ROW EXECUTE FUNCTION maj_modifie_le();

CREATE INDEX IF NOT EXISTS idx_quiz_tenant ON quiz(ecole_id, annee_academique_id);

CREATE TABLE IF NOT EXISTS quiz_questions (
  quiz_id     TEXT NOT NULL REFERENCES quiz(id) ON DELETE CASCADE,
  question_id TEXT NOT NULL REFERENCES questions(id) ON DELETE RESTRICT,
  position    INTEGER NOT NULL,
  points      NUMERIC(5,2) NOT NULL DEFAULT 1,
  PRIMARY KEY (quiz_id, question_id)
);
CREATE INDEX IF NOT EXISTS idx_quiz_questions_question ON quiz_questions(question_id);

-- --- Assignations ------------------------------------------------------------
-- Une assignation relie un objet pédagogique à une classe, pour une année.
CREATE TABLE IF NOT EXISTS assignations (
  id                  TEXT PRIMARY KEY,
  objet_type          TEXT NOT NULL,
  objet_id            TEXT NOT NULL,
  classe_id           TEXT NOT NULL,
  ecole_id            TEXT NOT NULL,
  annee_academique_id TEXT NOT NULL,
  obligatoire         BOOLEAN NOT NULL DEFAULT true,
  ouvre_le            TIMESTAMPTZ,
  date_limite         TIMESTAMPTZ,
  assigne_par         TEXT,
  cree_le             TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (objet_type, objet_id, classe_id, annee_academique_id)
);

ALTER TABLE assignations DROP CONSTRAINT IF EXISTS assignations_objet_valide;
ALTER TABLE assignations ADD  CONSTRAINT assignations_objet_valide
  CHECK (objet_type IN ('travail', 'quiz', 'parcours', 'ressource', 'laboratoire'));

ALTER TABLE assignations DROP CONSTRAINT IF EXISTS assignations_dates_coherentes;
ALTER TABLE assignations ADD  CONSTRAINT assignations_dates_coherentes
  CHECK (ouvre_le IS NULL OR date_limite IS NULL OR ouvre_le < date_limite);

CREATE INDEX IF NOT EXISTS idx_assignations_tenant ON assignations(ecole_id, annee_academique_id);
CREATE INDEX IF NOT EXISTS idx_assignations_classe ON assignations(classe_id);
CREATE INDEX IF NOT EXISTS idx_assignations_objet  ON assignations(objet_type, objet_id);

-- --- Remises et corrections ---------------------------------------------------
CREATE TABLE IF NOT EXISTS remises (
  id             TEXT PRIMARY KEY,
  assignation_id TEXT NOT NULL REFERENCES assignations(id) ON DELETE CASCADE,
  eleve_id       TEXT NOT NULL,
  ecole_id       TEXT NOT NULL,
  contenu        TEXT,
  reponses       JSONB,
  fichier_id     TEXT,
  statut         TEXT NOT NULL DEFAULT 'brouillon',
  remis_le       TIMESTAMPTZ,
  note           NUMERIC(5,2),
  note_sur       NUMERIC(5,2) NOT NULL DEFAULT 100,
  retour         TEXT,
  corrige_par    TEXT,
  corrige_le     TIMESTAMPTZ,
  UNIQUE (assignation_id, eleve_id)
);

ALTER TABLE remises DROP CONSTRAINT IF EXISTS remises_statut_valide;
ALTER TABLE remises ADD  CONSTRAINT remises_statut_valide
  CHECK (statut IN ('brouillon', 'remise', 'a_corriger', 'corrigee'));

-- Une note ne peut pas dépasser son barème ni être négative.
ALTER TABLE remises DROP CONSTRAINT IF EXISTS remises_note_dans_bareme;
ALTER TABLE remises ADD  CONSTRAINT remises_note_dans_bareme
  CHECK (note IS NULL OR (note >= 0 AND note <= note_sur));

-- Une remise corrigée porte forcément une note et son correcteur.
ALTER TABLE remises DROP CONSTRAINT IF EXISTS remises_correction_complete;
ALTER TABLE remises ADD  CONSTRAINT remises_correction_complete
  CHECK (statut <> 'corrigee' OR (note IS NOT NULL AND corrige_par IS NOT NULL));

CREATE INDEX IF NOT EXISTS idx_remises_eleve       ON remises(eleve_id);
CREATE INDEX IF NOT EXISTS idx_remises_assignation ON remises(assignation_id);
CREATE INDEX IF NOT EXISTS idx_remises_ecole       ON remises(ecole_id, statut);

COMMIT;
