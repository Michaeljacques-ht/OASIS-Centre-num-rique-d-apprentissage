-- ============================================================================
-- 004 — Apprentissage : compétences, parcours, progression, lecture, avis.
--
-- Tout ce qui est personnel à un apprenant est dérivé de ses actions, jamais
-- saisi : la progression se calcule, elle ne se déclare pas.
-- ============================================================================

BEGIN;

-- --- Référentiel de compétences ---------------------------------------------
CREATE TABLE IF NOT EXISTS competences (
  id         TEXT PRIMARY KEY,
  code       TEXT UNIQUE,
  libelle    TEXT NOT NULL,
  discipline TEXT,
  cycle      TEXT,
  niveau     TEXT,
  parent_id  TEXT REFERENCES competences(id) ON DELETE SET NULL
);

ALTER TABLE competences DROP CONSTRAINT IF EXISTS competences_cycle_valide;
ALTER TABLE competences ADD  CONSTRAINT competences_cycle_valide
  CHECK (cycle IS NULL OR cycle IN ('maternelle', 'primaire', 'secondaire'));

CREATE INDEX IF NOT EXISTS idx_competences_discipline ON competences(discipline, cycle);
CREATE INDEX IF NOT EXISTS idx_competences_parent     ON competences(parent_id);

CREATE TABLE IF NOT EXISTS ressource_competences (
  ressource_id  TEXT NOT NULL REFERENCES ressources(id) ON DELETE CASCADE,
  competence_id TEXT NOT NULL REFERENCES competences(id) ON DELETE CASCADE,
  PRIMARY KEY (ressource_id, competence_id)
);
CREATE INDEX IF NOT EXISTS idx_res_comp_competence ON ressource_competences(competence_id);

-- --- Parcours d'apprentissage ------------------------------------------------
CREATE TABLE IF NOT EXISTS parcours (
  id         TEXT PRIMARY KEY,
  titre      TEXT NOT NULL,
  theme      TEXT,
  discipline TEXT,
  niveau     TEXT,
  cycle      TEXT,
  audience   TEXT NOT NULL DEFAULT 'eleves',
  visibilite TEXT NOT NULL DEFAULT 'commun',
  ecole_id   TEXT,
  statut     TEXT NOT NULL DEFAULT 'brouillon',
  auteur_id  TEXT,
  cree_le    TIMESTAMPTZ NOT NULL DEFAULT now(),
  modifie_le TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE parcours DROP CONSTRAINT IF EXISTS parcours_visibilite_valide;
ALTER TABLE parcours ADD  CONSTRAINT parcours_visibilite_valide
  CHECK (visibilite IN ('commun', 'ecole', 'prive'));

ALTER TABLE parcours DROP CONSTRAINT IF EXISTS parcours_ecole_obligatoire;
ALTER TABLE parcours ADD  CONSTRAINT parcours_ecole_obligatoire
  CHECK (visibilite = 'commun' OR ecole_id IS NOT NULL);

ALTER TABLE parcours DROP CONSTRAINT IF EXISTS parcours_statut_valide;
ALTER TABLE parcours ADD  CONSTRAINT parcours_statut_valide
  CHECK (statut IN ('brouillon', 'publie', 'archive'));

DROP TRIGGER IF EXISTS trg_parcours_modifie ON parcours;
CREATE TRIGGER trg_parcours_modifie BEFORE UPDATE ON parcours
  FOR EACH ROW EXECUTE FUNCTION maj_modifie_le();

ALTER TABLE parcours DROP CONSTRAINT IF EXISTS parcours_cycle_valide;
ALTER TABLE parcours ADD  CONSTRAINT parcours_cycle_valide
  CHECK (cycle IS NULL OR cycle IN ('maternelle', 'primaire', 'secondaire'));

CREATE INDEX IF NOT EXISTS idx_parcours_visibilite ON parcours(visibilite, ecole_id);
CREATE INDEX IF NOT EXISTS idx_parcours_theme      ON parcours(theme, cycle);

CREATE TABLE IF NOT EXISTS parcours_etapes (
  id          TEXT PRIMARY KEY,
  parcours_id TEXT NOT NULL REFERENCES parcours(id) ON DELETE CASCADE,
  position    INTEGER NOT NULL,
  objet_type  TEXT NOT NULL,
  objet_id    TEXT NOT NULL,
  obligatoire BOOLEAN NOT NULL DEFAULT true,
  UNIQUE (parcours_id, position)
);

ALTER TABLE parcours_etapes DROP CONSTRAINT IF EXISTS etapes_objet_valide;
ALTER TABLE parcours_etapes ADD  CONSTRAINT etapes_objet_valide
  CHECK (objet_type IN ('ressource', 'quiz', 'travail', 'laboratoire'));

CREATE INDEX IF NOT EXISTS idx_etapes_parcours ON parcours_etapes(parcours_id);
CREATE INDEX IF NOT EXISTS idx_etapes_objet    ON parcours_etapes(objet_type, objet_id);

-- --- Progression --------------------------------------------------------------
-- Le pourcentage est une colonne calculée : il ne peut pas diverger du nombre
-- d'étapes acquises, parce qu'il n'est jamais écrit à la main.
CREATE TABLE IF NOT EXISTS progressions (
  utilisateur_id TEXT NOT NULL,
  parcours_id    TEXT NOT NULL REFERENCES parcours(id) ON DELETE CASCADE,
  ecole_id       TEXT,
  etapes_faites  TEXT[] NOT NULL DEFAULT '{}',
  etapes_total   INTEGER NOT NULL DEFAULT 0,
  pourcent       INTEGER GENERATED ALWAYS AS (
                   CASE WHEN etapes_total = 0 THEN 0
                        ELSE (cardinality(etapes_faites) * 100) / etapes_total END
                 ) STORED,
  reprise_a      TEXT,
  maj_le         TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (utilisateur_id, parcours_id)
);
CREATE INDEX IF NOT EXISTS idx_progressions_parcours ON progressions(parcours_id);

-- --- Reprise de lecture --------------------------------------------------------
CREATE TABLE IF NOT EXISTS lectures (
  utilisateur_id    TEXT NOT NULL,
  ressource_id      TEXT NOT NULL REFERENCES ressources(id) ON DELETE CASCADE,
  position_secondes INTEGER NOT NULL DEFAULT 0,
  termine           BOOLEAN NOT NULL DEFAULT false,
  maj_le            TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (utilisateur_id, ressource_id)
);
CREATE INDEX IF NOT EXISTS idx_lectures_ressource ON lectures(ressource_id);

-- --- Avis -----------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS avis (
  id             TEXT PRIMARY KEY,
  ressource_id   TEXT NOT NULL REFERENCES ressources(id) ON DELETE CASCADE,
  utilisateur_id TEXT NOT NULL,
  note           SMALLINT NOT NULL,
  commentaire    TEXT,
  cree_le        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (ressource_id, utilisateur_id)
);

ALTER TABLE avis DROP CONSTRAINT IF EXISTS avis_note_valide;
ALTER TABLE avis ADD  CONSTRAINT avis_note_valide CHECK (note BETWEEN 1 AND 5);

CREATE INDEX IF NOT EXISTS idx_avis_ressource ON avis(ressource_id);

-- La note moyenne affichée sur une ressource est recalculée par la base.
-- Aucun code applicatif ne peut la désynchroniser.
CREATE OR REPLACE FUNCTION recalculer_note_ressource() RETURNS trigger AS $$
DECLARE
  cible TEXT := COALESCE(NEW.ressource_id, OLD.ressource_id);
BEGIN
  UPDATE ressources r
     SET note = sous.moyenne, avis = sous.nombre
    FROM (SELECT round(avg(note)::numeric, 1) AS moyenne, count(*) AS nombre
            FROM avis WHERE ressource_id = cible) AS sous
   WHERE r.id = cible;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_avis_note ON avis;
CREATE TRIGGER trg_avis_note AFTER INSERT OR UPDATE OR DELETE ON avis
  FOR EACH ROW EXECUTE FUNCTION recalculer_note_ressource();

COMMIT;
