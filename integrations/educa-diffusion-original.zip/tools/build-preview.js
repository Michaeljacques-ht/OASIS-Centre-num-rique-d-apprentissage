'use strict';
/**
 * Aperçus HTML autonomes (CSS et images intégrés) : consultables sans serveur.
 * Sortie : preview/<nom>.html
 */
const fs = require('fs');
const path = require('path');
const { layout } = require('../frontend/components/layout');
const { siteLayout } = require('../frontend/components/site-layout');
const store = require('../frontend/services/api/diffusion');
const qr = require('../services/diffusion-service/src/utils/qr');

const root = path.join(__dirname, '..');
const readCss = (f) => fs.readFileSync(path.join(root, 'frontend/public/css', `${f}.css`), 'utf8');
const cssApp = ['tokens', 'base', 'layout', 'components'].map(readCss).join('\n');
const cssSite = ['tokens', 'base', 'components', 'site'].map(readCss).join('\n');
const js = fs.readFileSync(path.join(root, 'frontend/public/js/app.js'), 'utf8');



const ECRANS = [
  { nom: 'accueil-site-public', page: '../frontend/app/accueil', role: 'enseignant' },
  { nom: 'enseignant-tableau-de-bord', page: '../frontend/app/tableau-de-bord', role: 'enseignant' },
  { nom: 'enseignant-ressources-pedagogiques', page: '../frontend/app/ressources-pedagogiques', role: 'enseignant' },
  { nom: 'enseignant-ressources-methodologiques', page: '../frontend/app/ressources-methodologiques', role: 'enseignant' },
  { nom: 'enseignant-travaux-diriges', page: '../frontend/app/travaux-diriges', role: 'enseignant' },
  { nom: 'eleve-ressources-pedagogiques', page: '../frontend/app/ressources-pedagogiques', role: 'eleve' },
  { nom: 'eleve-ressources-methodologiques', page: '../frontend/app/ressources-methodologiques', role: 'eleve' },
  { nom: 'systeme-de-design', page: '../frontend/app/systeme', role: 'enseignant' },
];

/** Remplace chaque appel à /qr.svg?… par le QR code encodé sur place. */
function inlineQr(html) {
  const logo = 'data:image/svg+xml;base64,' +
    fs.readFileSync(path.join(root, 'frontend/public/img/logo.svg')).toString('base64');
  return html.replace(/\/qr\.svg\?([^"'\s]+)/g, (match, query) => {
    const params = new URLSearchParams(query.replace(/&amp;/g, '&'));
    const texte = params.get('texte');
    if (!texte) return match;
    const image = qr.svg(texte, {
      size: Number(params.get('taille')) || 200,
      logo: params.get('logo') ? logo : null,
    });
    return 'data:image/svg+xml;base64,' + Buffer.from(image).toString('base64');
  });
}

/** Remplace chaque src="/img/…" par son équivalent en base64. */
function inlineImages(html) {
  return html.replace(/\/img\/([\w.-]+\.svg)/g, (match, file) => {
    const full = path.join(root, 'frontend/public/img', file);
    if (!fs.existsSync(full)) return match;
    return 'data:image/svg+xml;base64,' + fs.readFileSync(full).toString('base64');
  });
}

fs.mkdirSync(path.join(root, 'preview'), { recursive: true });

(async () => {
const users = JSON.parse(fs.readFileSync(path.join(root, 'frontend/data/comptes-demo.json'), 'utf8'));
const nav = await store.read('nav');

for (const ecran of ECRANS) {
  const user = users.find((u) => u.role === ecran.role);
  const ctx = {
    query: {}, role: ecran.role, user, nav: nav[ecran.role],
    identite: { sub: user.id, role: ecran.role, school_id: 'eco_demo', academic_year_id: 'an_2026' },
  };
  const view = await require(ecran.page)(ctx);

  let out = view.chrome === 'site'
    ? await siteLayout(view)
    : layout({ ...view, nav: ctx.nav, user, otherRole: null });

  out = out
    .replace(/<link rel="stylesheet"[^>]*>\s*/g, '')
    .replace('</head>', `<style>\n${view.chrome === 'site' ? cssSite : cssApp}\n${(view.styles || []).map(readCss).join('\n')}\n</style>\n</head>`)
    .replace('<script src="/js/app.js" defer></script>', `<script>${js}</script>`);
  out = inlineQr(inlineImages(out));

  fs.writeFileSync(path.join(root, 'preview', `${ecran.nom}.html`), out);
  console.log(`${ecran.nom}.html — ${Math.round(out.length / 1024)} Ko`);
}
})();
