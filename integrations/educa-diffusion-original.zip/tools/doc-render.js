'use strict';
/**
 * Moteur de rendu des documents du projet : un contenu décrit une fois,
 * rendu en Markdown et en Word. Partagé par tools/doc-conception.js et
 * tools/doc-projet.js.
 */
const fs = require('fs');
const path = require('path');

/* --- Fabriques de blocs --------------------------------------------------- */
const couv = (lignes) => ({ t: 'couv', lignes });
const h1 = (texte) => ({ t: 'h1', texte });
const h1n = (texte) => ({ t: 'h1', texte, nonNumerote: true });
const h2 = (texte) => ({ t: 'h2', texte });
const h3 = (texte) => ({ t: 'h3', texte });
const p = (texte) => ({ t: 'p', texte });
const puces = (items) => ({ t: 'puces', items });
const tbl = (entetes, lignes, largeurs) => ({ t: 'tbl', entetes, lignes, largeurs });
const mono = (lignes) => ({ t: 'mono', lignes });
const note = (texte) => ({ t: 'note', texte });
const saut = () => ({ t: 'saut' });
const toc = () => ({ t: 'toc' });

/* ========================================================================= */
/* Numérotation des sections                                                 */
/* ========================================================================= */
function numeroter(CONTENU, depart) {
  let compteur = depart;
  for (const bloc of CONTENU) {
    if (bloc.t !== 'h1') continue;
    if (bloc.nonNumerote) continue;
    bloc.numero = compteur;
    compteur += 1;
  }
}

/* ========================================================================= */
/* Rendu Markdown                                                            */
/* ========================================================================= */
function versMarkdown(CONTENU) {
  const out = [];
  for (const b of CONTENU) {
    switch (b.t) {
      case 'couv':
        out.push(`# ${b.lignes[1]}`, '', `**${b.lignes[0]}**`, '', `## ${b.lignes[2]}`, '', `*${b.lignes[3]}*`, '');
        break;
      case 'h1':
        out.push('', `## ${b.numero ? b.numero + '. ' : ''}${b.texte}`, ''); break;
      case 'h2': out.push('', `### ${b.texte}`, ''); break;
      case 'h3': out.push('', `#### ${b.texte}`, ''); break;
      case 'p': out.push(b.texte, ''); break;
      case 'note': out.push(`> ${b.texte}`, ''); break;
      case 'puces': out.push(...b.items.map((i) => `- ${i}`), ''); break;
      case 'mono': out.push('```text', ...b.lignes, '```', ''); break;
      case 'toc': out.push('*(table des matières générée automatiquement dans la version Word)*', ''); break;
      case 'saut': break;
      case 'tbl':
        out.push(
          `| ${b.entetes.join(' | ')} |`,
          `| ${b.entetes.map(() => '---').join(' | ')} |`,
          ...b.lignes.map((l) => `| ${l.map((c) => String(c).replace(/\|/g, '\\|')).join(' | ')} |`),
          ''
        );
        break;
    }
  }
  return out.join('\n');
}

/* ========================================================================= */
/* Rendu Word                                                                */
/* ========================================================================= */
function versDocx(CONTENU, meta) {
  const {
    Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell,
    WidthType, ShadingType, BorderStyle, PageBreak, Footer, PageNumber, TableOfContents,
    LevelFormat, convertInchesToTwip,
  } = require('docx');

  const MARINE = '1F3864';
  const BLEU = '1D4ED8';
  const ORANGE = 'E56A19';
  const GRIS = '595959';
  const BORDURE = { style: BorderStyle.SINGLE, size: 4, color: 'BFBFBF' };
  const BORDURES = { top: BORDURE, bottom: BORDURE, left: BORDURE, right: BORDURE };

  const texte = (t, opts = {}) => new TextRun({ text: t, ...opts });

  const cellule = (contenu, largeur, entete = false) =>
    new TableCell({
      width: { size: largeur, type: WidthType.DXA },
      shading: entete
        ? { type: ShadingType.CLEAR, fill: MARINE, color: 'auto' }
        : { type: ShadingType.CLEAR, fill: 'FFFFFF', color: 'auto' },
      margins: { top: 60, bottom: 60, left: 100, right: 100 },
      children: [
        new Paragraph({
          spacing: { before: 20, after: 20 },
          children: [texte(String(contenu), { bold: entete, color: entete ? 'FFFFFF' : '000000', size: 18 })],
        }),
      ],
    });

  const tableau = (b) => {
    const largeurs = b.largeurs || b.entetes.map(() => Math.floor(9300 / b.entetes.length));
    return new Table({
      columnWidths: largeurs,
      width: { size: largeurs.reduce((a, c) => a + c, 0), type: WidthType.DXA },
      borders: BORDURES,
      rows: [
        new TableRow({
          tableHeader: true,
          children: b.entetes.map((e, i) => cellule(e, largeurs[i], true)),
        }),
        ...b.lignes.map((l) => new TableRow({ children: l.map((c, i) => cellule(c, largeurs[i])) })),
      ],
    });
  };

  const enfants = [];
  for (const b of CONTENU) {
    switch (b.t) {
      case 'couv':
        enfants.push(
          new Paragraph({ spacing: { before: 1600, after: 200 }, alignment: AlignmentType.CENTER,
            children: [texte(b.lignes[0], { bold: true, color: ORANGE, size: 24 })] }),
          new Paragraph({ spacing: { after: 160 }, alignment: AlignmentType.CENTER,
            children: [texte(b.lignes[1], { bold: true, color: MARINE, size: 48 })] }),
          new Paragraph({ spacing: { after: 120 }, alignment: AlignmentType.CENTER,
            children: [texte(b.lignes[2], { color: BLEU, size: 28 })] }),
          new Paragraph({ spacing: { after: 500 }, alignment: AlignmentType.CENTER,
            children: [texte(b.lignes[3], { italics: true, color: GRIS, size: 22 })] }),
        );
        break;
      case 'h1':
        enfants.push(new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 240, after: 160 },
          children: [texte(`${b.numero ? b.numero + '. ' : ''}${b.texte}`, { bold: true, color: MARINE, size: 30 })],
        }));
        break;
      case 'h2':
        enfants.push(new Paragraph({
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 120 },
          children: [texte(b.texte, { bold: true, color: BLEU, size: 24 })],
        }));
        break;
      case 'h3':
        enfants.push(new Paragraph({
          spacing: { before: 180, after: 100 },
          children: [texte(b.texte, { bold: true, color: '10305F', size: 21 })],
        }));
        break;
      case 'p':
        enfants.push(new Paragraph({
          spacing: { after: 140, line: 276 },
          alignment: AlignmentType.JUSTIFIED,
          children: [texte(b.texte, { size: 21 })],
        }));
        break;
      case 'note':
        enfants.push(new Paragraph({
          spacing: { before: 120, after: 160 },
          indent: { left: 240 },
          shading: { type: ShadingType.CLEAR, fill: 'F2F5FA', color: 'auto' },
          border: { left: { style: BorderStyle.SINGLE, size: 12, color: BLEU, space: 8 } },
          children: [texte(b.texte, { italics: true, size: 20, color: '333333' })],
        }));
        break;
      case 'puces':
        for (const item of b.items) {
          enfants.push(new Paragraph({
            numbering: { reference: 'puces', level: 0 },
            spacing: { after: 80, line: 276 },
            children: [texte(item, { size: 21 })],
          }));
        }
        break;
      case 'mono':
        for (const ligne of b.lignes) {
          enfants.push(new Paragraph({
            spacing: { before: 0, after: 0, line: 216 },
            children: [texte(ligne || ' ', { font: 'Consolas', size: 15 })],
          }));
        }
        enfants.push(new Paragraph({ spacing: { after: 160 }, children: [texte('')] }));
        break;
      case 'tbl':
        enfants.push(tableau(b), new Paragraph({ spacing: { after: 200 }, children: [texte('')] }));
        break;
      case 'toc':
        enfants.push(new TableOfContents('Sommaire', { hyperlink: true, headingStyleRange: '1-2' }));
        break;
      case 'saut':
        enfants.push(new Paragraph({ children: [new PageBreak()] }));
        break;
    }
  }

  const doc = new Document({
    creator: 'Michael Jacques — EDUCA Technologie',
    title: meta.titre,
    description: meta.description,
    styles: {
      default: { document: { run: { font: 'Calibri', size: 21 } } },
    },
    numbering: {
      config: [{
        reference: 'puces',
        levels: [{
          level: 0, format: LevelFormat.BULLET, text: '\u2022', alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 360, hanging: 200 } } },
        }],
      }],
    },
    sections: [{
      properties: {
        page: { margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 } },
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              texte(meta.pied + ' · Page ', { size: 16, color: GRIS }),
              new TextRun({ children: [PageNumber.CURRENT], size: 16, color: GRIS, bold: true }),
            ],
          })],
        }),
      },
      children: enfants,
    }],
  });

  return Packer.toBuffer(doc);
}


/* --- Écriture ------------------------------------------------------------- */
/**
 * @param {Array} contenu  blocs du document
 * @param {{fichier:string, titre:string, description:string, pied:string, depart?:number}} meta
 */
async function ecrire(contenu, meta) {
  numeroter(contenu, meta.depart === undefined ? 2 : meta.depart);
  const dossier = path.join(__dirname, '..', 'docs');
  fs.mkdirSync(dossier, { recursive: true });

  fs.writeFileSync(path.join(dossier, meta.fichier + '.md'), versMarkdown(contenu));
  const buffer = await versDocx(contenu, meta);
  fs.writeFileSync(path.join(dossier, meta.fichier + '.docx'), buffer);

  console.log(meta.fichier + '.md et .docx écrits — ' + Math.round(buffer.length / 1024) + ' Ko');
  console.log(
    contenu.filter((b) => b.t === 'h1').length + ' sections · ' +
    contenu.filter((b) => b.t === 'tbl').length + ' tableaux · ' +
    contenu.filter((b) => b.t === 'mono').length + ' diagrammes'
  );
}

module.exports = { couv, h1, h1n, h2, h3, p, puces, tbl, mono, note, saut, toc, ecrire };
