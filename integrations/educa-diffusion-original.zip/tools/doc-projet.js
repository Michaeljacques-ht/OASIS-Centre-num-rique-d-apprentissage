'use strict';
/**
 * EDUCA Diffusion — Document de projet v1.0
 * Structure calquée sur le document de projet ÉDUCA RH : 34 sections,
 * des modules décrits par objet / fonctionnalités / règles de gestion,
 * une matrice de permissions et un moteur détaillé.
 *
 *   node tools/doc-projet.js
 */
const { couv, h1, h1n, h2, h3, p, puces, tbl, mono, note, saut, toc, ecrire } = require('./doc-render');

const D = [];
const A = (...blocs) => D.push(...blocs);

/* ========================================================================= */
A(
  couv([
    'EDUCA TECHNOLOGIE',
    'ÉDUCA DIFFUSION',
    'Document de projet',
    'Plateforme de diffusion de contenus pédagogiques — « Diffuser le savoir autrement »',
  ]),
  tbl(['Rubrique', 'Information'], [
    ['Produit', 'ÉDUCA Diffusion'],
    ['Écosystème', 'EDUCA Technologie'],
    ['Version du document', '1.0'],
    ['Date', 'Août 2026'],
    ['Auteur', 'Michael Jacques'],
    ['Statut', 'Ossature et sept écrans livrés — modules en développement'],
    ['Devise de référence', 'Gourde haïtienne (HTG)'],
    ['Langues cibles', 'Français (v1), Créole haïtien (v2), Anglais (v3)'],
    ['Public', 'Élèves, enseignants, établissements, éditeurs'],
  ], [3000, 6300]),
  saut(),

  h1n('Table des matières'),
  toc(),
  saut(),
);

/* ========================================================================= */
/* 2. Introduction et contexte                                               */
/* ========================================================================= */
A(
  h1('Introduction et contexte'),
  h2('1.1 Présentation'),
  p("ÉDUCA Diffusion est la plateforme de diffusion de contenus pédagogiques de l'écosystème EDUCA Technologie. Elle réunit un fonds documentaire structuré, deux espaces de travail — enseignant et élève — et un mécanisme de liaison entre l'imprimé et le numérique : chaque manuel publié par la maison d'édition porte des QR codes qui ouvrent les ressources en ligne correspondantes."),
  p("Contrairement aux bibliothèques numériques généralistes, qui proposent un stock de fichiers à télécharger, ÉDUCA Diffusion est conçue comme un outil de travail quotidien : on y prépare un cours, on y compose une évaluation, on y suit un parcours de révision, on y dépose une ressource pour ses collègues."),
  h2("1.2 Positionnement dans l'écosystème EDUCA"),
  mono([
    'EDUCA Technologie',
    '  │',
    '  ├── EDUCA Librairie ........... vente de livres imprimés et numériques',
    '  ├── EDUCA Diffusion ........... fonds pédagogique et espaces de classe   ◄── présent document',
    '  ├── EDUCA Bibliothèque Num. ... conservation et lecture longue',
    '  ├── EDUCA Formation ........... formation continue certifiante',
    '  ├── ÉDUCA RH .................. gestion des personnels des établissements',
    '  └── Randevou.ht · Wout Konekte  autres plateformes de l’écosystème',
    '',
    'Points de contact :',
    '  Librairie   → un manuel vendu ouvre ses ressources Diffusion par QR code',
    '  Formation   → les enseignants se forment à la plateforme et aux méthodes',
    '  RH          → les comptes enseignants d’un établissement client',
    '  Bibliothèque→ les ressources longues sont archivées et citées',
  ]),
  h2('1.3 Public cible'),
  tbl(['Public', 'Effectif visé à 24 mois', 'Usage principal'], [
    ['Élèves du secondaire', '50 000 comptes actifs', 'Réviser, s’exercer, suivre un parcours'],
    ['Enseignants', '5 000 comptes actifs', 'Préparer, évaluer, déposer, partager'],
    ['Établissements', '300 écoles', 'Doter leurs classes d’un fonds commun'],
    ['Éditeurs et auteurs', '200 contributeurs', 'Publier et mesurer l’usage des contenus'],
    ['Grand public', 'non mesuré', 'Consulter par QR code, acheter un contenu'],
  ], [2600, 2800, 3900]),
  saut(),
);

/* ========================================================================= */
/* 3. Problématique et justification                                         */
/* ========================================================================= */
A(
  h1('Problématique et justification'),
  h2('2.1 Constats'),
  puces([
    "Le manuel scolaire est rare et isolé. Quand il existe, il ne s'accompagne d'aucune ressource d'appui : pas de vidéo, pas d'exercice supplémentaire, pas de corrigé.",
    "La préparation de classe est artisanale. Chaque enseignant refait, seul, un travail que des milliers d'autres ont déjà fait ; rien ne circule, rien ne se capitalise.",
    "Les élèves n'ont pas de méthode. Ils savent qu'il faut réviser, personne ne leur a montré comment ; l'échec est souvent un échec de méthode avant d'être un échec de compréhension.",
    "Les ressources existantes sont hors programme. Les plateformes internationales proposent des contenus pensés pour d'autres curricula, dans d'autres langues, à des tarifs en devises.",
    "La connectivité est intermittente. Une plateforme qui exige une connexion stable et un navigateur récent exclut la majorité des utilisateurs visés.",
    "Le numérique reste perçu comme un substitut au livre. Or l'école haïtienne continuera d'utiliser l'imprimé : c'est le lien entre les deux qu'il faut construire, pas leur opposition.",
  ]),
  h2('2.2 Proposition de valeur'),
  tbl(['Pour', 'La plateforme apporte'], [
    ['L’élève', 'Des ressources à son niveau, une méthode de travail explicite, un suivi de sa progression'],
    ['L’enseignant', 'Une bibliothèque prête à l’emploi, des outils de préparation et d’évaluation, une communauté'],
    ['L’établissement', 'Un fonds commun pour toutes les classes, sans licence par poste ni installation'],
    ['L’éditeur', 'Un prolongement numérique de l’imprimé et une mesure réelle de l’usage'],
    ['Le pays', 'La capitalisation d’une production pédagogique nationale conforme au programme'],
  ], [2200, 7100]),
  h2('2.3 Avantage concurrentiel'),
  puces([
    "Le lien imprimé-numérique par QR code, produit par la plateforme elle-même, sans prestataire tiers.",
    "Un fonds conforme au programme haïtien, vérifié avant publication.",
    "Une contribution ouverte aux enseignants, qui transforme les utilisateurs en producteurs.",
    "Une sobriété technique assumée : aucune dépendance externe, des pages qui s'affichent sur une connexion faible.",
    "L'appartenance à l'écosystème EDUCA : paiement en gourdes, identité commune, comptes mutualisés.",
  ]),
  saut(),
);

/* ========================================================================= */
/* 4. Objectifs du projet                                                    */
/* ========================================================================= */
A(
  h1('Objectifs du projet'),
  h2('3.1 Objectif général'),
  p("Doter l'école haïtienne d'une bibliothèque pédagogique numérique vérifiée, reliée aux manuels imprimés, utilisable en basse connectivité, et servant aussi bien la préparation de l'enseignant que le travail personnel de l'élève."),
  h2('3.2 Objectifs spécifiques'),
  tbl(['Réf.', 'Objectif', 'Indicateur de réalisation'], [
    ['OS1', 'Constituer un fonds structuré et vérifié', '1 000 ressources publiées à 12 mois'],
    ['OS2', 'Relier chaque manuel imprimé à ses ressources numériques', '100 % des manuels édités portent des QR codes'],
    ['OS3', 'Outiller la préparation de classe', '6 modules d’évaluation opérationnels'],
    ['OS4', 'Accompagner la méthode de travail de l’élève', '8 parcours méthodologiques complets'],
    ['OS5', 'Ouvrir la contribution enseignante sous modération', '30 % des publications issues de la communauté'],
    ['OS6', 'Proposer un laboratoire numérique', '50 simulations exécutables dans le navigateur'],
    ['OS7', 'Fonctionner en basse connectivité', 'Page complète sous 150 Ko hors médias'],
    ['OS8', 'Équiper les établissements', '300 écoles partenaires à 24 mois'],
  ], [900, 4700, 3700]),
  saut(),
);

/* ========================================================================= */
/* 5. Périmètre du projet                                                    */
/* ========================================================================= */
A(
  h1('Périmètre du projet'),
  h2('4.1 Inclus — Version 1.0'),
  puces([
    "Site public : accueil, catégories, familles de ressources, fiche de contenu, panier et comptes.",
    "Fonds documentaire : ressources pédagogiques, méthodologiques, multimédias, cartes et atlas.",
    "Espace enseignant : tableau de bord, catalogues, banque de questions, quiz, travaux dirigés et pratiques, exposés, dissertations, examens.",
    "Espace élève : tableau de bord, catalogues par thème et discipline, parcours, favoris, progression.",
    "Manuels hybrides : génération des QR codes, adresses courtes, statistiques de scan.",
    "Contribution : dépôt enseignant, soumission, vérification éditoriale, publication.",
    "Communauté : partage de ressources, forum, groupes de classe et d'étude.",
    "Administration : modération, gestion du fonds, paramétrage, journal d'audit.",
  ]),
  h2('4.2 Inclus — Version 2.0'),
  puces([
    "Laboratoire numérique complet : simulations paramétrables et expériences guidées.",
    "Tuteur intelligent : suggestion de ressources selon les résultats de l'élève.",
    "Mode hors ligne : installation en application web progressive, synchronisation différée.",
    "Application mobile native et lecture de QR code intégrée.",
    "Notifications par courriel, SMS et WhatsApp.",
    "API partenaires ouverte aux éditeurs et aux ministères.",
  ]),
  h2('4.3 Explicitement exclus'),
  puces([
    "classe virtuelle en direct et visioconférence — relève d'EDUCA Formation.",
    "gestion administrative des élèves (notes officielles, bulletins, absences) — relève d'un module scolaire distinct.",
    "gestion des personnels des établissements — relève d'ÉDUCA RH.",
    "correction automatique des productions écrites par intelligence artificielle.",
    "vente de manuels imprimés — relève d'EDUCA Librairie, qui renvoie vers Diffusion pour le numérique.",
  ]),
  h2('4.4 Hypothèses et dépendances'),
  tbl(['Hypothèse ou dépendance', 'Conséquence si non vérifiée'], [
    ['La maison d’édition fournit un fonds d’amorçage de 300 ressources', 'Catalogue vide au lancement, adoption compromise'],
    ['Les manuels imprimés réservent un emplacement de QR code', 'Le lien imprimé-numérique perd sa raison d’être'],
    ['La passerelle PLOP PLOP reste disponible', 'Les contenus payants sont suspendus ; le fonds gratuit reste accessible'],
    ['Les établissements disposent d’une connexion, même lente', 'Nécessité d’avancer le mode hors ligne en v1.0'],
    ['Le programme MENFP reste stable sur la période', 'Reclassement des ressources par niveau et discipline'],
  ], [4400, 4900]),
  saut(),
);

/* ========================================================================= */
/* 6. Acteurs et parties prenantes                                           */
/* ========================================================================= */
A(
  h1('Acteurs et parties prenantes'),
  h2('5.1 Acteurs du système'),
  tbl(['Acteur', 'Description', 'Accès'], [
    ['Visiteur', 'Consulte le site public et les ressources ouvertes ; arrive souvent par un QR code', 'Public, sans compte'],
    ['Élève', 'Consulte, s’exerce, suit des parcours, met en favori, participe au forum d’entraide', 'Espace élève'],
    ['Enseignant', 'Cherche, prépare, évalue, dépose, partage avec ses classes', 'Espace enseignant'],
    ['Éditeur', 'Publie le fonds de la maison d’édition, associe manuels et ressources', 'Espace enseignant étendu'],
    ['Administrateur d’établissement', 'Crée les comptes de ses enseignants et de ses classes, consulte les usages', 'Console établissement'],
    ['Modérateur', 'Vérifie les dépôts, approuve ou renvoie avec commentaire', 'Console d’administration'],
    ['Super administrateur', 'Paramètre le fonds, les familles, les disciplines, les niveaux ; consulte l’audit', 'Console d’administration'],
    ['Passerelle PLOP PLOP', 'Acteur externe : encaisse les paiements des contenus payants', 'API HTTPS'],
  ], [2400, 4800, 2100]),
  h2('5.2 Parties prenantes externes'),
  tbl(['Partie prenante', 'Intérêt', 'Attente'], [
    ['MENFP et directions départementales', 'Conformité au programme', 'Classement par niveau et discipline officiels'],
    ['Maison d’édition EDUCA', 'Valorisation du catalogue imprimé', 'Mesure des scans et des téléchargements'],
    ['Associations d’enseignants', 'Reconnaissance de la contribution', 'Attribution claire de la paternité des ressources'],
    ['Parents', 'Accompagnement scolaire', 'Accès simple depuis un téléphone, sans compte'],
    ['Bailleurs et partenaires', 'Impact mesurable', 'Indicateurs d’usage et de couverture territoriale'],
  ], [2900, 2900, 3500]),
  saut(),
);

/* ========================================================================= */
/* 7. Rôles et matrice de permissions                                        */
/* ========================================================================= */
A(
  h1('Rôles et matrice de permissions'),
  h2('6.1 Principes'),
  puces([
    "Cloisonnement des espaces — un compte élève n'atteint jamais les écrans de préparation et d'évaluation de l'espace enseignant, même par adresse directe.",
    "Cloisonnement par établissement — les groupes, les classes et les partages d'un établissement ne sont visibles que de ses membres.",
    "Paternité — l'auteur d'un dépôt garde la main sur sa ressource ; seul un administrateur peut la retirer.",
    "Consultation par défaut — le fonds publié est lisible par tous les comptes ; la restriction est l'exception et doit être motivée.",
    "Journalisation — toute décision de modération et toute tentative d'accès hors périmètre sont enregistrées.",
  ]),
  h2('6.2 Matrice'),
  p("L = Lecture · É = Écriture · A = Approbation · — = Aucun accès"),
  tbl(['Fonction', 'Visiteur', 'Élève', 'Enseig.', 'Éditeur', 'Admin étab.', 'Modér.'], [
    ['Catalogue public', 'L', 'L', 'L', 'L', 'L', 'L'],
    ['Ressource par QR code', 'L', 'L', 'L', 'L', 'L', 'L'],
    ['Fiche de ressource complète', '—', 'L', 'L', 'L', 'L', 'L'],
    ['Téléchargement', '—', 'L', 'L', 'L', 'L', 'L'],
    ['Favoris et progression', '—', 'LÉ', 'LÉ', 'LÉ', '—', '—'],
    ['Dépôt d’une ressource', '—', '—', 'LÉ', 'LÉ', '—', 'L'],
    ['Publication directe', '—', '—', '—', 'LÉ', '—', 'A'],
    ['Banque de questions', '—', '—', 'LÉ', 'LÉ', '—', 'L'],
    ['TD, TP, exposés, examens', '—', 'L (assignés)', 'LÉ', 'LÉ', 'L', '—'],
    ['Laboratoire numérique', '—', 'L', 'LÉ', 'LÉ', '—', '—'],
    ['Manuels et QR codes', '—', '—', 'L', 'LÉ', '—', 'L'],
    ['Statistiques d’une ressource', '—', '—', 'L (siennes)', 'L', 'L (étab.)', 'L'],
    ['Groupes et classes', '—', 'L', 'LÉ', 'L', 'LÉ', '—'],
    ['Forum', '—', 'LÉ', 'LÉ', 'LÉ', 'L', 'LÉA'],
    ['Comptes de l’établissement', '—', '—', '—', '—', 'LÉ', '—'],
    ['Vérification des dépôts', '—', '—', '—', '—', '—', 'LÉA'],
    ['Paramétrage du fonds', '—', '—', '—', '—', '—', 'LÉ'],
    ['Journal d’audit', '—', '—', '—', '—', '—', 'L'],
  ], [2400, 1100, 1300, 1200, 1200, 1100, 1000]),
  h2('6.3 Permissions granulaires'),
  puces([
    "Un enseignant peut restreindre un TD à ses classes : les autres comptes ne le voient pas, même par recherche.",
    "Un éditeur publie sans passer par la modération ; ses publications restent journalisées et révocables.",
    "Un administrateur d'établissement ne voit jamais le contenu des messages du forum, seulement les volumes d'activité.",
    "Un modérateur ne peut pas modifier le contenu d'un dépôt : il approuve ou renvoie avec un commentaire obligatoire.",
  ]),
  saut(),
);

/* ========================================================================= */
/* 7. Modèle multi-établissement                                             */
/* ========================================================================= */
A(
  h1('Modèle multi-établissement'),
  h2('7.1 Architecture logique'),
  p("Le fonds documentaire est commun : une ressource publiée est visible de tous. Ce qui est cloisonné, c'est le travail de classe — groupes, partages, assignations, statistiques d'établissement. Un établissement est donc une enveloppe de comptes et de groupes posée sur un fonds partagé, à l'inverse d'un SIRH où tout est cloisonné par défaut."),
  mono([
    '            ┌──────────────────────────────────────────────┐',
    '            │           FONDS COMMUN (public)              │',
    '            │  ressources · manuels · parcours · méthodes  │',
    '            └───────────────┬──────────────────────────────┘',
    '                            │  lecture pour tous les comptes',
    '        ┌───────────────────┼───────────────────┐',
    '        │                   │                   │',
    '  ┌─────▼──────┐      ┌─────▼──────┐      ┌─────▼──────┐',
    '  │ Lycée A    │      │ Collège B  │      │ Compte     │',
    '  │ classes    │      │ classes    │      │ individuel │',
    '  │ groupes    │      │ groupes    │      │ favoris    │',
    '  │ partages   │      │ partages   │      │ progression│',
    '  └────────────┘      └────────────┘      └────────────┘',
    '     cloisonnés          cloisonnés          personnel',
  ]),
  h2('7.2 Règles'),
  puces([
    "Une ressource publiée appartient au fonds commun ; elle n'est jamais rattachée à un établissement.",
    "Un groupe, une classe, un partage et une assignation appartiennent à un établissement et ne sortent pas de son périmètre.",
    "Un enseignant peut appartenir à plusieurs établissements ; son dépôt reste sa propriété personnelle.",
    "Un élève appartient à un seul établissement à la fois ; un changement d'école transfère ses groupes mais conserve ses favoris et sa progression.",
    "Les statistiques d'un établissement n'agrègent que ses propres comptes ; aucune comparaison inter-établissements n'est exposée.",
  ]),
  h2('7.3 Isolation des données'),
  puces([
    "Identification — l'identifiant d'établissement est porté par la session, jamais par un paramètre de requête.",
    "Requête — toute lecture de groupe, de partage ou de statistique est filtrée par cet identifiant côté serveur.",
    "Journal — toute tentative d'accès à un groupe d'un autre établissement est enregistrée avec l'auteur et l'adresse visée.",
  ]),
  saut(),
);

/* ========================================================================= */
/* 8. Architecture fonctionnelle — les 14 modules                            */
/* ========================================================================= */
const module_ = (num, titre, objet, fonctions, regles, remarque) => {
  const blocs = [
    h2(`Module ${num} — ${titre}`),
    p(`Objet : ${objet}`),
    h3('Fonctionnalités'),
    puces(fonctions),
    h3('Règles de gestion'),
    puces(regles),
  ];
  if (remarque) blocs.push(note(remarque));
  return blocs;
};

A(
  h1('Architecture fonctionnelle — les 14 modules'),

  ...module_(1, 'Catalogue et fonds documentaire',
    "constituer le référentiel unique des ressources.",
    [
      "Création d'une ressource avec identifiant généré automatiquement (format RES-2026-00147)",
      "Métadonnées obligatoires : titre, résumé, famille, type, format, discipline, niveau, mots-clés",
      "Rattachement facultatif : manuel d'origine, chapitre, compétence visée",
      "Pièce jointe (document, image, vidéo, audio) ou lien externe vérifié",
      "Auteur, licence d'utilisation et date de publication",
      "Statuts : brouillon, en vérification, publiée, archivée",
      "Recherche plein texte et filtrage croisé discipline × niveau × type × format",
      "Affichage en grille ou en liste, filtres portés par l'adresse",
    ],
    [
      "RG-CAT-01 : l'identifiant d'une ressource est unique, immuable et non réattribuable.",
      "RG-CAT-02 : la suppression est interdite ; seul l'archivage est possible, car des QR codes imprimés peuvent pointer vers la ressource.",
      "RG-CAT-03 : toute modification de métadonnées crée une entrée dans l'historique.",
      "RG-CAT-04 : une ressource sans discipline ni niveau ne peut pas être publiée.",
      "RG-CAT-05 : une ressource archivée reste servie sous forme de page d'information renvoyant vers son chapitre.",
    ],
    "Importation en masse : un import CSV avec modèle téléchargeable et rapport d'erreurs ligne par ligne conditionne la reprise du fonds éditorial existant."),

  ...module_(2, 'Ressources pédagogiques',
    "fournir les supports directement exploitables en classe.",
    [
      "Six familles : fiches de préparation, fiches d'activités, présentations de cours, guides et manuels, plans de leçon, autres ressources",
      "Fiche détaillée : aperçu, auteur, niveau, format, poids, licence, avis",
      "Téléchargement au format d'origine et aperçu en ligne quand le format le permet",
      "Notation par étoiles et commentaires des enseignants",
      "Ressources liées : même chapitre, même compétence, même auteur",
      "Deux vues distinctes : catalogue enseignant et catalogue élève",
    ],
    [
      "RG-PED-01 : une ressource destinée aux élèves est également visible des enseignants ; l'inverse n'est pas vrai.",
      "RG-PED-02 : un avis est unique par compte et par ressource, et modifiable.",
      "RG-PED-03 : le compteur de téléchargements n'est incrémenté qu'une fois par compte et par jour.",
    ]),

  ...module_(3, 'Ressources méthodologiques',
    "enseigner la manière d'enseigner et la manière d'apprendre.",
    [
      "Côté enseignant : méthodes, guides pratiques, fiches méthode, techniques, classées par approche pédagogique",
      "Côté élève : thèmes de travail — prendre des notes, organiser son temps, mémoriser, réviser, travailler en groupe",
      "Durée de lecture affichée et filtrable",
      "Compétence visée et durée d'application pour l'enseignant",
      "Progression personnelle de l'élève sur l'ensemble des méthodes",
    ],
    [
      "RG-MET-01 : une méthode est rattachée soit à l'espace enseignant, soit à l'espace élève, jamais aux deux avec le même texte.",
      "RG-MET-02 : la progression d'un élève est dérivée des méthodes consultées jusqu'au bout, jamais saisie.",
    ]),

  ...module_(4, 'Ressources multimédias',
    "offrir des contenus audiovisuels adaptés à la bande passante disponible.",
    [
      "Types : vidéo, audio, animation, podcast, documentaire, webinaire",
      "Lecture en flux progressif par requêtes Range, sans téléchargement complet",
      "Durée, transcription et sous-titres quand ils existent",
      "Historique de visionnage et reprise à l'endroit interrompu",
      "Playlist d'apprentissage constituée par l'élève ou l'enseignant",
    ],
    [
      "RG-MUL-01 : toute vidéo publiée dispose d'une vignette et d'une durée renseignée.",
      "RG-MUL-02 : une ressource de plus de 50 Mo est refusée au dépôt et doit passer par la voie éditoriale.",
      "RG-MUL-03 : la reprise de lecture est enregistrée toutes les quinze secondes pour survivre à une coupure.",
    ]),

  ...module_(5, 'Cartes géographiques et atlas',
    "mettre à disposition un fonds cartographique conforme au programme.",
    [
      "Cartes physiques, politiques, thématiques et historiques",
      "Cartes muettes à imprimer pour les évaluations",
      "Zoom et consultation hors ligne après téléchargement",
      "Rattachement au chapitre de géographie ou d'histoire concerné",
    ],
    [
      "RG-CAR-01 : toute carte porte sa source et sa date d'édition.",
      "RG-CAR-02 : une carte muette est systématiquement publiée en regard de sa version légendée.",
    ]),

  ...module_(6, 'Banque de questions et quiz',
    "capitaliser les questions et composer des évaluations rapidement.",
    [
      "Types de questions : choix unique, choix multiple, vrai-faux, texte à trous, appariement, réponse courte, question ouverte",
      "Métadonnées : discipline, niveau, chapitre, compétence, difficulté, durée estimée",
      "Composition d'un quiz par sélection manuelle ou tirage aléatoire sur critères",
      "Mélange des questions et des propositions, barème par question",
      "Reprises autorisées ou non, correction immédiate ou différée",
      "Statistiques par question : taux de réussite, discrimination, questions à revoir",
    ],
    [
      "RG-QUI-01 : une question utilisée dans un quiz publié ne peut plus être modifiée ; elle est dupliquée en nouvelle version.",
      "RG-QUI-02 : un quiz sans barème complet ne peut pas être publié.",
      "RG-QUI-03 : le tirage aléatoire respecte la répartition par chapitre demandée.",
    ]),

  ...module_(7, 'Travaux dirigés et travaux pratiques',
    "structurer le travail guidé des élèves.",
    [
      "Création en cinq étapes : informations générales, contenu et exercices, pièces jointes, paramètres, publication",
      "Objectifs d'apprentissage et consignes générales en éditeur enrichi",
      "Exercices numérotés, durée estimée, niveau de difficulté",
      "Pour les TP : matériel requis, protocole, consignes de sécurité, compte rendu attendu",
      "Barème, date limite, remise en ligne, visibilité par classe",
      "Duplication d'un TD existant comme modèle",
    ],
    [
      "RG-TRV-01 : un TD publié et assigné ne peut plus être modifié sur le fond ; une nouvelle version est créée.",
      "RG-TRV-02 : la somme des points des exercices doit être égale au barème déclaré.",
      "RG-TRV-03 : un TP comportant un protocole expérimental exige une consigne de sécurité renseignée.",
    ]),

  ...module_(8, 'Exposés, dissertations et examens',
    "couvrir les productions longues et les évaluations sommatives.",
    [
      "Exposés : sujet, type (recherche, analyse, expérimental, argumentatif), durée de présentation, grille d'évaluation orale",
      "Dissertations : type (argumentatif, délibératif, explicatif, réflexif), nombre de mots attendu, compétences visées, critères",
      "Examens : type (formatif, sommatif, pratique), durée, période, composition par sections",
      "Assignation à une ou plusieurs classes, suivi des remises",
      "Correction avec note sur 100 et retour personnalisé",
      "Carnet de notes consolidé par classe",
    ],
    [
      "RG-EXA-01 : un examen planifié est verrouillé à l'ouverture de sa période.",
      "RG-EXA-02 : une copie corrigée ne peut pas être modifiée sans trace au journal.",
      "RG-EXA-03 : la moyenne d'une classe n'est calculée qu'à partir de 60 % de copies corrigées.",
    ]),

  ...module_(9, 'Laboratoire numérique',
    "permettre l'expérimentation scientifique sans matériel.",
    [
      "Quatre types : expérience guidée, exploration libre, simulation théorique, démonstration interactive",
      "Assistant de création en cinq étapes avec aperçu en direct",
      "Disciplines couvertes : physique, chimie, biologie, mathématiques, sciences de la terre, technologie",
      "Paramètres modifiables par l'élève et relevé des mesures",
      "Partage avec les classes et suivi du temps d'utilisation",
      "Import d'une simulation au format HTML5",
    ],
    [
      "RG-LAB-01 : une simulation doit s'exécuter entièrement dans le navigateur, sans dépendance réseau après chargement.",
      "RG-LAB-02 : toute expérience guidée comporte au moins un objectif d'apprentissage et une question de vérification.",
    ]),

  ...module_(10, 'Tuteur intelligent',
    "orienter l'élève vers la ressource utile au bon moment.",
    [
      "Recommandations fondées sur le niveau, la discipline et les résultats aux quiz",
      "Détection des chapitres fragiles à partir des évaluations passées",
      "Suggestion de la méthode de travail correspondant à la difficulté observée",
      "Parcours de remédiation proposé à l'enseignant pour un groupe d'élèves",
    ],
    [
      "RG-TUT-01 : aucune recommandation n'est faite sur moins de trois évaluations.",
      "RG-TUT-02 : les recommandations sont explicables : l'élève voit pourquoi une ressource lui est proposée.",
      "RG-TUT-03 : aucune donnée de résultat n'est exposée à un autre élève, ni à un autre établissement.",
    ],
    "Ce module relève de la version 2.0 : il suppose un historique d'évaluations suffisant pour être pertinent."),

  ...module_(11, 'Manuels hybrides et QR codes',
    "relier l'imprimé au numérique — module détaillé à la section 9.",
    [
      "Déclaration d'un manuel : ISBN, titre, niveau, discipline, chapitres",
      "Association d'une ou plusieurs ressources à chaque chapitre ou page",
      "Génération du QR code et de l'adresse courte de chaque ressource",
      "Export d'une planche de QR codes pour l'imprimeur",
      "Statistiques de scan par manuel, par chapitre et par période",
    ],
    [
      "RG-MAN-01 : l'adresse courte d'une ressource est immuable dès sa première impression.",
      "RG-MAN-02 : une ressource associée à un manuel imprimé ne peut jamais être supprimée.",
      "RG-MAN-03 : un QR code exporté porte la version du manuel, pour distinguer les tirages.",
    ]),

  ...module_(12, 'Communauté : partage, forum et groupes',
    "faire circuler les pratiques entre enseignants et soutenir les élèves.",
    [
      "Partage de ressources : dépôt, collections, abonnement à un contributeur, classement des contributeurs",
      "Forum : catégories, sujets, réponses, sujets résolus, règles affichées",
      "Groupes : groupes de classe, groupes collaboratifs entre enseignants, groupes personnels, groupes d'étude entre élèves",
      "Annonces d'un enseignant à ses classes",
      "Signalement d'un contenu inapproprié",
    ],
    [
      "RG-COM-01 : le forum d'entraide des élèves est modéré par les enseignants de l'établissement.",
      "RG-COM-02 : un signalement retire provisoirement le message en attendant décision.",
      "RG-COM-03 : un groupe sans activité depuis douze mois est archivé automatiquement.",
    ]),

  ...module_(13, 'Établissements et classes',
    "donner à une école la maîtrise de ses comptes et de ses usages.",
    [
      "Création des comptes enseignants et élèves, individuellement ou par import",
      "Constitution des classes et rattachement des enseignants",
      "Assignation de ressources ou de parcours à une classe",
      "Rapports d'usage : ressources consultées, temps passé, progression moyenne",
      "Gestion de l'abonnement et de la facturation",
    ],
    [
      "RG-ETA-01 : un compte élève créé par un établissement arrive directement sur son espace, sans étape d'inscription.",
      "RG-ETA-02 : les rapports n'exposent jamais le détail nominatif des consultations d'un élève à un autre enseignant que le sien.",
      "RG-ETA-03 : la fin d'un abonnement suspend les fonctions de classe mais conserve les comptes et les favoris.",
    ]),

  ...module_(14, 'Modération et administration éditoriale',
    "garantir que rien n'atteint le fonds sans contrôle.",
    [
      "File des dépôts en attente, triée par ancienneté",
      "Prévisualisation exacte de la ressource telle qu'elle paraîtra",
      "Approbation, ou renvoi avec commentaire obligatoire",
      "Paramétrage des familles, catégories, disciplines, niveaux et formats",
      "Retrait d'une ressource publiée avec motif",
      "Journal d'audit consultable et exportable",
    ],
    [
      "RG-MOD-01 : un renvoi sans commentaire est refusé par le système.",
      "RG-MOD-02 : un modérateur ne peut pas approuver son propre dépôt.",
      "RG-MOD-03 : toute décision de modération est journalisée avec auteur, date et motif.",
      "RG-MOD-04 : un retrait de ressource déclenche la mise en place d'une page de redirection vers le chapitre.",
    ]),
  saut(),
);

/* ========================================================================= */
/* 9. Moteur de liaison imprimé-numérique                                    */
/* ========================================================================= */
A(
  h1('Module manuels hybrides — moteur de liaison imprimé-numérique'),
  p("C'est le module qui distingue ÉDUCA Diffusion de toute bibliothèque numérique : un manuel imprimé cesse d'être un objet clos pour devenir une porte d'entrée. Le moteur est écrit dans la plateforme, sans service externe : ni générateur en ligne, ni bibliothèque tierce, ni dépendance dont la disparition rendrait un tirage inutilisable."),

  h2('9.1 Chaîne de production'),
  mono([
    '  Ressource publiée',
    '        │',
    '        ▼  attribution d’une adresse courte immuable',
    '  https://diffusion.educa.ht/r/RES-12564',
    '        │',
    '        ▼  encodage (mode octet, correction M, version 1 à 6)',
    '  matrice de modules 21×21 à 41×41',
    '        │',
    '        ├──▶ rendu SVG ─────▶ affichage dans la plateforme',
    '        ├──▶ rendu SVG ─────▶ téléchargement pour l’imprimeur',
    '        └──▶ planche PDF ───▶ export par chapitre pour la maquette du manuel',
    '        │',
    '        ▼  impression',
    '  manuel distribué  ──scan──▶  /r/RES-12564  ──▶  ressource + compteur',
  ]),

  h2("9.2 Choix d'encodage"),
  tbl(['Paramètre', 'Valeur retenue', 'Justification'], [
    ['Mode', 'Octet (UTF-8)', 'Une adresse courte contient des minuscules et des chiffres'],
    ['Niveau de correction', 'M — environ 15 % de tolérance', 'Compromis entre densité et robustesse à l’encre et au pli'],
    ['Versions supportées', '1 à 6, soit 106 octets utiles', 'Une adresse courte dépasse rarement 40 caractères'],
    ['Masque', 'Choisi parmi huit par calcul de pénalité', 'Évite les motifs qui gênent la lecture optique'],
    ['Information de format', 'BCH(15,5) puis masque fixe', 'Conforme à la norme ISO/IEC 18004'],
    ['Logo central', '18 % de la largeur, fond blanc', 'Reste sous le seuil de tolérance du niveau M'],
  ], [2100, 3200, 4000]),

  h2("9.3 Contraintes d'impression"),
  tbl(['Contrainte', 'Valeur minimale', 'Raison'], [
    ['Côté du symbole', '20 mm', 'Lecture fiable par un téléphone d’entrée de gamme à 25 cm'],
    ['Taille d’un module', '0,5 mm', 'En deçà, l’encre bave et fusionne les modules'],
    ['Zone de silence', '4 modules', 'Exigence de la norme ; un QR collé au texte devient illisible'],
    ['Contraste', 'Noir sur blanc, 60 % minimum', 'Les fonds colorés font échouer la détection'],
    ['Emplacement', 'Marge extérieure, jamais dans la reliure', 'Un code pris dans le pli ne se scanne pas'],
    ['Résolution d’export', '600 ppp minimum', 'Le SVG est vectoriel ; la rasterisation doit rester nette'],
  ], [2400, 2700, 4200]),

  h2("9.4 Cycle de vie d'un lien imprimé"),
  mono([
    '  [ressource publiée] ──▶ adresse courte attribuée ──▶ QR exporté ──▶ imprimé',
    '                                    │',
    '                     ┌──────────────┼───────────────┐',
    '                     ▼              ▼               ▼',
    '              ressource mise    ressource       ressource',
    '              à jour            remplacée       retirée',
    '                     │              │               │',
    '                     ▼              ▼               ▼',
    '              même adresse    redirection vers  page d’information',
    '              contenu à jour  la nouvelle       + chapitre + voisines',
    '',
    '  Dans les trois cas, l’adresse imprimée continue de répondre.',
  ]),

  h2('9.5 Mesure des usages'),
  puces([
    "Chaque scan est comptabilisé côté serveur, avec la date, le manuel et le chapitre d'origine.",
    "Les compteurs sont agrégés par jour : aucune trace individuelle n'est conservée pour un visiteur non connecté.",
    "L'éditeur dispose du détail par manuel, par chapitre et par période ; l'auteur, du détail de ses ressources.",
    "Un pic de scans sur un chapitre signale un besoin pédagogique — c'est la boucle de retour que l'imprimé seul ne donne jamais.",
  ]),

  h2('9.6 Exigences de qualité du moteur'),
  tbl(['Exigence', 'Contrôle associé'], [
    ['Le mot de code doit être un code Reed-Solomon valide', 'Les syndromes du mot complet sont tous nuls'],
    ['L’information de format doit être conforme', 'Reste BCH nul après retrait du masque fixe'],
    ['La trame doit restituer exactement le texte', 'Relecture module par module, démasquage et désentrelacement'],
    ['Les motifs obligatoires doivent être présents', 'Trois motifs de repérage, synchronisation, module toujours noir'],
    ['Le rendu doit rester lisible après impression', 'Vérification au téléphone sur épreuve imprimée avant tirage'],
  ], [4500, 4800]),
  note("Les quatre premiers contrôles sont automatisés et rejouables (tools/verify-qr.js). Le cinquième ne peut pas l'être : aucune validation algorithmique ne remplace un scan réel sur papier avant un tirage de plusieurs milliers d'exemplaires."),
  saut(),
);

/* ========================================================================= */
/* 10. Contribution enseignante et modération                                */
/* ========================================================================= */
A(
  h1('Contribution enseignante et modération'),
  h2("10.1 Pourquoi ouvrir la contribution"),
  p("Un fonds alimenté uniquement par la maison d'édition croît au rythme d'une équipe éditoriale. Un fonds alimenté par les enseignants croît au rythme du pays. L'ouverture de la contribution est donc la principale source de croissance du catalogue — à condition que rien n'atteigne le public sans contrôle."),
  h2('10.2 Circuit de publication'),
  mono([
    '  Enseignant                     Plateforme                 Modérateur',
    '      │                              │                          │',
    '      │─ dépôt (fichier ou lien) ───▶│                          │',
    '      │                              │─ brouillon enregistré    │',
    '      │─ soumettre à vérification ──▶│                          │',
    '      │                              │─ file de modération ────▶│',
    '      │                              │                          │─ prévisualise',
    '      │                              │◀── approuver ────────────│',
    '      │                              │─ adresse courte + QR     │',
    '      │◀── ressource publiée ────────│                          │',
    '      │                              │◀── renvoyer + motif ─────│',
    '      │◀── commentaire affiché ──────│                          │',
    '      │─ corrige et resoumet ───────▶│                          │',
  ]),
  h2('10.3 Grille de vérification'),
  tbl(['Critère', 'Ce que le modérateur vérifie'], [
    ['Conformité au programme', 'Le niveau et la discipline annoncés correspondent au contenu réel'],
    ['Exactitude', 'Aucune erreur factuelle, aucun corrigé faux'],
    ['Droits', 'La paternité est déclarée ; aucun extrait protégé n’est reproduit sans licence'],
    ['Qualité formelle', 'Document lisible, orthographe correcte, illustrations nettes'],
    ['Métadonnées', 'Titre explicite, résumé informatif, mots-clés utiles à la recherche'],
    ['Sécurité', 'Pour un TP : consignes de sécurité présentes et suffisantes'],
    ['Doublon', 'La ressource n’existe pas déjà sous une autre forme'],
  ], [2600, 6700]),
  h2('10.4 Reconnaissance des contributeurs'),
  puces([
    "Le nom de l'auteur figure sur chaque ressource et sur son profil public.",
    "Un classement des contributeurs par nombre de ressources et par téléchargements est affiché dans l'espace de partage.",
    "Les statistiques d'usage sont visibles de l'auteur : combien d'enseignants utilisent réellement sa ressource.",
    "Une rétribution des contributions les plus utilisées est à l'étude pour la version 2.0 (voir section 28).",
  ]),
  h2('10.5 Objectif de délai'),
  tbl(['Indicateur', 'Cible'], [
    ['Délai de première décision sur un dépôt', 'Moins de 5 jours ouvrables'],
    ['Taux de dépôts approuvés au premier passage', 'Supérieur à 60 %'],
    ['Taux de dépôts abandonnés après renvoi', 'Inférieur à 25 %'],
  ], [5200, 4100]),
  saut(),
);

/* ========================================================================= */
/* 11. Parcours d'apprentissage et progression                               */
/* ========================================================================= */
A(
  h1("Parcours d'apprentissage et progression de l'élève"),
  h2('11.1 Structure d’un parcours'),
  p("Un parcours est une suite ordonnée d'étapes — ressource à consulter, exercice à faire, quiz à réussir — construite autour d'un objectif : réviser les bases, s'entraîner, approfondir, s'évaluer. Il donne à l'élève ce qu'un catalogue seul ne donne pas : un ordre et un horizon."),
  tbl(['Parcours type', 'Contenu', 'Objectif'], [
    ['Réviser les bases', 'Cours et exercices d’application directe', 'Remettre à niveau avant un chapitre'],
    ['S’entraîner', 'Exercices interactifs progressifs', 'Automatiser une technique'],
    ['Approfondir', 'Leçons et activités complémentaires', 'Aller au-delà du programme'],
    ['S’évaluer', 'Quiz et examens blancs', 'Se situer avant une évaluation réelle'],
  ], [2200, 4000, 3100]),
  h2('11.2 Mesure de la progression'),
  puces([
    "Une étape est acquise quand la ressource a été consultée jusqu'au bout, ou quand le quiz est réussi au-dessus du seuil.",
    "Le pourcentage affiché est dérivé du nombre d'étapes acquises sur le total ; il n'est jamais saisi.",
    "La progression est personnelle et n'est visible que de l'élève et de ses enseignants.",
    "Une reprise est toujours possible : un parcours n'est jamais verrouillé.",
  ]),
  h2('11.3 Continuité'),
  puces([
    "La reprise « Continue ton apprentissage » ramène l'élève à la dernière ressource interrompue, à l'endroit exact pour une vidéo.",
    "Les favoris survivent au changement d'établissement et de niveau.",
    "Un élève qui passe au niveau supérieur conserve l'historique de ses parcours antérieurs.",
  ]),
  saut(),
);

/* ========================================================================= */
/* 12. Espaces enseignant et élève                                           */
/* ========================================================================= */
A(
  h1('Espaces enseignant et élève'),
  h2('12.1 Principe de la double vue'),
  p("Les modules communs aux deux publics — tableau de bord, ressources pédagogiques, ressources méthodologiques — sont servis par une seule adresse. Le rôle du compte détermine la vue. Un lien transmis par un enseignant à ses élèves ouvre donc la version élève, sans redirection ni adresse parallèle à maintenir."),
  h2('12.2 Ce que contient chaque espace'),
  tbl(['Espace enseignant', 'Espace élève'], [
    ['Tableau de bord : volumes du fonds, ressources récentes, disciplines, ressource du jour, partage QR, statistiques', 'Tableau de bord : travail de la semaine, reprise, raccourcis'],
    ['Catalogues par famille, filtres avancés, dépôt', 'Catalogues par discipline et par thème, recommandations, nouveautés'],
    ['Banque de questions, quiz, TD, TP, exposés, dissertations, examens', 'Devoirs et TD assignés, quiz, examens blancs, corrections'],
    ['Laboratoire : création, simulations, expériences', 'Laboratoire : simulations à explorer'],
    ['Partage, forum, groupes collaboratifs et de classe', 'Forum d’entraide, groupes d’étude'],
    ['Statistiques d’usage de ses ressources', 'Progression, favoris, parcours'],
  ], [4650, 4650]),
  h2('12.3 Navigation'),
  puces([
    "Espace enseignant : Tableau de bord en tête, puis Ressources, Évaluation, Outils & logiciels, Communauté, et un bouton permanent « Déposer une ressource ».",
    "Espace élève : Tableau de bord, puis Ressources, Apprendre, Évaluation, Communauté, et un encadré d'aide vers l'enseignant.",
    "Les adresses héritées restent routées même lorsqu'elles ne figurent plus dans la barre : aucun lien partagé ne se casse.",
  ]),
  saut(),
);

/* ========================================================================= */
/* 13. Tableaux de bord et rapports                                          */
/* ========================================================================= */
A(
  h1('Tableaux de bord et rapports'),
  h2('13.1 Tableaux de bord'),
  tbl(['Destinataire', 'Contenu'], [
    ['Enseignant', 'Volumes du fonds par famille, ressources récentes, disciplines populaires, ressource du jour et son partage, statistiques de scans et de téléchargements'],
    ['Élève', 'Travail à faire cette semaine, reprise de la dernière ressource, progression des parcours, favoris'],
    ['Établissement', 'Comptes actifs, ressources les plus consultées, progression moyenne par classe, taux d’usage hebdomadaire'],
    ['Éditeur', 'Scans par manuel et par chapitre, téléchargements, ressources sans usage'],
    ['Administration', 'File de modération, délais de décision, volume de dépôts, signalements'],
  ], [2300, 7000]),
  h2('13.2 Rapports exportables'),
  puces([
    "Usage d'un manuel sur une période — scans par chapitre, comparaison entre tirages.",
    "Activité d'un établissement — comptes actifs, ressources consultées, progression par classe.",
    "Production d'un contributeur — ressources déposées, publiées, renvoyées, usages.",
    "Couverture du fonds — ressources par discipline et par niveau, chapitres non couverts.",
  ]),
  note("Le rapport de couverture est le plus important pour la direction éditoriale : il montre les trous du fonds, donc le programme de production des mois suivants."),
  saut(),
);

/* ========================================================================= */
/* 14. Système de notifications                                              */
/* ========================================================================= */
A(
  h1('Système de notifications'),
  h2('14.1 Canaux'),
  tbl(['Canal', 'Version', 'Usage'], [
    ['Dans la plateforme', 'v1.0', 'Cloche et compteur, journal des notifications'],
    ['Courriel', 'v2.0', 'Décision de modération, assignation, échéance'],
    ['SMS', 'v2.0', 'Rappel d’échéance pour les élèves sans courriel'],
    ['WhatsApp', 'v2.0', 'Annonces d’un enseignant à sa classe'],
  ], [2600, 1600, 5100]),
  h2('14.2 Événements notifiés'),
  tbl(['Événement', 'Destinataire'], [
    ['Dépôt approuvé ou renvoyé', 'Auteur du dépôt'],
    ['Nouveau dépôt en attente', 'Modérateurs'],
    ['Ressource assignée ou partagée', 'Élèves de la classe'],
    ['Échéance d’un devoir à 48 h', 'Élèves concernés'],
    ['Copie corrigée disponible', 'Élève'],
    ['Réponse à un sujet suivi', 'Auteur du sujet'],
    ['Signalement d’un contenu', 'Modérateurs'],
    ['Nouvelle ressource dans une discipline suivie', 'Enseignants abonnés'],
  ], [4900, 4400]),
  h2('14.3 Règles'),
  puces([
    "Toute notification est consultable dans la plateforme, même si le canal externe a échoué.",
    "Les notifications sont groupées : un enseignant recevant dix dépôts en attente reçoit un seul message.",
    "Chaque utilisateur peut désactiver les canaux externes, jamais le journal interne.",
  ]),
  saut(),
);

/* ========================================================================= */
/* 15. Exigences fonctionnelles                                              */
/* ========================================================================= */
A(
  h1('Exigences fonctionnelles'),
  tbl(['Réf.', 'Exigence', 'Priorité'], [
    ['EF-01', 'Le système doit gérer un fonds de ressources avec métadonnées obligatoires', 'Critique'],
    ['EF-02', 'Le système doit attribuer un identifiant unique et immuable à chaque ressource', 'Critique'],
    ['EF-03', 'Le système doit générer un QR code et une adresse courte par ressource publiée', 'Critique'],
    ['EF-04', 'Le système doit servir une ressource scannée sans exiger de compte', 'Critique'],
    ['EF-05', 'Le système doit filtrer le catalogue par discipline, niveau, type et format', 'Critique'],
    ['EF-06', 'Le système doit conserver les filtres dans l’adresse pour qu’une recherche soit partageable', 'Élevée'],
    ['EF-07', 'Le système doit servir deux vues distinctes selon le rôle sur une même adresse', 'Critique'],
    ['EF-08', 'Le système doit permettre le dépôt d’une ressource par un enseignant', 'Critique'],
    ['EF-09', 'Le système doit soumettre tout dépôt à vérification avant publication', 'Critique'],
    ['EF-10', 'Le système doit exiger un commentaire lors du renvoi d’un dépôt', 'Élevée'],
    ['EF-11', 'Le système doit interdire la suppression d’une ressource liée à un manuel imprimé', 'Critique'],
    ['EF-12', 'Le système doit gérer une banque de questions réutilisable', 'Élevée'],
    ['EF-13', 'Le système doit composer des quiz par sélection ou tirage aléatoire', 'Élevée'],
    ['EF-14', 'Le système doit permettre la création de TD, TP, exposés, dissertations et examens', 'Critique'],
    ['EF-15', 'Le système doit assigner un travail à une ou plusieurs classes', 'Élevée'],
    ['EF-16', 'Le système doit enregistrer les remises et permettre la correction notée', 'Élevée'],
    ['EF-17', 'Le système doit tenir un carnet de notes par classe', 'Moyenne'],
    ['EF-18', 'Le système doit servir les vidéos en flux progressif par requêtes Range', 'Élevée'],
    ['EF-19', 'Le système doit enregistrer la reprise de lecture d’un média', 'Moyenne'],
    ['EF-20', 'Le système doit proposer des parcours d’apprentissage et mesurer la progression', 'Élevée'],
    ['EF-21', 'Le système doit gérer les favoris de chaque compte', 'Moyenne'],
    ['EF-22', 'Le système doit comptabiliser vues, scans et téléchargements côté serveur', 'Élevée'],
    ['EF-23', 'Le système doit exposer les statistiques d’usage à l’auteur et à l’éditeur', 'Élevée'],
    ['EF-24', 'Le système doit permettre à un établissement de créer ses comptes en lot', 'Élevée'],
    ['EF-25', 'Le système doit cloisonner groupes, partages et rapports par établissement', 'Critique'],
    ['EF-26', 'Le système doit fournir un forum et des groupes modérés', 'Moyenne'],
    ['EF-27', 'Le système doit permettre le signalement d’un contenu', 'Élevée'],
    ['EF-28', 'Le système doit tenir un journal d’audit des actions sensibles', 'Critique'],
    ['EF-29', 'Le système doit permettre l’import en masse de ressources par CSV', 'Élevée'],
    ['EF-30', 'Le système doit exporter une planche de QR codes pour l’imprimeur', 'Élevée'],
    ['EF-31', 'Le système doit rediriger une ressource retirée vers son chapitre', 'Critique'],
    ['EF-32', 'Le système doit encaisser le paiement d’un contenu payant en gourdes', 'Moyenne'],
    ['EF-33', 'Le système doit permettre la création de laboratoires numériques', 'Moyenne'],
    ['EF-34', 'Le système doit notifier les événements dans la plateforme', 'Élevée'],
  ], [900, 6600, 1800]),
  saut(),
);

/* ========================================================================= */
/* 16. Exigences non fonctionnelles                                          */
/* ========================================================================= */
A(
  h1('Exigences non fonctionnelles'),
  tbl(['Domaine', 'Exigence', 'Cible mesurable'], [
    ['Performance', 'Rendu côté serveur, sans framework client', 'Moins de 100 ms par page'],
    ['Sobriété réseau', 'Pages légères, aucune police distante, images vectorielles', 'Moins de 150 Ko hors médias'],
    ['Disponibilité', 'Aucune dépendance externe bloquante', '99 % sur le mois'],
    ['Résilience', 'Le fonds reste consultable si la passerelle de paiement tombe', 'Aucune indisponibilité du catalogue'],
    ['Scalabilité', 'PostgreSQL en socle, réserve de connexions', 'Écritures concurrentes d’une classe entière'],
    ['Sécurité', 'Échappement systématique, mots de passe scrypt, cookies signés', 'Aucune injection possible en sortie'],
    ['Accessibilité', 'Contrastes, clavier, focus visible, mouvement réduit', 'WCAG 2.1 niveau AA'],
    ['Compatibilité', 'Responsive et navigation escamotable', 'Utilisable dès 360 px de large'],
    ['Pérennité des liens', 'Adresse courte immuable après impression', '100 % des adresses imprimées répondent'],
    ['Sauvegarde', 'Copie quotidienne hors serveur, écriture atomique', 'Restauration testée chaque trimestre'],
    ['Journalisation', 'Actions sensibles horodatées', 'Fenêtre glissante de 5 000 entrées'],
    ['Coût d’exploitation', 'Aucune dépendance payante', 'Moins de 40 USD par mois'],
    ['Maintenabilité', 'Code commenté en français, zéro dépendance npm', 'Reprise par un tiers en moins d’une semaine'],
  ], [1900, 4700, 2700]),
  saut(),
);

/* ========================================================================= */
/* 17. Cas d'utilisation principaux                                          */
/* ========================================================================= */
const cas = (titre, lignes) => [h2(titre), tbl(['Rubrique', 'Contenu'], lignes, [2000, 7300])];

A(
  h1("Cas d'utilisation principaux"),
  ...cas("CU-01 — Ouvrir une ressource depuis un manuel imprimé", [
    ['Acteurs', 'Élève ou parent, Éditeur (producteur du manuel)'],
    ['Préconditions', 'Ressource publiée, QR code imprimé'],
    ['Déclencheur', 'Scan du code avec l’appareil photo du téléphone'],
    ['Scénario nominal', "1. Le navigateur ouvre l'adresse courte. 2. La plateforme résout la ressource. 3. Le scan est comptabilisé pour le manuel et le chapitre. 4. La ressource s'affiche, adaptée au petit écran. 5. Un encart propose la création d'un compte pour la mettre en favori."],
    ['Alternatives', "2a. Ressource retirée : page d'information listant le chapitre et les ressources voisines. 2b. Ressource remplacée : redirection permanente vers la nouvelle."],
    ['Résultat', 'Ressource consultée sans compte ; usage mesuré pour l’éditeur'],
  ]),
  ...cas("CU-02 — Déposer une ressource et la faire publier", [
    ['Acteurs', 'Enseignant, Modérateur'],
    ['Préconditions', 'Compte enseignant actif'],
    ['Déclencheur', 'Clic sur « Déposer une ressource »'],
    ['Scénario nominal', "1. L'enseignant renseigne les métadonnées et joint un fichier ou un lien. 2. Le dépôt est enregistré en brouillon. 3. Il le soumet à vérification. 4. Le modérateur prévisualise et décide. 5. À l'approbation, l'adresse courte et le QR code sont générés, la ressource paraît au catalogue."],
    ['Alternatives', "4a. Renvoi : un commentaire obligatoire est affiché à l'auteur, qui corrige et resoumet. 1a. Format ou taille refusés : message explicite, dépôt conservé."],
    ['Résultat', 'Aucune ressource au catalogue sans contrôle éditorial'],
  ]),
  ...cas("CU-03 — Préparer et assigner une évaluation", [
    ['Acteurs', 'Enseignant, Élèves'],
    ['Préconditions', 'Compte enseignant, au moins une classe rattachée'],
    ['Déclencheur', 'Création d’un quiz ou d’un examen'],
    ['Scénario nominal', "1. L'enseignant puise dans la banque de questions par discipline, niveau et chapitre. 2. Il complète par tirage aléatoire. 3. Il fixe le barème, la durée et les reprises. 4. Il assigne à ses classes avec une date limite. 5. Les élèves composent ; la correction automatique s'applique aux questions fermées. 6. L'enseignant corrige les questions ouvertes et publie les résultats."],
    ['Alternatives', "5a. Coupure pendant la composition : les réponses déjà saisies sont conservées et la reprise est possible."],
    ['Résultat', 'Évaluation composée en quelques minutes, résultats consolidés au carnet de notes'],
  ]),
  ...cas("CU-04 — Équiper un établissement", [
    ['Acteurs', 'Administrateur d’établissement, Enseignants, Élèves'],
    ['Préconditions', 'Abonnement établissement actif'],
    ['Déclencheur', 'Import du fichier des comptes'],
    ['Scénario nominal', "1. L'administrateur importe la liste des enseignants et des élèves. 2. Il constitue les classes et rattache les enseignants. 3. Les comptes reçoivent leurs identifiants. 4. Les élèves arrivent directement sur leur espace. 5. L'administrateur suit l'usage dans les rapports."],
    ['Alternatives', "1a. Lignes en erreur : rapport ligne par ligne, import partiel accepté."],
    ['Résultat', 'Établissement opérationnel en une séance de prise en main'],
  ]),
  ...cas("CU-05 — Publier un manuel hybride", [
    ['Acteurs', 'Éditeur, Imprimeur'],
    ['Préconditions', 'Manuel déclaré, ressources publiées'],
    ['Déclencheur', 'Préparation de la maquette du manuel'],
    ['Scénario nominal', "1. L'éditeur déclare le manuel et ses chapitres. 2. Il associe les ressources à chaque chapitre. 3. Il exporte la planche de QR codes. 4. L'imprimeur intègre les codes à la maquette. 5. Une épreuve est imprimée et scannée pour contrôle. 6. Le tirage est lancé ; les scans sont suivis par chapitre."],
    ['Alternatives', "5a. Échec de lecture sur épreuve : agrandissement du symbole ou déplacement hors reliure, nouvelle épreuve."],
    ['Résultat', 'Manuel imprimé relié à ses ressources, usage mesurable'],
  ]),
  saut(),
);

/* ========================================================================= */
/* 18. Modélisation UML                                                      */
/* ========================================================================= */
A(
  h1('Modélisation UML'),
  h2("18.1 Diagramme de cas d'utilisation"),
  mono([
    '                        ┌────────────────────────────────────────────┐',
    '                        │             ÉDUCA DIFFUSION                │',
    '   ┌──────────┐         │                                            │',
    '   │ Visiteur │─────────┼──○ Parcourir le catalogue                  │',
    '   └──────────┘         │  ○ Ouvrir une ressource par QR code        │',
    '   ┌──────────┐         │  ○ Créer un compte                         │',
    '   │  Élève   │─────────┼──○ Suivre un parcours · S’exercer          │',
    '   └──────────┘         │  ○ Mettre en favori · Forum d’entraide     │',
    '   ┌──────────┐         │  ○ Composer une évaluation assignée        │',
    '   │Enseignant│─────────┼──○ Chercher · Déposer une ressource        │',
    '   └──────────┘         │  ○ Créer TD, TP, quiz, examens             │',
    '   ┌──────────┐         │  ○ Assigner · Corriger · Partager          │',
    '   │ Éditeur  │─────────┼──○ Publier le fonds                        │',
    '   └──────────┘         │  ○ Déclarer un manuel · Exporter les QR    │',
    '   ┌──────────┐         │  ○ Consulter les scans                     │',
    '   │Admin éta.│─────────┼──○ Créer les comptes · Suivre les usages   │',
    '   └──────────┘         │                                            │',
    '   ┌──────────┐         │  ○ Vérifier les dépôts                     │',
    '   │Modérateur│─────────┼──○ Paramétrer le fonds · Auditer           │',
    '   └──────────┘         └────────────────────────────────────────────┘',
  ]),
  h2('18.2 Diagramme de séquence — publication et impression'),
  mono([
    ' Enseignant    Plateforme     Modérateur     MoteurQR      Éditeur/Imprimeur',
    '     │             │              │              │                │',
    '     │─ déposer ──▶│              │              │                │',
    '     │             │─ file ──────▶│              │                │',
    '     │             │◀─ approuver ─│              │                │',
    '     │             │─ adresse courte + encodage ▶│                │',
    '     │             │◀──────────── SVG ───────────│                │',
    '     │◀─ publiée ──│              │              │                │',
    '     │             │─ planche de QR par chapitre ───────────────▶ │',
    '     │             │              │              │   épreuve + scan test',
    '     │             │◀──────────── validation ────────────────────│',
    '     │             │              │              │      tirage lancé',
  ]),
  h2("18.3 Diagramme d'états — ressource"),
  mono([
    '   [dépôt]──▶ brouillon ──soumettre──▶ en_verification ──approuver──▶ publiee',
    '                  ▲                          │                          │',
    '                  └────renvoyer (motif)──────┘                          │',
    '                                                                        │',
    '                              remplacer ◀───────────────────────────────┤',
    '                                  │                                     │',
    '                                  ▼                                     ▼',
    '                            redirigee                               archivee',
    '',
    '   Aucune transition ne détruit l’adresse courte : elle répond dans tous les états.',
  ]),
  h2("18.4 Diagramme d'états — travail assigné"),
  mono([
    '   brouillon ──publier──▶ publie ──assigner──▶ assigne ──date limite──▶ clos',
    '                                                   │                      │',
    '                                            remise élève             correction',
    '                                                   │                      │',
    '                                                   ▼                      ▼',
    '                                               a_corriger ─────────▶ corrige',
  ]),
  h2('18.5 Diagramme de classes'),
  mono([
    '┌────────────────────┐        ┌──────────────────────┐       ┌───────────────┐',
    '│    Utilisateur     │1     * │      Ressource       │*     1│    Manuel     │',
    '├────────────────────┤────────├──────────────────────┤───────├───────────────┤',
    '│ id, nom, email     │ dépose │ id, titre, resume    │       │ isbn, titre   │',
    '│ role, etablissement│        │ famille, type, format│       │ niveau        │',
    '│ niveau, favoris[]  │        │ discipline, niveau   │       │ chapitres[]   │',
    '└───┬────────────┬───┘        │ statut, lienCourt    │       └───────────────┘',
    '    │1           │1           └───┬──────────────┬───┘',
    '    │*           │*               │1             │1',
    '┌───▼──────┐ ┌───▼──────────┐ ┌───▼──────┐  ┌────▼──────┐',
    '│Progression│ │  Travail     │ │  Usage   │  │  Dépôt    │',
    '├──────────┤ ├──────────────┤ ├──────────┤  ├───────────┤',
    '│ parcoursId│ │ type, titre  │ │ vues     │  │ statut    │',
    '│ etapes[]  │ │ exercices[]  │ │ scans    │  │ commentaire│',
    '│ pourcent  │ │ bareme       │ │ telech.  │  │ decidePar │',
    '└──────────┘ └──────┬───────┘ └──────────┘  └───────────┘',
    '                    │1',
    '                    │*',
    '            ┌───────▼────────┐        ┌──────────┐ 1   * ┌──────────┐',
    '            │    Remise      │        │  Groupe  │───────│  Membre  │',
    '            ├────────────────┤        └──────────┘       └──────────┘',
    '            │ eleveId, note  │',
    '            │ retour         │        ┌──────────┐ 1   * ┌──────────┐',
    '            └────────────────┘        │  Sujet   │───────│ Message  │',
    '                                      └──────────┘       └──────────┘',
  ]),
  saut(),
);

/* ========================================================================= */
/* 19. Architecture technique                                                */
/* ========================================================================= */
A(
  h1('Architecture technique'),
  h2('19.1 Choix de la pile technologique'),
  tbl(['Couche', 'Choix', 'Justification'], [
    ['Serveur', 'Node.js 18+, module http natif', 'Zéro dépendance, démarrage instantané, aucune faille de chaîne d’approvisionnement'],
    ['Rendu', 'HTML généré côté serveur par un moteur de gabarits interne', 'Aucun script de framework à télécharger en connexion lente'],
    ['Interface', 'CSS3 à jetons, JavaScript natif limité à trois comportements', 'Une page reste utilisable même si le script échoue'],
    ['Icônes', 'Jeu vectoriel interne de 67 tracés', 'Aucune police d’icônes ni requête distante'],
    ['QR codes', 'Encodeur interne (Reed-Solomon, masques, BCH)', 'Un tirage imprimé ne doit dépendre d’aucun service tiers'],
    ['Persistance', 'PostgreSQL, client écrit pour le projet (lib/pg)', 'Protocole v3, SCRAM-SHA-256, TLS, transactions — sans dépendance npm'],
    ['Socle de repli', 'Collections JSON à écriture atomique', 'Le projet reste lançable sans serveur de base'],
    ['Médias', 'Service de fichiers avec requêtes Range', 'Lecture vidéo immédiate sans téléchargement complet'],
    ['Paiement', 'API PLOP PLOP en HTTPS, signature HMAC-SHA256', 'Mutualisée avec les autres plateformes de l’écosystème'],
    ['Hébergement', 'Service web avec disque persistant (Render ou VPS)', 'Coût maîtrisé, déploiement par dépôt Git'],
  ], [1700, 3500, 4100]),
  h2('19.2 Décision d’architecture : monolithe modulaire'),
  p("Une architecture en microservices a été étudiée puis écartée. Le volume attendu ne justifie pas le coût d'exploitation d'un maillage de services, alors que l'hébergement local est contraint et l'équipe réduite. Le découpage interne constitue la ligne de fracture d'une extraction future : le moteur de QR codes, le service de fichiers et le module de paiement sont déjà isolés derrière des interfaces stables et deviendraient des services autonomes sans réécriture de la logique métier."),
  note("Seuil de réexamen : 5 000 ressources publiées, 20 000 comptes actifs, ou un temps de rendu médian supérieur à 300 ms."),
  h2('19.3 Décision d’architecture : persistance'),
  p("Les collections JSON conviennent tant que les écritures restent rares et les lectures majoritaires — ce qui est le cas d'un fonds documentaire. L'écriture atomique (fichier temporaire puis renommage) protège contre la corruption en cas de coupure. Le passage à PostgreSQL est prévu à l'apparition d'écritures concurrentes fréquentes : remises d'élèves en temps réel pendant une évaluation de classe."),
  h2('19.4 Architecture applicative'),
  mono([
    '  Requête HTTP',
    '      │',
    '      ▼  server.js — méthode, statique, /qr.svg, /r/:id',
    '      ▼  lib/router.js — table des adresses, repli « module à construire »',
    '      ▼  session : rôle, espace, établissement',
    '      ▼  views/pages/<module>.js — vue enseignant ou vue élève',
    '      │        │',
    '      │        ├── lib/store.js ......... lecture des collections',
    '      │        ├── views/components ..... blocs de page',
    '      │        └── lib/icons.js .......... icônes',
    '      ▼  views/layout.js ou site-layout.js — ossature',
    '      ▼  HTML échappé  ──▶  Réponse',
  ]),
  h2('19.5 Structure des répertoires'),
  mono([
    'educa-diffusion/',
    '  server.js ................. serveur HTTP, rôles, statique, QR, 404',
    '  lib/',
    '    html.js ................. gabarits échappés par défaut',
    '    icons.js ................ 67 icônes vectorielles',
    '    qr.js ................... encodeur QR complet',
    '    store.js ................ persistance JSON, cache, requêtes',
    '    router.js ............... table des adresses',
    '  views/',
    '    layout.js ............... ossature de l’application',
    '    site-layout.js .......... ossature du site public',
    '    components/ ............. chrome.js, blocks.js',
    '    pages/ .................. une fonction par écran',
    '  public/',
    '    css/ .................... tokens, base, layout, components, site, home, dashboard, resources',
    '    js/app.js ............... trois comportements clients',
    '    img/ .................... logo, illustrations, vignettes',
    '  data/ ..................... une collection JSON par domaine',
    '  docs/ ..................... documents de projet (Markdown et Word)',
    '  tools/ .................... aperçus, visuels, contrôles QR, documentation',
    '  preview/ .................. aperçus HTML autonomes',
  ]),
  saut(),
);

/* ========================================================================= */
/* 20. Modèle de données                                                     */
/* ========================================================================= */
A(
  h1('Modèle de données'),
  h2('20.1 Entités principales'),
  tbl(['Entité', 'Clé', 'Champs principaux'], [
    ['utilisateurs', 'usr_', 'nom, email, pass, role, espace, niveau, etablissementId, favoris[]'],
    ['etablissements', 'eta_', 'nom, type, departement, abonnement, classes[]'],
    ['classes', 'cls_', 'etablissementId, nom, niveau, enseignants[], eleves[]'],
    ['ressources', 'res_', 'titre, resume, famille, type, format, discipline, niveau, auteurId, statut, lienCourt, fichierId, manuelId, chapitre, licence'],
    ['fichiers', 'fic_', 'nomOrigine, nomStocke, format, taille, empreinte'],
    ['manuels', 'man_', 'isbn, titre, niveau, discipline, chapitres[], tirage'],
    ['usages', '—', 'ressourceId, jour, vues, scans, telechargements, manuelId'],
    ['depots', 'dep_', 'ressourceId, auteurId, statut, commentaire, decidePar, decideLe'],
    ['questions', 'que_', 'enonce, type, choix[], reponse, discipline, niveau, chapitre, difficulte'],
    ['quiz', 'qui_', 'titre, questions[], bareme, seuil, reprises, melange'],
    ['travaux', 'trv_', 'type, titre, discipline, niveau, objectifs, consignes, exercices[], bareme, statut'],
    ['assignations', '—', 'travailId, classeId, dateLimite, obligatoire'],
    ['remises', 'rem_', 'travailId, eleveId, contenu, fichierId, note, retour, remiseLe'],
    ['parcours', 'par_', 'titre, theme, niveau, etapes[]'],
    ['progressions', '—', 'userId, parcoursId, etapesFaites[], pourcent, repriseA'],
    ['laboratoires', 'lab_', 'titre, discipline, type, scenario, ressources[], statut'],
    ['groupes', 'grp_', 'etablissementId, nom, type, membres[]'],
    ['sujets / messages', 'suj_ / mfr_', 'categorie, auteurId, titre, resolu / sujetId, auteurId, contenu'],
    ['commandes', 'cmd_', 'userId, ressourceId, montant, methode, statut, transactionId'],
    ['auditLog', '—', 'at, userId, action, cible, details'],
    ['parametres', '—', 'familles[], disciplines[], niveaux[], formats[], approches[]'],
  ], [1900, 1300, 6100]),
  h2("20.2 Contraintes d'intégrité"),
  puces([
    "Adresse courte — unique, attribuée à la publication, immuable ensuite ; c'est la contrainte la plus forte du modèle, parce qu'elle est gravée sur du papier.",
    "Suppression — interdite sur toute ressource ayant un manuelId ou au moins un scan ; archivage seul possible.",
    "Références — auteurId, etablissementId, classeId, manuelId doivent exister.",
    "Cloisonnement — toute lecture de groupe, assignation, remise ou rapport est filtrée par etablissementId issu de la session.",
    "Compteurs — vues, scans et téléchargements sont écrits côté serveur uniquement, agrégés par jour.",
    "Barème — la somme des points des exercices doit égaler le barème déclaré, sinon la publication est refusée.",
    "Progression — dérivée des étapes acquises, jamais saisie directement.",
    "Modération — un dépôt ne passe en publiée que par une décision journalisée d'un modérateur distinct de l'auteur.",
  ]),
  saut(),
);

/* ========================================================================= */
/* 21. Interfaces et API                                                     */
/* ========================================================================= */
A(
  h1('Interfaces et API'),
  h2('21.1 Principes'),
  puces([
    "Les écrans sont servis en HTML complet ; il n'existe pas d'API interne consommée par un client JavaScript.",
    "Les filtres et les états d'affichage passent par la requête, ce qui rend toute vue partageable par simple copie du lien.",
    "Deux points d'accès font exception et renvoient autre chose que du HTML : la génération de QR codes et, en version 2.0, l'API partenaires.",
  ]),
  h2('21.2 Adresses principales'),
  tbl(['Méthode', 'Adresse', 'Rôle', 'Accès'], [
    ['GET', '/', 'Site public — accueil', 'Public'],
    ['GET', '/r/:id', 'Adresse courte, cible des QR codes', 'Public'],
    ['GET', '/qr.svg', 'QR code à la volée (texte, taille, logo, téléchargement)', 'Public'],
    ['GET', '/categories/:slug', 'Contenus d’une catégorie', 'Public'],
    ['GET', '/tableau-de-bord', 'Tableau de bord de l’espace courant', 'Connecté'],
    ['GET', '/ressources-pedagogiques', 'Catalogue, filtres, grille ou liste', 'Connecté'],
    ['GET', '/ressources-methodologiques', 'Méthodes d’enseignement ou de travail', 'Connecté'],
    ['GET', '/ressources-multimedias', 'Vidéos, audios, animations', 'Connecté'],
    ['GET', '/banque-de-questions', 'Banque de questions', 'Enseignant'],
    ['POST', '/quiz', 'Composition d’un quiz', 'Enseignant'],
    ['POST', '/travaux-diriges', 'Création d’un TD', 'Enseignant'],
    ['POST', '/travaux/:id/assigner', 'Assignation à des classes', 'Propriétaire'],
    ['POST', '/travaux/:id/corriger', 'Note et retour sur une remise', 'Propriétaire'],
    ['POST', '/partage-de-ressources/nouveau', 'Dépôt d’une ressource', 'Enseignant'],
    ['POST', '/depots/:id/soumettre', 'Soumission à vérification', 'Auteur'],
    ['POST', '/admin/depots/:id', 'Approbation ou renvoi commenté', 'Modérateur'],
    ['GET', '/admin/manuels/:id/planche', 'Export de la planche de QR codes', 'Éditeur'],
    ['GET', '/rapports/manuel/:id', 'Scans par chapitre et par période', 'Éditeur'],
    ['POST', '/etablissement/comptes', 'Création de comptes en lot', 'Admin étab.'],
    ['GET', '/forum · /groupes', 'Communauté', 'Connecté'],
  ], [1100, 3300, 3400, 1500]),
  h2('21.3 Génération de QR codes'),
  tbl(['Paramètre', 'Valeurs', 'Effet'], [
    ['texte', 'chaîne UTF-8, 106 octets maximum', 'Contenu encodé ; au-delà, réponse 413'],
    ['taille', '80 à 1024 (défaut 200)', 'Côté de l’image en pixels'],
    ['logo', '1 ou absent', 'Réserve centrale de 18 % avec le logo EDUCA'],
    ['telecharger', '1 ou absent', 'Envoi en pièce jointe'],
  ], [1900, 3400, 4000]),
  h2('21.4 API partenaires — version 2.0'),
  puces([
    "GET /api/v1/ressources — recherche paginée par discipline, niveau et date de publication.",
    "GET /api/v1/ressources/:id — métadonnées complètes et adresse courte.",
    "GET /api/v1/manuels/:isbn — chapitres et ressources associées.",
    "Authentification par clé d'application, quota horaire, journalisation des appels.",
  ]),
  saut(),
);

/* ========================================================================= */
/* 22. Intégrations avec l'écosystème EDUCA                                  */
/* ========================================================================= */
A(
  h1("Intégrations avec l'écosystème EDUCA"),
  h2('22.1 EDUCA Librairie'),
  p("La Librairie vend le manuel imprimé ; Diffusion en sert le prolongement numérique. À l'achat d'un manuel, la confirmation de commande porte l'adresse du chapitre d'accueil et un QR code de bienvenue. Réciproquement, une ressource dont le manuel est en vente affiche un lien d'achat."),
  h2('22.2 EDUCA Formation'),
  p("Les enseignants qui découvrent la plateforme suivent un parcours de prise en main hébergé par Formation. La certification obtenue est affichée sur le profil public du contributeur dans Diffusion."),
  h2('22.3 EDUCA Bibliothèque Numérique'),
  p("Les ressources longues — ouvrages, rapports, mémoires — sont conservées par la Bibliothèque et citées depuis Diffusion. Le partage de responsabilité est net : Diffusion sert l'usage quotidien de classe, la Bibliothèque la conservation et la lecture longue."),
  h2('22.4 ÉDUCA RH'),
  p("Pour un établissement client des deux plateformes, la liste des enseignants peut être importée depuis ÉDUCA RH plutôt que ressaisie. L'import est ponctuel et sur demande explicite de l'établissement : aucune synchronisation automatique n'est prévue, pour éviter qu'une modification RH n'affecte silencieusement des comptes pédagogiques."),
  h2('22.5 Passerelle PLOP PLOP'),
  p("Les contenus payants et les abonnements d'établissement réutilisent la passerelle déjà intégrée par EDUCA Librairie et EDUCA Formation : ouverture de transaction, vérification serveur par sondage, finalisation idempotente, signature HMAC-SHA256 des versements. Aucune adaptation propre à Diffusion n'est requise."),
  note("Point à trancher : la facturation d'un abonnement d'établissement se prête mal au portefeuille mobile, plafonné en montant. Deux options — fractionnement mensuel automatique, ou virement bancaire hors plateforme avec activation manuelle. La seconde est retenue pour la v1.0."),
  saut(),
);

/* ========================================================================= */
/* 23. Interface utilisateur et charte graphique                             */
/* ========================================================================= */
A(
  h1('Interface utilisateur et charte graphique'),
  h2('23.1 Identité visuelle'),
  tbl(['Élément', 'Valeur'], [
    ['Bleu de marque', '#1D4ED8 — action, liens, état actif'],
    ['Marine', '#0A1A3C à #17357A — bannières enseignant, appels à l’action publics, pied de page'],
    ['Orange', '#F5871F — accent du logo, second terme des titres'],
    ['Vert', '#1A7A46 — engagement (jeton conservé, usage restreint)'],
    ['Encres', '#0F1B33 titres · #344054 texte · #667085 métadonnées'],
    ['Fonds', '#F4F6FA application · #EEF2F8 accueil public'],
    ['Tons de discipline', 'Sept teintes pastel : bleu, vert, violet, orange, rose, sarcelle, gris'],
    ['Typographie', 'Inter puis pile système ; aucune police distante'],
    ['Formes', 'Rayons 6 à 26 px ; ombres douces ; bordure #E6EAF2'],
  ], [2400, 6900]),
  h2('23.2 Patrons d’écran'),
  puces([
    "Site public — grandes cartes arrondies sur fond froid : bannière en deux moitiés, panneau manifeste à filet dégradé, sections de contenu.",
    "Application — barre latérale fixe, barre supérieure de recherche, contenu et rail droit d'informations secondaires.",
    "Catalogue — en-tête clair, pastilles de familles ou de disciplines, barre de filtres, grille ou liste, filtres avancés au rail.",
    "Module d'activité — bannière colorée, compteurs, filtres, liste, rail.",
    "Création — assistant en cinq étapes avec aperçu en direct à droite.",
  ]),
  h2('23.3 Écrans à concevoir'),
  tbl(['État', 'Écrans'], [
    ['Livrés', 'Accueil public, tableau de bord enseignant et élève, ressources pédagogiques (deux vues), ressources méthodologiques (deux vues), travaux dirigés, système de design'],
    ['À concevoir — priorité 1', 'Fiche de ressource, dépôt, file de modération, banque de questions, création de quiz'],
    ['À concevoir — priorité 2', 'Multimédias, cartes, TP, exposés, dissertations, examens, carnet de notes'],
    ['À concevoir — priorité 3', 'Laboratoire, console établissement, rapports éditeur, forum, groupes'],
  ], [2600, 6700]),
  h2("23.4 Principes d'interface"),
  puces([
    "Clarté — un seul objectif par écran, action principale visible sans défilement.",
    "Vocabulaire — les libellés décrivent l'effet réel : « Soumettre à vérification » et non « Publier ».",
    "États d'erreur — un échec nomme le problème et propose une issue ; un écran vide invite à agir.",
    "Continuité — les filtres voyagent dans l'adresse ; une vue se partage par copie du lien.",
    "Accessibilité — contrastes conformes, navigation au clavier, focus visible, animations désactivables.",
    "Sobriété — aucune animation décorative, aucune image lourde, aucun script bloquant.",
  ]),
  saut(),
);

/* ========================================================================= */
/* 24. Sécurité                                                              */
/* ========================================================================= */
A(
  h1('Sécurité'),
  h2('24.1 Authentification'),
  puces([
    "Mots de passe hachés en scrypt avec sel unique par compte, comparaison en temps constant.",
    "Session matérialisée par un cookie HttpOnly signé, invalidé à la déconnexion.",
    "Comptes d'élèves créés par l'établissement : mot de passe provisoire à changer à la première connexion.",
    "Aucun secret en clair dans le code ou les données ; clés en variables d'environnement.",
  ]),
  note("État actuel : l'ossature bascule d'espace au moyen d'un cookie de démonstration, sans authentification. La mise en place des comptes est la première tâche de la phase 4 du planning."),
  h2('24.2 Autorisation'),
  puces([
    "Le rôle et l'établissement sont portés par la session, jamais par un paramètre de requête.",
    "Chaque adresse déclare le rôle minimal requis ; le contrôle est effectué avant toute lecture de données.",
    "Un accès hors périmètre renvoie la même réponse qu'une ressource inexistante, pour ne pas révéler son existence.",
  ]),
  h2('24.3 Protection des données'),
  puces([
    "TLS de bout en bout, imposé par l'hébergeur, y compris vers la passerelle de paiement.",
    "Aucune donnée nominative n'est conservée pour un visiteur non connecté : les scans sont agrégés par jour.",
    "Les données des élèves mineurs sont limitées au strict nécessaire : nom, niveau, établissement, progression.",
    "Aucun traceur publicitaire, aucun service d'analyse tiers.",
  ]),
  h2('24.4 Protection applicative'),
  puces([
    "Échappement systématique : le moteur de gabarits échappe par défaut, seuls les fragments produits par les composants sont marqués sûrs.",
    "En-tête X-Content-Type-Options: nosniff sur toutes les réponses.",
    "Chemins des fichiers statiques normalisés puis vérifiés comme appartenant au dossier public.",
    "Noms de fichiers régénérés au téléversement ; types et tailles contrôlés avant écriture.",
    "Aucune dépendance npm : la chaîne d'approvisionnement ne présente pas de surface d'attaque.",
    "Limitation de débit sur le dépôt, la recherche et la génération de QR codes.",
  ]),
  h2("24.5 Journal d'audit"),
  p("Sont journalisés avec horodatage, auteur et cible : décisions de modération, publications et retraits, modifications de paramètres, créations de comptes en lot, exports de planches de QR codes, signalements, tentatives d'accès hors périmètre, échecs d'authentification répétés."),
  h2('24.6 Continuité'),
  puces([
    "Sauvegarde quotidienne des données et des téléversements hors serveur.",
    "Écriture atomique protégeant contre la corruption en cas de coupure.",
    "Restauration testée chaque trimestre sur un environnement dédié.",
    "Retour arrière par redéploiement du commit précédent en moins de deux minutes.",
  ]),
  saut(),
);

/* ========================================================================= */
/* 25. Conformité légale et éditoriale                                       */
/* ========================================================================= */
A(
  h1('Conformité légale et éditoriale'),
  h2('25.1 Cadre de référence'),
  tbl(['Domaine', 'Référence', 'Incidence sur la plateforme'], [
    ['Programme scolaire', 'Curriculum du MENFP', 'Classement obligatoire par niveau et discipline officiels'],
    ['Droit d’auteur', 'Convention de Berne ; loi haïtienne sur la propriété littéraire', 'Licence déclarée par ressource ; retrait sur signalement'],
    ['Protection des mineurs', 'Convention relative aux droits de l’enfant', 'Minimisation des données, forum modéré, aucun traceur'],
    ['Commerce électronique', 'Réglementation BRH sur la monnaie électronique', 'Paiements délégués à un prestataire agréé'],
    ['Accessibilité', 'WCAG 2.1 niveau AA', 'Contrastes, clavier, focus, mouvement réduit'],
  ], [2000, 3300, 4000]),
  h2('25.2 Obligations éditoriales à outiller'),
  puces([
    "Déclaration de paternité et de licence obligatoire à chaque dépôt, avec choix entre licence propriétaire EDUCA et licence ouverte.",
    "Procédure de signalement et de retrait d'un contenu contrefaisant, avec délai de traitement affiché.",
    "Conservation de la trace des décisions de modération, opposable en cas de litige.",
    "Mention de la source pour toute carte, photographie ou extrait reproduit.",
    "Registre des manuels et des tirages, pour identifier les exemplaires portant un QR code retiré.",
  ]),
  h2('25.3 Principe de conception'),
  p("Aucune règle légale ou éditoriale n'est codée en dur. Les licences, les niveaux, les disciplines et les délais de traitement sont des paramètres administrables : une réforme du curriculum ou une évolution réglementaire se traite par paramétrage, sans modification du code ni redéploiement."),
  h2('25.4 Validation préalable'),
  p("Avant la mise en production, trois validations externes sont requises : conformité du classement au curriculum en vigueur par un conseiller pédagogique, revue des mentions de licence par un juriste, et vérification du traitement des données d'élèves mineurs au regard des engagements pris auprès des établissements."),
  saut(),
);

/* ========================================================================= */
/* 26. Stratégie de tests                                                    */
/* ========================================================================= */
A(
  h1('Stratégie de tests'),
  h2('26.1 Types de tests'),
  tbl(['Type', 'Portée', 'Méthode'], [
    ['Unitaire', 'Échappement, filtrage, encodage QR, calculs de barème', 'Scripts Node sur les fonctions pures'],
    ['Intégration', 'Réponse de toutes les adresses, filtres croisés, bascule d’espace', 'Requêtes automatisées sur le serveur local'],
    ['Fonctionnel', 'Parcours des sept acteurs, du QR scanné au dépôt publié', 'Scénarios de bout en bout sur le jeu de démonstration'],
    ['Cloisonnement', 'Accès croisés entre établissements et entre espaces', 'Tentatives d’accès par adresse directe'],
    ['Rendu', 'Équilibre des balises, présence des blocs, poids des pages', 'Contrôle automatique du HTML produit'],
    ['Impression', 'Lisibilité des QR codes sur épreuve papier', 'Scan manuel avec trois téléphones différents'],
    ['Accessibilité', 'Contrastes, tabulation, libellés', 'Revue assistée par navigateur'],
    ['Résilience', 'Passerelle injoignable, coupure en cours de remise', 'Arrêt du simulateur pendant une transaction'],
  ], [1700, 3900, 3700]),
  h2('26.2 Corpus de référence du moteur QR'),
  p("Un corpus de contrôle est rejoué à chaque modification de l'encodeur : adresses courtes types, chaînes accentuées, contenu à la limite de capacité, contenu trop long. Pour chacune, trois vérifications — syndromes de Reed-Solomon nuls, reste BCH de l'information de format nul, relecture module par module restituant le texte exact."),
  h2('26.3 Cas de test critiques'),
  puces([
    "Pérennité — une ressource archivée continue de répondre sur son adresse courte et redirige vers son chapitre.",
    "Modération — un dépôt soumis disparaît du catalogue jusqu'à décision ; un modérateur ne peut pas approuver son propre dépôt.",
    "Cloisonnement — un enseignant d'un établissement A n'atteint ni les groupes, ni les remises, ni les rapports de l'établissement B.",
    "Barème — un travail dont la somme des points diffère du barème déclaré est refusé à la publication.",
    "Compteurs — un rechargement de page n'incrémente pas deux fois le compteur de scans.",
    "Coupure — une remise interrompue conserve les réponses déjà saisies.",
  ]),
  saut(),
);

/* ========================================================================= */
/* 27. Déploiement et infrastructure                                         */
/* ========================================================================= */
A(
  h1('Déploiement et infrastructure'),
  h2('27.1 Environnements'),
  tbl(['Environnement', 'Données', 'Paiement', 'Usage'], [
    ['Développement', 'Collections locales relues à chaque requête', 'Simulateur', 'Codage quotidien'],
    ['Test', 'Jeu de démonstration', 'Clés de test', 'Recette et aperçus autonomes'],
    ['Production', 'Disque persistant, cache mémoire', 'Clés marchand réelles', 'Service aux utilisateurs'],
  ], [2000, 3000, 2000, 2300]),
  h2('27.2 Infrastructure cible'),
  mono([
    '  ┌────────────┐  HTTPS  ┌──────────────────────────┐  HTTPS  ┌─────────────┐',
    '  │ Navigateur │◀───────▶│  Hébergeur (service web) │◀───────▶│  PLOP PLOP  │',
    '  │  ou mobile │         │   Node.js · port 3000    │         └─────────────┘',
    '  └────────────┘         │  ┌────────────────────┐  │',
    '        ▲                │  │ Disque persistant  │  │   ┌──────────────────┐',
    '        │ scan QR        │  │ data/ · uploads/   │  │──▶│ Sauvegarde hors  │',
    '  ┌─────┴──────┐         │  └────────────────────┘  │   │ serveur (quotid.)│',
    '  │  Manuel    │         └──────────────────────────┘   └──────────────────┘',
    '  │  imprimé   │',
    '  └────────────┘',
  ]),
  h2('27.3 Procédure de mise en production'),
  puces([
    "Authentification et sessions signées en place ; cookie de démonstration retiré.",
    "DATA_DIR pointant vers le disque persistant ; données et téléversements préservés.",
    "BASE_URL renseignée et TLS actif ; adresses courtes /r/:id opérationnelles.",
    "NODE_ENV=production pour activer le cache mémoire et les en-têtes de cache.",
    "Visuels d'attente remplacés par les illustrations définitives.",
    "Sauvegarde automatique programmée et restauration testée au moins une fois.",
    "Une épreuve de QR code imprimée, scannée avec trois téléphones différents.",
    "Comptes de démonstration supprimés.",
  ]),
  h2('27.4 Accompagnement des établissements'),
  tbl(['Étape', 'Contenu', 'Durée'], [
    ['Prise en main', 'Séance avec l’équipe pédagogique, import des comptes', 'Une demi-journée'],
    ['Amorçage', 'Constitution des classes, première assignation', 'Une semaine'],
    ['Suivi', 'Point d’usage et réponses aux questions', 'À un mois, puis trimestriel'],
    ['Support', 'Canal direct pour l’administrateur de l’établissement', 'Continu'],
  ], [2100, 5100, 2100]),
  saut(),
);

/* ========================================================================= */
/* 28. Modèle économique et tarification                                     */
/* ========================================================================= */
A(
  h1('Modèle économique et tarification'),
  h2('28.1 Formules'),
  tbl(['Formule', 'Cible', 'Contenu', 'Tarif indicatif'], [
    ['Libre', 'Élèves, parents, visiteurs', 'Fonds gratuit, ressources par QR code, favoris, parcours', 'Gratuit'],
    ['Enseignant', 'Enseignant individuel', 'Catalogue complet, outils de préparation, dépôt, statistiques', '1 500 HTG / an'],
    ['Établissement', 'École ou réseau', 'Comptes enseignants et élèves, classes, assignations, rapports', 'À partir de 25 000 HTG / an selon l’effectif'],
    ['Éditeur', 'Maison d’édition, auteur', 'Publication directe, manuels hybrides, statistiques de scan', 'Sur convention'],
  ], [1700, 2000, 3400, 2200]),
  h2('28.2 Principes de tarification'),
  puces([
    "Le fonds de base reste gratuit : une ressource scannée depuis un manuel s'ouvre sans compte ni paiement. C'est la condition de crédibilité du lien imprimé-numérique.",
    "Ce qui se paie, c'est l'outil de travail — préparation, évaluation, suivi de classe — non l'accès au savoir.",
    "Tarification en gourdes, sans indexation sur une devise étrangère.",
    "Tarif d'établissement par tranche d'effectif, dégressif, sans licence par poste.",
    "Gratuité de droit pour les écoles publiques des départements prioritaires, dans la limite d'un quota annuel.",
  ]),
  h2('28.3 Revenus complémentaires'),
  puces([
    "Vente unitaire de contenus premium de la maison d'édition (corrigés complets, annales, manuels numériques).",
    "Prestations d'accompagnement et de formation des équipes pédagogiques, en lien avec EDUCA Formation.",
    "Production de manuels hybrides pour des éditeurs tiers : déclaration, QR codes, hébergement des ressources.",
  ]),
  h2('28.4 Rétribution des contributeurs — v2.0'),
  p("Une part du revenu des abonnements enseignants et établissements sera redistribuée aux auteurs des ressources les plus utilisées, au prorata des téléchargements vérifiés. Le principe est acquis ; le barème et le seuil de déclenchement restent à arbitrer, de même que le mode de versement — le portefeuille mobile étant déjà utilisé par EDUCA Formation pour rémunérer ses formateurs."),
  saut(),
);

/* ========================================================================= */
/* 29. Planning de réalisation                                               */
/* ========================================================================= */
A(
  h1('Planning de réalisation'),
  h2('29.1 Phases'),
  tbl(['Phase', 'Livrables', 'Charge', 'Jalon'], [
    ['1. Cadrage', 'Périmètre, acteurs, exigences, vingt maquettes', '—', 'Validé'],
    ['2. Ossature et charte', 'Système de design, ossatures, blocs de page, jeu d’icônes', '3 semaines', 'Validé'],
    ['3. Site public et catalogues', 'Accueil, ressources pédagogiques et méthodologiques (deux vues), travaux dirigés', '4 semaines', 'Validé'],
    ['4. Comptes et contribution', 'Authentification, sessions, dépôt, file de modération, journal d’audit', '4 semaines', 'À engager'],
    ['5. Manuels hybrides', 'Manuels, adresses courtes, planches de QR, statistiques de scan', '3 semaines', 'À engager'],
    ['6. Évaluation', 'Banque de questions, quiz, TP, exposés, dissertations, examens, carnet de notes', '6 semaines', 'À engager'],
    ['7. Établissements', 'Comptes en lot, classes, assignations, rapports, abonnements', '4 semaines', 'À engager'],
    ['8. Communauté et médias', 'Forum, groupes, partage, multimédias, cartes', '4 semaines', 'À engager'],
    ['9. Mise en production', 'Déploiement, domaine, sauvegardes, fonds réel, illustrations définitives', '2 semaines', 'À planifier'],
    ['10. Pilote', 'Trois établissements, cinquante enseignants, un manuel hybride imprimé', '8 semaines', 'À planifier'],
    ['11. Version 2.0', 'Laboratoire complet, tuteur, hors ligne, mobile, API, notifications', '—', 'Trimestre suivant'],
  ], [1900, 4200, 1300, 1900]),
  h2('29.2 Chemin critique'),
  p("La phase 5 conditionne tout le reste : tant que les adresses courtes ne sont pas définitives, aucun manuel ne peut partir à l'impression, et le pilote ne peut pas démontrer la proposition de valeur. Elle doit démarrer dès la fin de la phase 4, en parallèle de la phase 6 si nécessaire."),
  note("Un tirage lancé avec des adresses provisoires serait irrécupérable : les exemplaires resteraient en circulation pendant des années avec des QR codes morts. C'est le seul point du projet où une erreur ne se corrige pas par un correctif logiciel."),
  saut(),
);

/* ========================================================================= */
/* 30. Budget estimatif                                                      */
/* ========================================================================= */
A(
  h1('Budget estimatif'),
  h2('30.1 Charge de développement'),
  tbl(['Poste', 'Charge estimée'], [
    ['Phases 2 et 3 — réalisées', '7 semaines'],
    ['Phases 4 à 8 — à réaliser', '21 semaines'],
    ['Phase 9 — mise en production', '2 semaines'],
    ['Accompagnement du pilote', '4 semaines'],
    ['Total restant', '27 semaines-personne'],
  ], [5200, 4100]),
  h2('30.2 Coûts externes récurrents'),
  tbl(['Poste', 'Nature', 'Estimation mensuelle'], [
    ['Hébergement', 'Service web et disque persistant', '20 à 30 USD'],
    ['Stockage des médias', 'Vidéos et documents du fonds', '5 à 15 USD selon volume'],
    ['Sauvegardes', 'Stockage externe', 'Moins de 5 USD'],
    ['Nom de domaine et TLS', 'Sous-domaine d’educasoft.tech', 'Inclus'],
    ['Passerelle de paiement', 'Commission PLOP PLOP', 'Proportionnelle au volume'],
    ['Logiciels', 'Aucun — pile entièrement libre', '0'],
    ['Total récurrent', '—', '30 à 50 USD'],
  ], [2400, 4300, 2600]),
  h2('30.3 Coûts non récurrents'),
  tbl(['Poste', 'Estimation'], [
    ['Illustrations et vignettes définitives', 'À budgéter — les visuels actuels sont des SVG d’attente'],
    ['Amorçage éditorial du fonds (300 ressources)', 'Production interne de la maison d’édition'],
    ['Épreuves d’impression et tests de QR codes', 'Marginal, à la charge de l’imprimeur'],
    ['Validations externes (pédagogique, juridique)', 'Deux prestations ponctuelles'],
  ], [4600, 4700]),
  h2('30.4 Recommandation'),
  p("Le coût d'exploitation est volontairement minimal : l'absence de dépendances, de conteneurs et de services managés est un choix économique autant que technique. L'essentiel de l'investissement porte sur le temps de développement et sur l'amorçage du fonds — c'est-à-dire sur ce qui produit de la valeur durable, non sur l'infrastructure."),
  saut(),
);

/* ========================================================================= */
/* 31. Risques et mesures d'atténuation                                      */
/* ========================================================================= */
A(
  h1("Risques et mesures d'atténuation"),
  tbl(['Risque', 'Probabilité', 'Impact', "Mesure d'atténuation"], [
    ['QR codes imprimés pointant dans le vide', 'Faible', 'Critique', 'Adresses courtes immuables, archivage au lieu de suppression, redirection systématique, épreuve scannée avant tirage'],
    ['Fonds trop pauvre au lancement', 'Élevée', 'Élevé', 'Amorçage éditorial de 300 ressources avant ouverture publique'],
    ['Contribution enseignante qui ne démarre pas', 'Moyenne', 'Élevé', 'Reconnaissance des auteurs, statistiques d’usage, rétribution en v2.0, accompagnement au dépôt'],
    ['Contenus de qualité insuffisante', 'Moyenne', 'Élevé', 'Vérification avant publication, grille de contrôle, commentaire de renvoi obligatoire'],
    ['Litige de droit d’auteur', 'Moyenne', 'Élevé', 'Déclaration de paternité, mention des sources, procédure de retrait, traçabilité des décisions'],
    ['Corruption des données', 'Faible', 'Critique', 'Écriture atomique, sauvegarde quotidienne hors serveur, restauration testée'],
    ['Croissance dépassant le socle JSON', 'Moyenne', 'Moyen', 'Seuil de bascule défini, migration PostgreSQL préparée'],
    ['Connectivité insuffisante dans les écoles', 'Élevée', 'Moyen', 'Pages légères, aucun état perdu, mode hors ligne avancé en v2.0 si nécessaire'],
    ['Indisponibilité de la passerelle', 'Moyenne', 'Faible', 'Le fonds gratuit et les espaces restent accessibles ; seuls les achats sont suspendus'],
    ['Dépendance à un unique développeur', 'Élevée', 'Élevé', 'Documentation complète, code commenté en français, zéro dépendance exotique'],
    ['Réforme du curriculum', 'Faible', 'Moyen', 'Niveaux et disciplines paramétrables, reclassement en masse outillé'],
  ], [2500, 1300, 1200, 4300]),
  saut(),
);

/* ========================================================================= */
/* 32. Indicateurs de succès                                                 */
/* ========================================================================= */
A(
  h1('Indicateurs de succès'),
  h2('32.1 Adoption'),
  tbl(['Indicateur', 'Cible à 12 mois', 'Cible à 24 mois'], [
    ['Ressources publiées', '1 000', '3 000'],
    ['Enseignants actifs mensuels', '1 200', '5 000'],
    ['Élèves actifs mensuels', '12 000', '50 000'],
    ['Établissements partenaires', '80', '300'],
    ['Manuels hybrides en circulation', '3 titres', '12 titres'],
  ], [3500, 2900, 2900]),
  h2('32.2 Usage'),
  tbl(['Indicateur', 'Cible'], [
    ['Scans de QR codes par mois', '20 000 à 24 mois'],
    ['Part des scans aboutissant à une consultation complète', 'Supérieure à 70 %'],
    ['Ressources téléchargées par enseignant actif et par mois', 'Au moins 4'],
    ['Part du fonds consultée au moins une fois par trimestre', 'Supérieure à 60 %'],
    ['Parcours méthodologiques achevés par élève et par an', 'Au moins 2'],
  ], [5600, 3700]),
  h2('32.3 Qualité et contribution'),
  tbl(['Indicateur', 'Cible'], [
    ['Part des publications issues de la communauté enseignante', '30 % à 24 mois'],
    ['Délai médian de décision sur un dépôt', 'Moins de 5 jours ouvrables'],
    ['Taux d’approbation au premier passage', 'Supérieur à 60 %'],
    ['Signalements traités sous 48 h', '100 %'],
    ['Note moyenne des ressources', 'Supérieure à 4,2 sur 5'],
  ], [5600, 3700]),
  h2('32.4 Technique'),
  tbl(['Indicateur', 'Cible'], [
    ['Temps de rendu médian', 'Moins de 100 ms'],
    ['Poids médian d’une page hors médias', 'Moins de 150 Ko'],
    ['Disponibilité mensuelle', 'Supérieure à 99 %'],
    ['Adresses courtes imprimées répondant', '100 %'],
    ['Coût d’exploitation mensuel', 'Moins de 50 USD'],
  ], [5600, 3700]),
  saut(),
);

/* ========================================================================= */
/* 33. Glossaire                                                             */
/* ========================================================================= */
A(
  h1('Glossaire'),
  tbl(['Terme', 'Définition'], [
    ['Adresse courte', 'Chemin bref et immuable d’une ressource, cible de son QR code imprimé'],
    ['Bloc de page', 'Composant assemblable : bannière, compteurs, filtres, liste, carte de rail'],
    ['Chantier', 'Écran dont l’ossature répond mais dont le module reste à construire'],
    ['Espace', 'Vue complète destinée à un public : public, enseignant ou élève'],
    ['Famille de ressources', 'Regroupement éditorial : fiche de préparation, présentation, guide, plan de leçon'],
    ['Fonds commun', 'Ensemble des ressources publiées, lisible par tous les comptes'],
    ['Jeton de design', 'Variable CSS portant une décision visuelle réutilisable'],
    ['Manuel hybride', 'Manuel imprimé dont les chapitres portent des QR codes vers des ressources numériques'],
    ['Niveau de correction M', 'Réglage QR tolérant environ 15 % de dégradation — compatible avec un logo central'],
    ['Patron de page', 'Séquence bannière → compteurs → filtres → liste → rail, commune à la majorité des écrans'],
    ['Rail droit', 'Colonne d’informations secondaires : actions rapides, populaires, conseils'],
    ['Reed-Solomon', 'Code correcteur d’erreurs employé par les QR codes'],
    ['Règle de gestion (RG)', 'Contrainte métier codifiée, référencée RG-XXX-NN dans le présent document'],
    ['Ressource méthodologique', 'Contenu portant sur la manière d’enseigner ou d’apprendre, non sur une matière'],
    ['Vérification éditoriale', 'Contrôle d’un dépôt par l’administration avant publication'],
    ['Zone de silence', 'Marge blanche obligatoire autour d’un QR code, quatre modules minimum'],
    ['Écriture atomique', 'Enregistrement par fichier temporaire puis renommage, sans état intermédiaire'],
    ['HTG', 'Gourde haïtienne, devise de référence de la plateforme'],
  ], [2600, 6700]),
  saut(),
);

/* ========================================================================= */
/* 34. Annexes                                                               */
/* ========================================================================= */
A(
  h1('Annexes'),
  h2('Annexe A — Comptes de démonstration'),
  tbl(['Rôle', 'Nom affiché', 'Espace'], [
    ['Enseignant', 'Jean Baptiste', 'Espace enseignant, toutes disciplines'],
    ['Élève', 'Jonas Pierre', 'Espace élève, Secondaire 2'],
  ], [2200, 3200, 3900]),
  note("Ces comptes sont des profils d'affichage : l'authentification n'est pas encore en place. Ils seront remplacés à la phase 4."),
  h2("Annexe B — Variables d'environnement"),
  tbl(['Variable', 'Rôle'], [
    ['PORT', 'Port d’écoute (3000 par défaut)'],
    ['NODE_ENV', 'production active le cache mémoire et les en-têtes de cache'],
    ['BASE_URL', 'URL publique, base des adresses courtes des QR codes'],
    ['DATA_DIR', 'Dossier des données — disque persistant en production'],
    ['PLOP_CLIENT_ID', 'Identifiant marchand'],
    ['PLOP_CLIENT_SECRET', 'Clé secrète marchand'],
  ], [3000, 6300]),
  h2('Annexe C — État de réalisation'),
  tbl(['Élément', 'État'], [
    ['Ossature applicative et site public', 'Livré'],
    ['Système de design et jeu d’icônes', 'Livré — consultable à l’adresse /systeme'],
    ['Encodeur QR et service /qr.svg', 'Livré et contrôlé (tools/verify-qr.js)'],
    ['Tableau de bord enseignant et élève', 'Livré'],
    ['Ressources pédagogiques et méthodologiques, deux vues chacune', 'Livré'],
    ['Travaux dirigés', 'Livré'],
    ['Trente adresses de navigation', 'Répondent — modules à construire pour la plupart'],
    ['Authentification, dépôt, modération', 'À réaliser — phase 4'],
    ['Manuels hybrides et planches de QR', 'À réaliser — phase 5'],
  ], [5600, 3700]),
  h2('Annexe D — Documents et outils'),
  puces([
    "Document de conception de projet EDUCA Diffusion (docs/Conception-Projet-EDUCA-Diffusion).",
    "README technique : démarrage, arborescence, ajout d'un module.",
    "Aperçus autonomes des écrans livrés (dossier preview/).",
    "Contrôles de l'encodeur QR (tools/verify-qr.js).",
    "Générateur du présent document (tools/doc-projet.js) — Markdown et Word depuis une source unique.",
  ]),
);

/* ========================================================================= */
ecrire(D, {
  fichier: 'EDUCA-Diffusion-Document-de-projet-v1.0',
  titre: 'ÉDUCA Diffusion — Document de projet',
  description: 'Document de projet, version 1.0',
  pied: 'ÉDUCA Diffusion — Document de projet · v1.0',
  depart: 1,
});
