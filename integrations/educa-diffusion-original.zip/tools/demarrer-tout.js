'use strict';
/**
 * Lance le service et le frontend côte à côte, pour le développement local.
 * En production, chaque processus est déployé séparément.
 */
const { spawn } = require('child_process');
const path = require('path');

const racine = path.join(__dirname, '..');
const PORT_SERVICE = process.env.PORT_SERVICE || '4001';
const PORT_FRONTEND = process.env.PORT_FRONTEND || '3000';

const processus = [
  { nom: 'service ', commande: ['node', ['src/server.js']], dossier: path.join(racine, 'services', 'diffusion-service'),
    env: { PORT: PORT_SERVICE } },
  { nom: 'frontend', commande: ['node', ['server.js']], dossier: path.join(racine, 'frontend'),
    env: { PORT: PORT_FRONTEND, API_DIFFUSION: `http://127.0.0.1:${PORT_SERVICE}/api/v1` } },
];

const enfants = processus.map(({ nom, commande, dossier, env }) => {
  const enfant = spawn(commande[0], commande[1], { cwd: dossier, env: { ...process.env, ...env } });
  const prefixer = (flux) => flux.on('data', (d) => {
    for (const ligne of d.toString().trimEnd().split('\n')) console.log(`[${nom}] ${ligne}`);
  });
  prefixer(enfant.stdout); prefixer(enfant.stderr);
  return enfant;
});

const arreter = () => { for (const e of enfants) e.kill('SIGTERM'); process.exit(0); };
process.on('SIGINT', arreter);
process.on('SIGTERM', arreter);
