'use strict';
/**
 * Génère les visuels d'attente du site public : vignettes de catégories et
 * photo de bannière. À remplacer par les vraies images (mêmes noms de fichier,
 * ou chemins modifiés dans data/accueil.json).
 */
const fs = require('fs');
const path = require('path');
const { icon } = require('../frontend/lib/icons');

const OUT = path.join(__dirname, '..', 'frontend', 'public', 'img');
fs.mkdirSync(OUT, { recursive: true });

const CATS = [
  { file: 'cat-education-scolaire', from: '#1d4ed8', to: '#2e6bf0', icon: 'book' },
  { file: 'cat-developpement-personnel', from: '#b45309', to: '#e56a19', icon: 'briefcase' },
  { file: 'cat-jeunesse', from: '#be185d', to: '#ec4899', icon: 'sparkle' },
  { file: 'cat-sciences-technologie', from: '#0e7490', to: '#0e9384', icon: 'microscope' },
  { file: 'cat-langues', from: '#6d28d9', to: '#7e3af2', icon: 'message' },
  { file: 'cat-arts-culture', from: '#c2410c', to: '#f5871f', icon: 'palette' },
];

for (const c of CATS) {
  const glyph = String(icon(c.icon, { size: 96, stroke: 1.3 }))
    .replace('<svg', '<svg x="152" y="102" opacity=".95" color="#ffffff"');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" role="img" aria-label="">
  <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="${c.from}"/><stop offset="1" stop-color="${c.to}"/>
  </linearGradient></defs>
  <rect width="400" height="300" fill="url(#g)"/>
  <circle cx="330" cy="60" r="90" fill="#fff" opacity=".08"/>
  <circle cx="70" cy="250" r="70" fill="#fff" opacity=".07"/>
  ${glyph}
</svg>`;
  fs.writeFileSync(path.join(OUT, `${c.file}.svg`), svg);
}

/* Photo de bannière : composition d'attente, à remplacer par une photo. */
fs.writeFileSync(path.join(OUT, 'hero-accueil.svg'), `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" role="img" aria-label="Élève consultant une ressource numérique">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#dbe6fe"/><stop offset="1" stop-color="#eaf1fe"/>
    </linearGradient>
    <linearGradient id="screen" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#0a1a3c"/><stop offset="1" stop-color="#12275c"/>
    </linearGradient>
  </defs>
  <rect width="800" height="600" fill="url(#bg)"/>
  <circle cx="640" cy="140" r="150" fill="#1d4ed8" opacity=".07"/>
  <!-- silhouette -->
  <circle cx="530" cy="215" r="72" fill="#1d4ed8" opacity=".85"/>
  <path d="M400 600c0-115 58-186 130-186s130 71 130 186z" fill="#1d4ed8" opacity=".85"/>
  <!-- tablette -->
  <g transform="rotate(-8 300 340)">
    <rect x="120" y="230" width="330" height="235" rx="18" fill="#0f1b33"/>
    <rect x="134" y="244" width="302" height="207" rx="10" fill="url(#screen)"/>
    <circle cx="250" cy="330" r="26" fill="#f5871f"/>
    <ellipse cx="250" cy="330" rx="86" ry="34" fill="none" stroke="#2e6bf0" stroke-width="2"/>
    <ellipse cx="250" cy="330" rx="122" ry="50" fill="none" stroke="#2e6bf0" stroke-width="2" opacity=".6"/>
    <circle cx="336" cy="330" r="8" fill="#dbe6fe"/>
    <circle cx="128" cy="330" r="6" fill="#0e9f6e"/>
    <rect x="350" y="380" width="66" height="58" rx="6" fill="#fff"/>
    <g fill="#0f1b33">
      <rect x="358" y="388" width="14" height="14"/><rect x="394" y="388" width="14" height="14"/>
      <rect x="358" y="416" width="14" height="14"/><rect x="380" y="410" width="8" height="8"/>
      <rect x="394" y="420" width="10" height="10"/>
    </g>
  </g>
</svg>`);

console.log('visuels générés :', CATS.length + 1);

/* --- Visuels du tableau de bord ------------------------------------------ */
const carte = (nom, from, to, contenu) => fs.writeFileSync(path.join(OUT, `${nom}.svg`),
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 200" role="img" aria-label="">
  <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${from}"/><stop offset="1" stop-color="${to}"/></linearGradient></defs>
  <rect width="320" height="200" fill="url(#g)"/>${contenu}
</svg>`);

// Document PDF : page de texte
carte('thumb-revolution', '#eef2f9', '#dde5f2', `
  <rect x="70" y="18" width="180" height="164" rx="6" fill="#fff" stroke="#c9d4e6"/>
  <text x="160" y="44" text-anchor="middle" font-family="Georgia, serif" font-size="13" fill="#0f1b33">La Révolution française</text>
  ${Array.from({ length: 11 }, (_, i) => `<rect x="86" y="${58 + i * 10}" width="${i % 4 === 3 ? 96 : 148}" height="3.4" rx="1.7" fill="#9fb0c9"/>`).join('')}`);

// Vidéo : la Terre vue de l'espace
carte('thumb-volcans', '#04122e', '#0a2a63', `
  <circle cx="160" cy="112" r="74" fill="#123c7d"/>
  <path d="M116 88c18 6 30-4 46 2s26 22 44 18c-10 30-40 50-72 44s-52-36-46-64z" fill="#1d6fd8" opacity=".85"/>
  <circle cx="160" cy="112" r="74" fill="none" stroke="#4b93f7" stroke-width="1.5" opacity=".6"/>
  ${Array.from({ length: 22 }, (_, i) => `<circle cx="${(i * 67) % 320}" cy="${(i * 41) % 90}" r="1.2" fill="#fff" opacity=".7"/>`).join('')}`);

// Activité : élèves au travail
carte('thumb-fractions', '#dff2e6', '#bfe6cf', `
  <rect x="42" y="120" width="236" height="80" rx="8" fill="#0e9f6e" opacity=".2"/>
  <circle cx="112" cy="86" r="26" fill="#f5b78a"/><path d="M76 148c0-22 16-36 36-36s36 14 36 36z" fill="#e8734a"/>
  <circle cx="208" cy="86" r="26" fill="#8d5a3b"/><path d="M172 148c0-22 16-36 36-36s36 14 36 36z" fill="#2f7d4f"/>
  <rect x="96" y="150" width="128" height="34" rx="4" fill="#fff" stroke="#9ecfb4"/>
  <rect x="108" y="160" width="60" height="4" rx="2" fill="#9ecfb4"/><rect x="108" y="170" width="90" height="4" rx="2" fill="#9ecfb4"/>`);

// Quiz : cases à cocher
carte('thumb-quiz', '#5b2bb8', '#8b46e8', `
  ${Array.from({ length: 4 }, (_, i) => `
    <rect x="52" y="${40 + i * 34}" width="20" height="20" rx="4" fill="#fff" opacity=".9"/>
    <path d="M${57} ${50 + i * 34}l4 4 7-8" stroke="#7e3af2" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
    <rect x="84" y="${44 + i * 34}" width="${[150, 118, 138, 96][i]}" height="10" rx="5" fill="#fff" opacity=".55"/>`).join('')}
  <circle cx="258" cy="150" r="20" fill="#f5871f"/><text x="258" y="157" text-anchor="middle" font-family="Inter, Arial" font-size="20" font-weight="700" fill="#fff">?</text>`);

// Ressource du jour : jeune pousse
carte('thumb-photosynthese', '#f4faf6', '#e2f3e8', `
  <rect x="128" y="120" width="64" height="52" rx="6" fill="#d98b4a"/>
  <path d="M160 120V70" stroke="#2f7d4f" stroke-width="5" stroke-linecap="round"/>
  <path d="M160 92c-22 0-34-12-34-28 18-2 34 8 34 28z" fill="#3da35d"/>
  <path d="M160 80c20-2 32-14 32-30-18-2-32 10-32 30z" fill="#57bd77"/>
  <circle cx="240" cy="46" r="18" fill="#f5c33b"/>
  ${Array.from({ length: 6 }, (_, i) => `<path d="M240 46l${Math.round(Math.cos(i) * 30)} ${Math.round(Math.sin(i) * 30)}" stroke="#f5c33b" stroke-width="2.4" stroke-linecap="round" opacity=".8"/>`).join('')}`);

// Illustration du bandeau d'accueil
fs.writeFileSync(path.join(OUT, 'welcome-enseignant.svg'), `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 460 280" role="img" aria-label="">
  <g opacity=".28" stroke="#9ec2ff" fill="none" stroke-width="1.6">
    <circle cx="66" cy="40" r="16"/><circle cx="180" cy="26" r="13"/><circle cx="300" cy="34" r="15"/><circle cx="410" cy="60" r="12"/>
    <path d="M82 46h84M193 30h94M315 40h82"/>
  </g>
  <!-- plante -->
  <path d="M410 150c-16 0-26-12-26-28 16-2 26 10 26 28z" fill="#3da35d"/>
  <path d="M412 146c16-4 26-16 24-32-16 0-26 14-24 32z" fill="#57bd77"/>
  <path d="M396 198h34l-5 46h-24z" fill="#e08a4a"/>
  <!-- ordinateur portable -->
  <rect x="120" y="70" width="212" height="132" rx="10" fill="#0d2451"/>
  <rect x="130" y="80" width="192" height="112" rx="6" fill="#fff"/>
  <rect x="104" y="202" width="244" height="14" rx="7" fill="#c8d6ee"/>
  <g transform="translate(176 108)">
    <path d="M22 8C22 0 12-4 0-6 -2 6 6 14 22 16z" fill="#f5871f"/>
    <path d="M26 8c0-8 10-12 22-14 2 12-6 20-22 22z" fill="#1d4ed8"/>
    <path d="M-4 26c9-3 18-3 27 0v16c-9-3-18-3-27 0z" fill="#1d4ed8"/>
    <path d="M56 26c-9-3-18-3-27 0v16c9-3 18-3 27 0z" fill="#2e6bf0"/>
    <text x="26" y="66" text-anchor="middle" font-family="Inter, Arial" font-size="15" font-weight="800" fill="#1d4ed8">EDUCA</text>
  </g>
  <!-- livres et pot à crayons -->
  <rect x="330" y="176" width="96" height="12" rx="3" fill="#e8734a"/>
  <rect x="336" y="188" width="90" height="12" rx="3" fill="#2f7d4f"/>
  <rect x="330" y="200" width="96" height="12" rx="3" fill="#f5c33b"/>
  <rect x="52" y="150" width="46" height="52" rx="6" fill="#2e6bf0"/>
  <g stroke-width="4" stroke-linecap="round">
    <path d="M64 150v-26" stroke="#f5871f"/><path d="M75 150v-34" stroke="#e02424"/><path d="M86 150v-22" stroke="#0e9f6e"/>
  </g>
</svg>`);

console.log('visuels du tableau de bord générés');

/* --- Vignettes du catalogue de ressources -------------------------------- */
// Salle de classe : enseignant devant une carte
carte('thumb-classe-histoire', '#e8eef8', '#d4e0f2', `
  <rect x="150" y="26" width="140" height="96" rx="4" fill="#fdfbf4" stroke="#b9c7dd"/>
  <path d="M168 56c14-8 26 4 40-2s24 6 38 0 22 8 30 2v42c-10 6-22-4-32 2s-22-6-36 0-26-8-40-2z" fill="#9dc3a5"/>
  <circle cx="196" cy="72" r="7" fill="#6ea3d8"/>
  <circle cx="252" cy="88" r="9" fill="#6ea3d8"/>
  <circle cx="118" cy="70" r="20" fill="#6b4423"/>
  <path d="M88 138c0-20 14-32 30-32s30 12 30 32z" fill="#2f6bb5"/>
  <rect x="30" y="140" width="260" height="10" rx="4" fill="#c9a227" opacity=".5"/>
  ${[0, 1, 2].map((i) => `<g transform="translate(${44 + i * 74} 150)"><circle cx="20" cy="14" r="13" fill="${['#8d5a3b', '#e0a878', '#5c3a21'][i]}"/><path d="M0 50c0-14 9-23 20-23s20 9 20 23z" fill="${['#e05c3e', '#f2c14e', '#3f8f5f'][i]}"/></g>`).join('')}`);

// Paysage : écosystèmes
carte('thumb-ecosystemes', '#bfe4f7', '#8ecbe8', `
  <circle cx="272" cy="40" r="20" fill="#ffd75e"/>
  <path d="M0 122c40-16 76 4 112-6s70-18 108-6 66 18 100 8v82H0z" fill="#4d9f5e"/>
  <path d="M0 150c50 16 96-8 148 2s110 20 172 2v46H0z" fill="#2f7d4f"/>
  <path d="M96 200c28-22 66-22 96 0-30 14-66 14-96 0z" fill="#3aa0d1"/>
  ${[40, 214, 258].map((x, i) => `<g transform="translate(${x} ${[112, 104, 118][i]})"><rect x="8" y="24" width="6" height="26" fill="#6b4423"/><circle cx="11" cy="18" r="19" fill="#2f7d4f"/></g>`).join('')}`);

// Pile de manuels
carte('thumb-guide-tice', '#eae4fb', '#d5c9f6', `
  <rect x="86" y="52" width="148" height="30" rx="4" fill="#7e3af2"/>
  <rect x="76" y="84" width="168" height="30" rx="4" fill="#1d4ed8"/>
  <rect x="92" y="116" width="140" height="30" rx="4" fill="#2e6bf0"/>
  <rect x="80" y="148" width="160" height="30" rx="4" fill="#f5871f"/>
  <g fill="#fff" opacity=".85">
    <rect x="100" y="64" width="70" height="5" rx="2.5"/><rect x="90" y="96" width="86" height="5" rx="2.5"/>
    <rect x="106" y="128" width="62" height="5" rx="2.5"/><rect x="94" y="160" width="78" height="5" rx="2.5"/>
  </g>`);

// Schéma de circuit électrique
carte('thumb-electricite', '#eef3fa', '#dde7f5', `
  <rect x="46" y="44" width="228" height="118" rx="8" fill="#fff" stroke="#c3d2e8"/>
  <path d="M78 140V88h44v52M122 100h56M178 88v52h44V88" stroke="#1d4ed8" stroke-width="3" fill="none" stroke-linecap="round"/>
  <rect x="96" y="70" width="12" height="18" rx="2" fill="#f5871f"/>
  <circle cx="200" cy="76" r="13" fill="#f5c33b" stroke="#e0a020" stroke-width="2"/>
  <path d="M196 76l4 6 4-8" stroke="#8a6400" stroke-width="2" fill="none"/>
  <rect x="140" y="94" width="20" height="12" rx="2" fill="#0e9f6e"/>
  <text x="160" y="180" text-anchor="middle" font-family="Inter, Arial" font-size="13" font-weight="600" fill="#0f1b33">L'électricité</text>`);

// Carte de l'Afrique
carte('thumb-carte-afrique', '#d7ecf8', '#b9dcf0', `
  <path d="M140 24c26-6 52 4 62 22s2 34 12 48 26 16 22 34-22 22-26 38-2 30-16 34-24-12-36-22-30-8-40-24-4-32-10-48-10-30 2-44 12-32 30-38z" fill="#e9c46a" stroke="#c9902c" stroke-width="2"/>
  <path d="M150 60c18 4 30 0 42 8M138 108c22 6 40-4 58 6M152 154c16 8 30 2 44 10" stroke="#c9902c" stroke-width="1.6" fill="none" opacity=".8"/>
  <circle cx="174" cy="96" r="5" fill="#e02424"/>`);

// Système solaire
carte('thumb-systeme-solaire', '#050d24', '#122a5c', `
  <circle cx="40" cy="112" r="26" fill="#f5b301"/>
  ${[[104, 10, '#6ea3d8'], [150, 14, '#e07b39'], [200, 18, '#5fbf8a'], [252, 12, '#c96a6a']].map(([x, r, c]) => `<circle cx="${x}" cy="112" r="${r}" fill="${c}"/>`).join('')}
  <ellipse cx="200" cy="112" rx="28" ry="7" fill="none" stroke="#c9a227" stroke-width="2.4"/>
  ${Array.from({ length: 26 }, (_, i) => `<circle cx="${(i * 53) % 320}" cy="${(i * 71) % 200}" r="1.1" fill="#fff" opacity=".65"/>`).join('')}`);

// Pile de livres anciens
carte('thumb-corriges', '#f3ece2', '#e2d5c3', `
  <rect x="70" y="150" width="180" height="22" rx="3" fill="#8c3b2e"/>
  <rect x="80" y="128" width="164" height="22" rx="3" fill="#2f5d3f"/>
  <rect x="66" y="106" width="188" height="22" rx="3" fill="#1f3d70"/>
  <rect x="86" y="84" width="150" height="22" rx="3" fill="#a9762c"/>
  <g fill="#f5e6cd" opacity=".9">
    <rect x="92" y="92" width="60" height="4" rx="2"/><rect x="76" y="114" width="76" height="4" rx="2"/>
    <rect x="90" y="136" width="66" height="4" rx="2"/><rect x="80" y="158" width="82" height="4" rx="2"/>
  </g>`);

console.log('vignettes du catalogue générées');

/* --- Vignettes de l'espace élève ----------------------------------------- */
// Schéma : cellule végétale
carte('thumb-cellule', '#eef4ea', '#dcebd6', `
  <rect x="60" y="34" width="200" height="132" rx="16" fill="#a8d5a2" stroke="#5f9e57" stroke-width="3"/>
  <rect x="72" y="46" width="176" height="108" rx="12" fill="#cfe8c9"/>
  <ellipse cx="150" cy="100" rx="34" ry="26" fill="#7fbf7a" stroke="#4b8a46" stroke-width="2"/>
  <circle cx="150" cy="100" r="11" fill="#3f7a3b"/>
  ${[[96, 70], [212, 74], [104, 138], [206, 132], [176, 60]].map(([x, y]) => `<ellipse cx="${x}" cy="${y}" rx="13" ry="8" fill="#4b8a46" opacity=".75"/>`).join('')}
  ${[[86, 104], [226, 108]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="9" fill="#f2c14e"/>`).join('')}
  ${Array.from({ length: 5 }, (_, i) => `<path d="M${88 + i * 42} 168v14" stroke="#8fb98a" stroke-width="1.4"/>`).join('')}`);

// Pyramides d'Égypte
carte('thumb-egypte', '#9fd4ef', '#e8d5a8', `
  <circle cx="262" cy="46" r="20" fill="#ffe08a"/>
  <path d="M0 132h320v68H0z" fill="#e0c184"/>
  <path d="M96 132 160 34l64 98z" fill="#d4a95c"/>
  <path d="M160 34l64 98h-64z" fill="#b98a42"/>
  <path d="M22 132 66 68l44 64z" fill="#d4a95c"/>
  <path d="M66 68l44 64H66z" fill="#b98a42"/>
  <path d="M232 132l38-52 38 52z" fill="#c99f57"/>
  <path d="M0 160c40-10 80 6 120-2s90-12 130 0 50 6 70 2v40H0z" fill="#cfae72"/>`);

// Vignettes compactes des nouveautés et favoris
const mini = (nom, fond, glyphe) => fs.writeFileSync(path.join(OUT, `${nom}.svg`),
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" role="img" aria-label="">
  <rect width="120" height="120" rx="10" fill="${fond}"/>${glyphe}</svg>`);

mini('thumb-phrases', '#f3ecff', `
  <rect x="24" y="30" width="72" height="14" rx="7" fill="#7e3af2" opacity=".85"/>
  <rect x="24" y="52" width="56" height="14" rx="7" fill="#a78bfa"/>
  <rect x="24" y="74" width="64" height="14" rx="7" fill="#c4b5fd"/>
  <circle cx="96" cy="88" r="10" fill="#7e3af2"/><text x="96" y="93" text-anchor="middle" font-family="Inter, Arial" font-size="13" font-weight="700" fill="#fff">?</text>`);
mini('thumb-respiration', '#e7f3fb', `
  <path d="M60 26v22" stroke="#5b7f9e" stroke-width="6" stroke-linecap="round"/>
  <path d="M58 48c-4 16-22 14-26 32s6 30 18 26 12-24 8-36z" fill="#f19a9a"/>
  <path d="M62 48c4 16 22 14 26 32s-6 30-18 26-12-24-8-36z" fill="#e57373"/>`);
mini('thumb-equations', '#e9f7ef', `
  <text x="60" y="56" text-anchor="middle" font-family="Georgia, serif" font-size="30" font-weight="700" fill="#0e9f6e">2x+3</text>
  <path d="M28 68h64" stroke="#0e9f6e" stroke-width="4" stroke-linecap="round"/>
  <text x="60" y="98" text-anchor="middle" font-family="Georgia, serif" font-size="26" font-weight="700" fill="#0b7a55">= 9</text>`);
mini('thumb-fonctions', '#eef2fd', `
  <path d="M22 92h76M30 100V28" stroke="#94a3c4" stroke-width="3" stroke-linecap="round"/>
  <path d="M30 88C48 88 56 44 92 36" stroke="#1d4ed8" stroke-width="4" fill="none" stroke-linecap="round"/>
  <circle cx="92" cy="36" r="5" fill="#f5871f"/>`);

console.log('vignettes élève générées');

/* --- Illustrations des ressources méthodologiques ------------------------ */
// Concevoir une séquence : livre ouvert, ampoule et engrenages
carte('methodo-sequence', '#eaf1fe', '#dbe6fe', `
  <path d="M60 132c34-14 66-14 100 0v-58c-34-14-66-14-100 0z" fill="#fff" stroke="#8fb0e8" stroke-width="2"/>
  <path d="M260 132c-34-14-66-14-100 0v-58c34-14 66-14 100 0z" fill="#fff" stroke="#8fb0e8" stroke-width="2"/>
  <path d="M160 74v58" stroke="#8fb0e8" stroke-width="2"/>
  <circle cx="160" cy="52" r="18" fill="#f5c33b"/><path d="M154 66h12M156 72h8" stroke="#c99a12" stroke-width="2.4" stroke-linecap="round"/>
  <g fill="none" stroke="#1d4ed8" stroke-width="2.6">
    <circle cx="244" cy="48" r="13"/><circle cx="76" cy="56" r="10"/>
    <path d="M244 29v-8M244 75v-6M263 48h8M217 48h-8"/>
  </g>
  <g fill="#1d4ed8"><rect x="196" y="150" width="34" height="8" rx="4"/><rect x="90" y="150" width="34" height="8" rx="4"/><rect x="143" y="150" width="34" height="8" rx="4"/></g>`);

// Classe inversée : enseignant et élèves
carte('methodo-classe-inversee', '#e6eef9', '#d3e0f2', `
  <rect x="120" y="24" width="164" height="86" rx="6" fill="#2f6b58" stroke="#1f4a3c" stroke-width="3"/>
  <g stroke="#bfe3d3" stroke-width="3" stroke-linecap="round"><path d="M138 46h60M138 62h96M138 78h48"/></g>
  <circle cx="80" cy="58" r="17" fill="#6b4423"/><path d="M52 116c0-17 12-28 28-28s28 11 28 28z" fill="#2f6bb5"/>
  ${[0, 1, 2, 3].map((i) => `<g transform="translate(${58 + i * 62} 128)"><circle cx="20" cy="12" r="13" fill="${['#8d5a3b', '#e0a878', '#5c3a21', '#c98b5e'][i]}"/><path d="M2 48c0-13 8-22 18-22s18 9 18 22z" fill="${['#e05c3e', '#f2c14e', '#3f8f5f', '#4b7bd8'][i]}"/></g>`).join('')}`);

// Différenciation : cible et flèches
carte('methodo-differenciation', '#e9eff8', '#d8e3f3', `
  <circle cx="160" cy="104" r="54" fill="#fff" stroke="#c2d2ea" stroke-width="2"/>
  <circle cx="160" cy="104" r="38" fill="#e02424" opacity=".18"/>
  <circle cx="160" cy="104" r="24" fill="#e02424" opacity=".35"/>
  <circle cx="160" cy="104" r="10" fill="#e02424"/>
  <g stroke="#1d4ed8" stroke-width="3.4" stroke-linecap="round">
    <path d="M232 46l-58 50M236 46h-16M236 46v16"/>
    <path d="M88 46l58 50M88 46h16M88 46v16"/>
    <path d="M236 160l-62-42M236 160h-16M236 160v-16"/>
  </g>`);

// Évaluer par compétences : liste à cocher et stylo
carte('methodo-competences', '#fdf6e8', '#f7e8cb', `
  <rect x="86" y="26" width="150" height="150" rx="8" fill="#fff" stroke="#dfc79a" stroke-width="2"/>
  <rect x="132" y="18" width="58" height="18" rx="6" fill="#c9a227"/>
  ${[0, 1, 2, 3].map((i) => `
    <rect x="104" y="${58 + i * 28}" width="18" height="18" rx="4" fill="#0e9f6e" opacity=".18"/>
    <path d="M108 ${67 + i * 28}l4 4 7-8" stroke="#0e9f6e" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
    <rect x="132" y="${63 + i * 28}" width="${[78, 60, 86, 52][i]}" height="7" rx="3.5" fill="#d8c49a"/>`).join('')}
  <path d="M226 148l34-52 16 10-34 52-20 6z" fill="#4a6fa5"/><path d="M222 164l20-6-16-10z" fill="#0f1b33"/>`);

// Pensée critique : ampoule posée sur des livres
carte('methodo-pensee-critique', '#f2edfd', '#e3d9fa', `
  <rect x="96" y="140" width="130" height="18" rx="4" fill="#7e3af2"/>
  <rect x="86" y="158" width="150" height="18" rx="4" fill="#1d4ed8"/>
  <circle cx="160" cy="86" r="36" fill="#f5c33b"/>
  <path d="M144 122h32l-4 16h-24z" fill="#c9a227"/>
  <path d="M150 86c0-8 4-14 10-18M160 60v-14M126 60l-10-10M194 60l10-10" stroke="#e0a020" stroke-width="3" fill="none" stroke-linecap="round"/>`);

// Apprentissage collaboratif : bulles de discussion
carte('methodo-collaboratif', '#e7f2fb', '#d3e6f7', `
  ${[[92, 60, '#9ecbf0'], [160, 44, '#7fb8ea'], [228, 62, '#b4d9f5']].map(([x, y, c]) => `
    <ellipse cx="${x}" cy="${y}" rx="30" ry="22" fill="${c}"/>
    <path d="M${x - 8} ${y + 20}l4 12 10-11z" fill="${c}"/>
    <g fill="#4a7fb5"><circle cx="${x - 10}" cy="${y}" r="3"/><circle cx="${x}" cy="${y}" r="3"/><circle cx="${x + 10}" cy="${y}" r="3"/></g>`).join('')}
  ${[0, 1, 2].map((i) => `<g transform="translate(${72 + i * 68} 118)"><circle cx="22" cy="16" r="16" fill="${['#8d5a3b', '#e0a878', '#5c3a21'][i]}"/><path d="M0 60c0-16 10-26 22-26s22 10 22 26z" fill="${['#3f8f5f', '#e05c3e', '#4b7bd8'][i]}"/></g>`).join('')}`);

// Gestion de classe : tête et pièces de puzzle
carte('methodo-gestion-classe', '#e8f0fa', '#d6e4f4', `
  <path d="M118 172c-26-16-40-44-34-74s34-52 66-52 60 22 66 52-8 58-34 74z" fill="#fff" stroke="#a9c3e5" stroke-width="2.6"/>
  <g stroke="#fff" stroke-width="2">
    <path d="M118 74h36v34h-36z" fill="#e02424"/><path d="M154 74h36v34h-36z" fill="#f5871f"/>
    <path d="M118 108h36v34h-36z" fill="#0e9f6e"/><path d="M154 108h36v34h-36z" fill="#1d4ed8"/>
  </g>
  <circle cx="136" cy="91" r="6" fill="#fff"/><circle cx="172" cy="125" r="6" fill="#fff"/>`);

// TICE : ordinateur portable et graphiques
carte('methodo-tice', '#eaf1fe', '#d9e6fb', `
  <rect x="82" y="46" width="156" height="104" rx="8" fill="#0f2b5b"/>
  <rect x="92" y="56" width="136" height="84" rx="4" fill="#fff"/>
  <rect x="60" y="150" width="200" height="12" rx="6" fill="#b9cdec"/>
  <g fill="#1d4ed8"><rect x="106" y="104" width="16" height="26" rx="3"/><rect x="130" y="88" width="16" height="42" rx="3"/><rect x="154" y="96" width="16" height="34" rx="3"/><rect x="178" y="72" width="16" height="58" rx="3"/></g>
  <path d="M106 82l24-14 24 10 30-24" stroke="#f5871f" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  <circle cx="184" cy="54" r="5" fill="#f5871f"/>`);

console.log('illustrations méthodologiques générées');

/* --- Illustrations des méthodes de travail (espace élève) ---------------- */
// Prendre des notes
carte('eleve-notes', '#e9f2fb', '#d7e7f6', `
  <rect x="92" y="26" width="136" height="150" rx="8" fill="#fff" stroke="#a9c6e6" stroke-width="2"/>
  <path d="M120 26v150" stroke="#f0a1a1" stroke-width="2"/>
  ${Array.from({ length: 7 }, (_, i) => `<rect x="132" y="${48 + i * 18}" width="${i % 3 === 2 ? 48 : 80}" height="6" rx="3" fill="#b9cee6"/>`).join('')}
  <circle cx="112" cy="54" r="4" fill="#f5871f"/><circle cx="112" cy="90" r="4" fill="#0e9f6e"/><circle cx="112" cy="126" r="4" fill="#7e3af2"/>
  <path d="M212 152l36-56 16 10-36 56-20 6z" fill="#4a6fa5"/><path d="M208 168l20-6-16-10z" fill="#0f1b33"/>`);

// Organiser son temps
carte('eleve-planning', '#fdf3e7', '#f8e3c8', `
  <rect x="72" y="40" width="176" height="130" rx="10" fill="#fff" stroke="#e0bc86" stroke-width="2"/>
  <rect x="72" y="40" width="176" height="26" rx="10" fill="#e56a19"/>
  <path d="M104 40V26M196 40V26" stroke="#b1500f" stroke-width="6" stroke-linecap="round"/>
  ${[0, 1, 2].map((r) => [0, 1, 2, 3].map((c) => `<rect x="${92 + c * 38}" y="${84 + r * 28}" width="24" height="18" rx="4" fill="${(r + c) % 3 === 0 ? '#f5b26b' : '#f6e6d2'}"/>`).join('')).join('')}
  <circle cx="222" cy="150" r="24" fill="#fff" stroke="#e56a19" stroke-width="3"/>
  <path d="M222 136v14l10 6" stroke="#e56a19" stroke-width="3" fill="none" stroke-linecap="round"/>`);

// Lecture active
carte('eleve-lecture', '#efeafc', '#e0d6fa', `
  <path d="M62 140c32-14 62-14 96 0V62c-34-14-64-14-96 0z" fill="#fff" stroke="#a992e8" stroke-width="2"/>
  <path d="M258 140c-32-14-62-14-96 0V62c34-14 64-14 96 0z" fill="#fff" stroke="#a992e8" stroke-width="2"/>
  ${Array.from({ length: 4 }, (_, i) => `<rect x="${78}" y="${76 + i * 16}" width="${[58, 44, 62, 38][i]}" height="5" rx="2.5" fill="#c3b4ee"/><rect x="176" y="${76 + i * 16}" width="${[54, 62, 40, 58][i]}" height="5" rx="2.5" fill="#c3b4ee"/>`).join('')}
  <rect x="176" y="92" width="62" height="5" rx="2.5" fill="#f5c33b"/>
  <circle cx="228" cy="48" r="20" fill="#7e3af2" opacity=".18"/>
  <path d="M220 48l6 6 12-14" stroke="#7e3af2" stroke-width="3.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`);

// Réviser avant un examen
carte('eleve-revision', '#e7f6ef', '#d1eee0', `
  <rect x="96" y="34" width="128" height="142" rx="8" fill="#fff" stroke="#96d3b4" stroke-width="2"/>
  ${[0, 1, 2, 3].map((i) => `<rect x="116" y="${58 + i * 30}" width="${[86, 66, 90, 54][i]}" height="7" rx="3.5" fill="#bfe3d1"/>`).join('')}
  <circle cx="222" cy="150" r="30" fill="#0e9f6e"/>
  <path d="M210 150l8 9 16-19" stroke="#fff" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M84 44l-16 8 16 8" fill="none" stroke="#0b7a55" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M68 52c26-16 56 4 52 32" fill="none" stroke="#0b7a55" stroke-width="3" stroke-linecap="round"/>`);

// Travailler en équipe
carte('eleve-equipe', '#fdeef4', '#f9dbe7', `
  <circle cx="160" cy="98" r="46" fill="none" stroke="#e6a6c2" stroke-width="3" stroke-dasharray="7 8"/>
  ${[[160, 42], [110, 128], [210, 128]].map(([x, y], i) => `
    <g transform="translate(${x - 22} ${y - 22})">
      <circle cx="22" cy="16" r="15" fill="${['#8d5a3b', '#e0a878', '#5c3a21'][i]}"/>
      <path d="M2 56c0-14 9-24 20-24s20 10 20 24z" fill="${['#d61f69', '#7e3af2', '#1d4ed8'][i]}"/>
    </g>`).join('')}
  <circle cx="160" cy="98" r="16" fill="#fff" stroke="#d61f69" stroke-width="3"/>
  <path d="M153 98l5 5 10-11" stroke="#d61f69" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`);

// Carte mentale
carte('eleve-carte-mentale', '#e8f4fa', '#d3e9f5', `
  <g stroke="#7fb6d8" stroke-width="2.4" fill="none">
    <path d="M160 100 84 56M160 100l76-44M160 100 84 152M160 100l76 52"/>
  </g>
  <ellipse cx="160" cy="100" rx="38" ry="26" fill="#1d4ed8"/>
  <text x="160" y="105" text-anchor="middle" font-family="Inter, Arial" font-size="13" font-weight="700" fill="#fff">Idée</text>
  ${[[84, 56, '#0e9f6e'], [236, 56, '#f5871f'], [84, 152, '#7e3af2'], [236, 152, '#e02424']].map(([x, y, c]) => `<ellipse cx="${x}" cy="${y}" rx="28" ry="18" fill="${c}" opacity=".85"/>`).join('')}`);

// Mémoriser : cartes de révision
carte('eleve-memoriser', '#fff6e6', '#fbe9c6', `
  <rect x="70" y="70" width="120" height="82" rx="8" fill="#fff" stroke="#e2bd7c" stroke-width="2" transform="rotate(-8 130 111)"/>
  <rect x="104" y="58" width="120" height="82" rx="8" fill="#fff" stroke="#e2bd7c" stroke-width="2" transform="rotate(4 164 99)"/>
  <rect x="132" y="76" width="120" height="82" rx="8" fill="#fff" stroke="#c9a227" stroke-width="2.6"/>
  <rect x="150" y="98" width="60" height="7" rx="3.5" fill="#e0c68d"/>
  <rect x="150" y="116" width="84" height="7" rx="3.5" fill="#e0c68d"/>
  <circle cx="234" cy="60" r="18" fill="#f5871f"/><path d="M228 60l5 5 10-11" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`);

// Gérer le stress d'un examen
carte('eleve-examen', '#eef0fb', '#dee2f7', `
  <circle cx="160" cy="96" r="46" fill="#fff" stroke="#a3abe0" stroke-width="3"/>
  <path d="M160 66v32l22 12" stroke="#4a55b8" stroke-width="4" fill="none" stroke-linecap="round"/>
  <path d="M126 44l-14-12M194 44l14-12" stroke="#4a55b8" stroke-width="5" stroke-linecap="round"/>
  <path d="M92 168c22-10 44-10 68 0s46 10 68 0" stroke="#8f97d6" stroke-width="4" fill="none" stroke-linecap="round"/>
  <circle cx="160" cy="96" r="4" fill="#4a55b8"/>`);

console.log('illustrations méthodologiques élève générées');

/* --- Bannière d'accueil, version « carte » ------------------------------- */
fs.writeFileSync(path.join(OUT, 'hero-eleve-casque.svg'), `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 620 520" role="img" aria-label="">
  <defs>
    <linearGradient id="ec" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#c9dcfa"/><stop offset="1" stop-color="#9dbdf0"/>
    </linearGradient>
    <linearGradient id="ordi" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#dbe4f2"/><stop offset="1" stop-color="#b6c4da"/>
    </linearGradient>
  </defs>
  <!-- personnage -->
  <path d="M214 520c0-96 48-152 116-152s116 56 116 152z" fill="#2f6bd8"/>
  <path d="M246 520c0-78 38-122 84-122s84 44 84 122z" fill="#4b86ea"/>
  <circle cx="330" cy="266" r="86" fill="#c98a5e"/>
  <path d="M244 254c0-62 38-102 86-102s86 40 86 102c0 14-6 24-14 24-10 0-8-18-22-26-22-12-58-6-84-22-16-10-18 24-30 34-12 10-22 4-22-10z" fill="#3b2418"/>
  <!-- casque -->
  <path d="M240 258a90 90 0 0 1 180 0" fill="none" stroke="#f2f5fa" stroke-width="18" stroke-linecap="round"/>
  <rect x="222" y="248" width="34" height="58" rx="16" fill="#f2f5fa"/>
  <rect x="404" y="248" width="34" height="58" rx="16" fill="#e4eaf4"/>
  <!-- ordinateur -->
  <rect x="176" y="384" width="268" height="16" rx="8" fill="#94a6c4"/>
  <path d="M196 384l24-108h180l24 108z" fill="url(#ordi)"/>
  <rect x="236" y="296" width="148" height="72" rx="6" fill="#7f93b4" opacity=".5"/>
  <!-- tasse et plante -->
  <rect x="470" y="424" width="66" height="56" rx="10" fill="#f4f7fc"/>
  <path d="M536 440h16a14 14 0 0 1 0 28h-16z" fill="none" stroke="#f4f7fc" stroke-width="8"/>
  <path d="M556 424c-14-2-24-12-24-26 14-2 24 8 24 26z" fill="#4bbf7a"/>
  <path d="M560 420c12-6 18-18 16-32-14 2-20 14-16 32z" fill="#7cd79f"/>
  <path d="M548 424h26l-5 56h-16z" fill="#e2edfb"/>
</svg>`);

console.log('bannière d’accueil générée');
