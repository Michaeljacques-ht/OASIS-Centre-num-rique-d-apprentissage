'use strict';
/**
 * Frontend EDUCA Diffusion — rendu des espaces public, enseignant et élève.
 *
 * Responsabilités, conformément à l'architecture de l'écosystème : affichage,
 * navigation, session, appels API. Aucune logique métier, aucun accès direct
 * à la base de données.
 *
 * Note d'architecture : l'écosystème prévoit Next.js pour les frontends. Ce
 * serveur de rendu est transitoire — il consomme déjà l'API du service, ce qui
 * rend le remplacement de la couche de présentation indépendant du backend.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

const { layout } = require('./components/layout');
const { siteLayout } = require('./components/site-layout');
const { resoudre } = require('./services/routeur');
const store = require('./services/api/diffusion');
const { appeler } = require('./services/api/client');
const { html } = require('./lib/html');
const B = require('./components/blocks');

const PORT = Number(process.env.PORT) || 3000;
const PUBLIC = path.join(__dirname, 'public');
const COMPTES = path.join(__dirname, 'data', 'comptes-demo.json');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.webp': 'image/webp', '.woff2': 'font/woff2',
};

const ROLES = ['enseignant', 'eleve'];

/* --- Session ---------------------------------------------------------------- */
function lireCookies(entete = '') {
  return entete.split(';').reduce((acc, part) => {
    const [k, ...v] = part.trim().split('=');
    if (k) acc[decodeURIComponent(k)] = decodeURIComponent(v.join('='));
    return acc;
  }, {});
}

/**
 * Contexte de la requête.
 *
 * TRANSITOIRE — le rôle vient d'un cookie de démonstration. À l'intégration,
 * il viendra du jeton émis par le gateway, et l'identité transmise à l'API
 * sera ce jeton, non l'en-tête de développement.
 */
async function contexte(req, url) {
  const cookies = lireCookies(req.headers.cookie);
  const demande = url.searchParams.get('role');
  const role = ROLES.includes(demande) ? demande : ROLES.includes(cookies.ed_role) ? cookies.ed_role : 'enseignant';

  const comptes = JSON.parse(fs.readFileSync(COMPTES, 'utf8'));
  const user = comptes.find((u) => u.role === role) || comptes[0];
  const nav = (await store.read('nav'))[role];

  const identite = {
    sub: user.id, role,
    school_id: process.env.ECOLE_DEMO || 'eco_demo',
    academic_year_id: process.env.ANNEE_DEMO || 'an_2026',
  };

  const query = {};
  for (const [k, v] of url.searchParams) if (k !== 'role') query[k] = v;

  const autre = role === 'enseignant' ? 'eleve' : 'enseignant';
  return {
    path: url.pathname, query, role, user, nav, identite,
    poserCookie: demande === role,
    otherRole: {
      label: autre === 'eleve' ? 'espace élève' : 'espace enseignant',
      href: `${url.pathname}?role=${autre}`,
    },
  };
}

/* --- Réponses ---------------------------------------------------------------- */
const envoyer = (res, statut, type, corps, entetes = {}) => {
  res.writeHead(statut, { 'Content-Type': type, 'X-Content-Type-Options': 'nosniff', ...entetes });
  res.end(corps);
};

function servirStatique(req, res, pathname) {
  const cible = path.join(PUBLIC, path.normalize(pathname).replace(/^(\.\.[/\\])+/, ''));
  if (!cible.startsWith(PUBLIC)) return envoyer(res, 403, 'text/plain', 'Accès refusé');
  fs.readFile(cible, (err, corps) => {
    if (err) return introuvable(req, res);
    const type = MIME[path.extname(cible).toLowerCase()] || 'application/octet-stream';
    const cache = process.env.NODE_ENV === 'production' ? 'public, max-age=604800' : 'no-cache';
    envoyer(res, 200, type, corps, { 'Cache-Control': cache });
  });
}

async function rendre(res, ctx, vue, statut = 200) {
  const entetes = {};
  if (ctx.poserCookie) entetes['Set-Cookie'] = `ed_role=${ctx.role}; Path=/; Max-Age=2592000; SameSite=Lax`;
  const corps = vue.chrome === 'site'
    ? await siteLayout(vue)
    : layout({ ...vue, nav: ctx.nav, user: ctx.user, otherRole: ctx.otherRole });
  envoyer(res, statut, MIME['.html'], corps, entetes);
}

async function introuvable(req, res) {
  const url = new URL(req.url, 'http://localhost');
  const ctx = await contexte(req, url);
  const main = html`
    ${B.hero({
      tone: 'dark', mark: 'search',
      title: 'Cette page n’existe pas',
      lede: `Le chemin ${url.pathname} ne correspond à aucun module. Vérifiez l’adresse, ou repartez du tableau de bord.`,
      actions: [{ label: 'Retour au tableau de bord', href: '/tableau-de-bord', icon: 'home' }],
    })}`;
  await rendre(res, ctx, { title: 'Page introuvable', active: '', main }, 404);
}

/* --- Serveur ----------------------------------------------------------------- */
const serveur = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

  if (req.method !== 'GET' && req.method !== 'HEAD') {
    return envoyer(res, 405, 'text/plain; charset=utf-8', 'Méthode non autorisée', { Allow: 'GET, HEAD' });
  }

  // Le QR code est produit par le service : le frontend relaie, il ne calcule pas.
  if (url.pathname === '/qr.svg') {
    try {
      const image = await appeler(`/public/qr${url.search}`);
      return envoyer(res, 200, 'image/svg+xml', image, { 'Cache-Control': 'public, max-age=86400' });
    } catch (e) {
      return envoyer(res, e.statut || 502, 'text/plain; charset=utf-8', e.message);
    }
  }

  if (/^\/(css|js|img)\//.test(url.pathname)) return servirStatique(req, res, url.pathname);
  if (url.pathname === '/favicon.ico') return servirStatique(req, res, '/img/logo.svg');

  const pathname = url.pathname.length > 1 ? url.pathname.replace(/\/+$/, '') : '/';
  try {
    const ctx = await contexte(req, url);
    const match = resoudre(pathname, await store.read('nav'));
    if (!match) return introuvable(req, res);
    await rendre(res, ctx, await match.page(ctx));
  } catch (err) {
    console.error(`[500] ${pathname}`, err.message);
    envoyer(res, 502, 'text/plain; charset=utf-8',
      'Le service de diffusion est injoignable. Démarrez diffusion-service, puis rechargez.');
  }
});

serveur.listen(PORT, () => {
  console.log(`EDUCA Diffusion — frontend : http://localhost:${PORT}`);
  console.log(`  API diffusion-service : ${require('./services/api/client').BASE}`);
});
