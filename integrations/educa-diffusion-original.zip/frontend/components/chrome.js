'use strict';
/** Marque, barre latérale et barre supérieure : l'ossature commune. */
const { html, raw, each, when } = require('../lib/html');
const { icon } = require('../lib/icons');

const brand = () => html`
  <a class="brand" href="/" aria-label="EDUCA Diffusion, accueil">
    <img src="/img/logo.svg" width="38" height="38" alt="">
    <span class="brand__word">
      <span class="brand__educa">EDUCA</span>
      <span class="brand__diffusion">DIFFUSION</span>
    </span>
  </a>`;

/**
 * @param {{groups: Array, active: string, help: object}} nav
 */
function sidebar(nav, active) {
  return html`
    <aside class="sidebar" id="sidebar">
      <div class="sidebar__brand">${brand()}</div>
      <nav class="sidebar__nav" aria-label="Navigation principale">
        ${when(nav.principal, () => html`
          <a class="nav-primary" href="${nav.principal.href}"
             ${raw(nav.principal.href === active ? 'aria-current="page"' : '')}>
            ${icon(nav.principal.icon, { size: 19 })}
            <span>${nav.principal.label}</span>
          </a>`)}
        ${each(nav.groups.filter((g) => !g.masque), (group) => html`
          <div class="nav-group">
            ${when(group.label, () => html`<p class="nav-group__label eyebrow">${group.label}</p>`)}
            ${each(group.items, (item) => html`
              <a class="nav-item" href="${item.href}"
                 ${raw(item.href === active ? 'aria-current="page"' : '')}>
                ${icon(item.icon)}
                <span>${item.label}</span>
                ${when(item.count, html`<span class="nav-item__count">${item.count}</span>`)}
              </a>`)}
          </div>`)}
      </nav>
      ${when(nav.cta, () => html`
        <div class="sidebar__cta">
          <a class="btn btn--primary btn--block" href="${nav.cta.href}">
            ${icon(nav.cta.icon, { size: 18 })} ${nav.cta.label}
          </a>
        </div>`)}
      ${when(nav.help, () => html`
        <div class="sidebar__help">
          <h4>${icon('help', { size: 16 })} ${nav.help.title}</h4>
          <p>${nav.help.text}</p>
          <a class="btn btn--ghost btn--sm btn--block" href="${nav.help.href}">${nav.help.action}</a>
        </div>`)}
    </aside>`;
}

/**
 * @param {{user: object, search: string, otherRole: object}} opts
 */
function topbar({ user, search, otherRole, action }) {
  return html`
    <header class="topbar">
      <button class="topbar__toggle" type="button" data-nav-toggle aria-controls="sidebar"
              aria-expanded="false" aria-label="Afficher ou masquer la navigation">
        ${icon('menu', { size: 22 })}
      </button>

      <form class="topbar__search" role="search" action="/recherche" method="get">
        <label class="sr-only" for="q">Rechercher</label>
        <input id="q" name="q" type="search" placeholder="${search}" autocomplete="off">
        <button type="submit" aria-label="Lancer la recherche">${icon('search', { size: 19 })}</button>
      </form>

      <div class="topbar__actions">
        ${when(action, () => html`
          <a class="btn btn--outline btn--round topbar__action" href="${action.href}">
            ${icon(action.icon || 'plus', { size: 18 })} ${action.label}
          </a>`)}
        <a class="icon-btn" href="/notifications" aria-label="Notifications, ${user.notifications} non lues">
          ${icon('bell', { size: 20 })}
          ${when(user.notifications, html`<span class="icon-btn__badge">${user.notifications}</span>`)}
        </a>
        <a class="icon-btn" href="/messages" aria-label="Messages, ${user.messages} non lus">
          ${icon('mail', { size: 20 })}
          ${when(user.messages, html`<span class="icon-btn__badge">${user.messages}</span>`)}
        </a>
        <a class="icon-btn" href="/aide" aria-label="Centre d'aide">${icon('help', { size: 20 })}</a>
        <button class="userchip" type="button" aria-haspopup="true" aria-expanded="false">
          <img class="userchip__avatar" src="${user.avatar}" alt="">
          <span class="userchip__id">
            <span class="userchip__name">${user.name}</span>
            <span class="userchip__role">${user.roleLabel}</span>
          </span>
          ${icon('chevronDown', { size: 16 })}
        </button>
        ${when(otherRole, () => html`
          <a class="btn btn--ghost btn--sm" href="${otherRole.href}"
             title="Basculer d'espace pour la démonstration">Voir : ${otherRole.label}</a>`)}
      </div>
    </header>`;
}

module.exports = { brand, sidebar, topbar };
