'use strict';
/**
 * Blocs de page. Chaque fonction correspond à un patron repéré dans les
 * maquettes : bannière, rangée de compteurs, barre de filtres, onglets,
 * liste de ressources, cartes du rail, encadré conseil, pagination.
 */
const { html, raw, each, when, number, compact } = require('../lib/html');
const { icon } = require('../lib/icons');

/* --- Bannière ----------------------------------------------------------- */
function hero({ title, lede, mark, tone = 'dark', pills = [], actions = [] }) {
  return html`
    <section class="hero hero--${tone}">
      <div class="hero__inner">
        ${when(mark, () => html`<span class="hero__mark">${icon(mark, { size: 30, stroke: 1.6 })}</span>`)}
        <div>
          <h1>${title}</h1>
          <p class="hero__lede">${lede}</p>
        </div>
      </div>
      ${when(pills.length || actions.length, html`
        <div class="hero__actions">
          ${each(pills, (p) => html`<a class="hero__pill" href="${p.href}">${icon(p.icon, { size: 16 })}${p.label}</a>`)}
          ${each(actions, (a) => html`<a class="btn ${a.variant || 'btn--light'}" href="${a.href}">${when(a.icon, icon(a.icon, { size: 17 }))}${a.label}</a>`)}
        </div>`)}
    </section>`;
}

/* --- Rangée de compteurs ------------------------------------------------ */
function stats(items) {
  return html`
    <div class="stats">
      ${each(items, (s) => html`
        <div class="stat">
          <span class="stat__icon" style="background:var(--t-${s.tone || 'blue'}-bg);color:var(--t-${s.tone || 'blue'}-fg)">
            ${icon(s.icon, { size: 21 })}
          </span>
          <span>
            <span class="stat__value">${typeof s.value === 'number' ? number(s.value) : s.value}</span>
            <span class="stat__label">${s.label}</span>
            ${when(s.delta, html`<span class="stat__delta">${s.delta}</span>`)}
          </span>
        </div>`)}
    </div>`;
}

/* --- Barre de filtres --------------------------------------------------- */
function filters({ selects = [], search, action = '' }) {
  return html`
    <form class="filters" method="get" action="${action}">
      ${each(selects, (s) => html`
        <label class="select">
          <span class="muted">${s.label} :</span>
          <select name="${s.name}" onchange="this.form.requestSubmit()">
            ${each(s.options, (o) => html`
              <option value="${o.value}" ${raw(o.value === s.value ? 'selected' : '')}>${o.label}</option>`)}
          </select>
          ${icon('chevronDown', { size: 15 })}
        </label>`)}
      ${when(search, () => html`
        <label class="search-inline">
          ${icon('search', { size: 17 })}
          <input type="search" name="q" value="${search.value || ''}" placeholder="${search.placeholder}">
        </label>`)}
      <button class="btn btn--ghost" type="submit">${icon('filter', { size: 17 })} Filtres</button>
    </form>`;
}

/* --- Onglets ------------------------------------------------------------ */
function tabs(items) {
  return html`
    <div class="tabs" role="tablist">
      ${each(items, (t) => html`
        <a class="tab" role="tab" href="${t.href}" aria-selected="${t.active ? 'true' : 'false'}">
          ${when(t.icon, icon(t.icon, { size: 17 }))}${t.label}
          ${when(t.count, html`<span class="tab__count">${t.count}</span>`)}
        </a>`)}
    </div>`;
}

/* --- Liste de ressources ------------------------------------------------ */
function list({ title, count, tools, rows, pager: pages }) {
  return html`
    <section class="list">
      <div class="list__head">
        <h2 class="list__title">${title}${when(count !== undefined, html` <span class="muted">(${number(count)})</span>`)}</h2>
        <div class="list__tools">${tools || ''}</div>
      </div>
      ${when(rows.length === 0, empty())}
      ${each(rows, row)}
      ${when(pages, () => pager(pages))}
    </section>`;
}

function row(item) {
  return html`
    <article class="row">
      <span class="row__thumb" style="${raw(item.tone ? `background:var(--t-${item.tone}-bg);color:var(--t-${item.tone}-fg)` : '')}">
        ${item.image ? raw(`<img src="${item.image}" alt="">`) : icon(item.icon || 'file', { size: 24 })}
      </span>
      <div>
        <h3 class="row__title"><a href="${item.href || '#'}">${item.title}</a></h3>
        ${when(item.description, html`<p class="row__desc">${item.description}</p>`)}
        ${when(item.tags && item.tags.length, html`
          <div class="row__tags">${each(item.tags, (t) => html`<span class="tag tag--${t.tone || 'gray'}">${t.label}</span>`)}</div>`)}
        ${when(item.facts && item.facts.length, html`
          <div class="row__meta" style="margin-top:8px">
            ${each(item.facts, (f) => html`<span>${when(f.label, html`<b>${f.label}</b>`)}${f.value}</span>`)}
          </div>`)}
      </div>
      <div class="row__actions">
        ${each(item.actions || [], (a) => html`
          <a class="icon-btn" href="${a.href}" aria-label="${a.label}" title="${a.label}">${icon(a.icon, { size: 18 })}</a>`)}
        ${when(item.views !== undefined, html`
          <span class="rail__views">${icon('eye', { size: 15 })} ${compact(item.views)}</span>`)}
      </div>
    </article>`;
}

/* --- Cartes du rail droit ---------------------------------------------- */
function railCard({ title, link, items = [], body, foot }) {
  return html`
    <section class="card">
      ${when(title, html`
        <div class="card__head">
          <h3>${title}</h3>
          ${when(link, () => html`<a class="card__link" href="${link.href}">${link.label}</a>`)}
        </div>`)}
      ${when(body, html`<div class="card__body">${body}</div>`)}
      ${each(items, (i) => html`
        <a class="rail__item" href="${i.href || '#'}">
          ${when(i.rank, html`<span class="rail__rank">${i.rank}</span>`)}
          ${when(i.icon, () => html`
            <span class="rail__icon" style="background:var(--t-${i.tone || 'blue'}-bg);color:var(--t-${i.tone || 'blue'}-fg)">
              ${icon(i.icon, { size: 19 })}
            </span>`)}
          <span>
            <span class="rail__label">${i.label}</span>
            ${when(i.hint, html`<span class="rail__hint">${i.hint}</span>`)}
          </span>
          ${when(i.views !== undefined, html`<span class="rail__views">${icon('eye', { size: 15 })} ${compact(i.views)}</span>`)}
          ${when(i.chevron !== false && i.views === undefined, html`<span class="rail__chevron">${icon('chevronRight', { size: 17 })}</span>`)}
        </a>`)}
      ${when(foot, html`<div class="card__foot">${foot}</div>`)}
    </section>`;
}

/* --- Encadré conseil ---------------------------------------------------- */
function note({ tone = 'tip', title, text, link, iconName = 'bulb' }) {
  return html`
    <aside class="note note--${tone}">
      <p class="note__title">${icon(iconName, { size: 18 })} ${title}</p>
      <p>${text}</p>
      ${when(link, () => html`<a class="note__link" href="${link.href}">${link.label} ${icon('arrowRight', { size: 15 })}</a>`)}
    </aside>`;
}

/* --- Pagination et état vide ------------------------------------------- */
function pager({ page, pages, href }) {
  const at = (n) => `${href}${href.includes('?') ? '&' : '?'}page=${n}`;
  const shown = [...new Set([1, 2, 3, pages].filter((n) => n >= 1 && n <= pages))];
  return html`
    <nav class="pager" aria-label="Pagination">
      <a href="${at(Math.max(1, page - 1))}" aria-label="Page précédente">${icon('chevronLeft', { size: 16 })}</a>
      ${each(shown, (n, i) => html`
        ${when(i > 0 && n - shown[i - 1] > 1, html`<span aria-hidden="true">…</span>`)}
        <a href="${at(n)}" ${raw(n === page ? 'aria-current="page"' : '')}>${n}</a>`)}
      <a href="${at(Math.min(pages, page + 1))}" aria-label="Page suivante">${icon('chevronRight', { size: 16 })}</a>
    </nav>`;
}

function empty(opts = {}) {
  return html`
    <div class="empty">
      <h3>${opts.title || 'Rien à afficher pour ces filtres'}</h3>
      <p>${opts.text || 'Élargissez la recherche, ou créez la première ressource de cette catégorie.'}</p>
      ${when(opts.action, () => html`<a class="btn btn--primary" href="${opts.action.href}">${opts.action.label}</a>`)}
    </div>`;
}

module.exports = { hero, stats, filters, tabs, list, row, railCard, note, pager, empty };
