'use strict';
/** Document complet : ossature + contenu + rail droit. */
const { html, raw, when } = require('../lib/html');
const { sidebar, topbar } = require('./chrome');

/**
 * @param {{title:string, nav:object, active:string, user:object,
 *           search:string, otherRole?:object, main:any, rail?:any}} view
 */
function layout(view) {
  return `<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${view.title} — EDUCA Diffusion</title>
<meta name="description" content="${view.description || 'Plateforme éducative EDUCA Diffusion : ressources, évaluations et laboratoire virtuel pour l’enseignement secondaire.'}">
<meta name="theme-color" content="#1d4ed8">
<link rel="icon" href="/img/logo.svg" type="image/svg+xml">
<link rel="stylesheet" href="/css/tokens.css">
<link rel="stylesheet" href="/css/base.css">
<link rel="stylesheet" href="/css/layout.css">
<link rel="stylesheet" href="/css/components.css">
${(view.styles || []).map((s) => `<link rel="stylesheet" href="/css/${s}.css">`).join('\n')}
</head>
<body>
<a class="sr-only" href="#contenu">Aller au contenu</a>
<div class="app">
  ${sidebar(view.nav, view.active)}
  <div class="main">
    ${topbar({ user: view.user, search: view.search || 'Rechercher…', otherRole: view.otherRole, action: view.topAction })}
    <main class="page" id="contenu">
      <div class="page__grid">
        <div class="page__main">${view.main}</div>
        ${when(view.rail, html`<div class="rail">${view.rail}</div>`)}
      </div>
    </main>
  </div>
</div>
<script src="/js/app.js" defer></script>
</body>
</html>`;
}

module.exports = { layout };
