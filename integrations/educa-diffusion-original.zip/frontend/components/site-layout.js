'use strict';
/** Gabarit du site public : en-tête, contenu, pied de page. */
const { html, raw, each, when } = require('../lib/html');
const { icon } = require('../lib/icons');
const store = require('../services/api/diffusion');

const brandBlock = (tagline) => html`
  <a class="site-brand" href="/">
    <span class="site-brand__mark"><img src="/img/logo.svg" width="30" height="30" alt=""></span>
    <span class="brand__word">
      <span class="brand__educa">EDUCA</span>
      <span class="brand__diffusion">DIFFUSION</span>
      ${when(tagline, html`<span class="site-brand__tag">Diffuser le savoir autrement</span>`)}
    </span>
  </a>`;

function header(nav, panier) {
  return html`
    <header class="site-header">
      <div class="wrap site-header__bar">
        ${brandBlock(true)}
        <nav class="site-nav" aria-label="Navigation du site">
          ${each(nav, (item) => html`
            <a href="${item.href}" ${raw(item.actif ? 'aria-current="page"' : '')}>
              ${item.label}${when(item.menu, icon('chevronDown', { size: 15 }))}
            </a>`)}
        </nav>
        <div class="site-header__tools">
          <form class="site-search" role="search" action="/recherche">
            <label class="sr-only" for="q">Rechercher un contenu</label>
            <input id="q" name="q" type="search" placeholder="Rechercher…">
            <button type="submit" aria-label="Lancer la recherche">${icon('search', { size: 17 })}</button>
          </form>
          <a class="icon-btn" href="/panier" aria-label="Panier, ${panier} articles">
            ${icon('cart', { size: 21 })}
            ${when(panier, html`<span class="icon-btn__badge" style="background:var(--blue-600)">${panier}</span>`)}
          </a>
          <a class="btn btn--outline btn--sm btn--round" href="/connexion">Se connecter</a>
          <a class="btn btn--navy btn--sm btn--round" href="/inscription">S'inscrire</a>
          <button class="site-burger" type="button" data-nav-toggle aria-label="Afficher le menu">
            ${icon('menu', { size: 22 })}
          </button>
        </div>
      </div>
    </header>`;
}

function footer(pied, nav) {
  return html`
    <footer class="site-footer">
      <div class="wrap">
        <div class="footer-grid">
          <div class="footer-brand">
            ${brandBlock(false)}
            <p style="color:#fff;font-weight:600;margin-top:12px">Diffuser le savoir autrement</p>
            <p>${pied.description}</p>
            <div class="footer-social">
              ${each(pied.reseaux, (r) => html`
                <a href="${r.href}" aria-label="${r.label}" rel="noopener">${icon(r.icon, { size: 18 })}</a>`)}
            </div>
          </div>
          ${each(pied.colonnes, (col) => html`
            <div>
              <h4>${col.titre}</h4>
              <div class="footer-links">
                ${each(col.liens, (l) => html`<a href="${l.href}">${l.label}</a>`)}
              </div>
            </div>`)}
          <div>
            <h4>Restez informé</h4>
            <p style="font-size:var(--fs-sm)">Recevez nos nouveautés, nos offres et nos conseils pédagogiques.</p>
            <form class="newsletter" action="/newsletter" method="post">
              <label class="sr-only" for="email">Votre adresse électronique</label>
              <input id="email" name="email" type="email" required placeholder="Votre email">
              <button class="btn btn--green" type="submit">S'abonner</button>
            </form>
          </div>
        </div>
        <div class="footer-bottom">
          <span>© ${new Date().getFullYear()} EDUCA DIFFUSION. Tous droits réservés.</span>
          <nav aria-label="Informations légales">
            ${each(pied.legal, (l) => html`<a href="${l.href}">${l.label}</a>`)}
          </nav>
        </div>
      </div>
    </footer>`;
}

/**
 * @param {{title:string, description?:string, body:any}} view
 */
async function siteLayout(view) {
  const contenu = await store.read('accueil');
  return `<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${view.title} — EDUCA Diffusion</title>
<meta name="description" content="${view.description || 'EDUCA Diffusion — diffuser le savoir autrement : contenus et ressources pédagogiques numériques pour apprendre, enseigner et progresser.'}">
<meta name="theme-color" content="#1d4ed8">
<meta property="og:title" content="${view.title} — EDUCA Diffusion">
<meta property="og:description" content="Diffuser le savoir autrement.">
<meta property="og:type" content="website">
<link rel="icon" href="/img/logo.svg" type="image/svg+xml">
<link rel="stylesheet" href="/css/tokens.css">
<link rel="stylesheet" href="/css/base.css">
<link rel="stylesheet" href="/css/components.css">
<link rel="stylesheet" href="/css/site.css">
${(view.styles || []).map((f) => `<link rel="stylesheet" href="/css/${f}.css">`).join('\n')}
</head>
<body class="site${view.bodyClass ? ' ' + view.bodyClass : ''}">
<a class="sr-only" href="#contenu">Aller au contenu</a>
${header(contenu.nav || [], view.panier || 2)}
<main id="contenu">${view.body}</main>
${footer(contenu.pied || {}, contenu.nav || [])}
<script src="/js/app.js" defer></script>
</body>
</html>`;
}

module.exports = { siteLayout };
