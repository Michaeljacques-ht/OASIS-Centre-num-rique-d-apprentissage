'use strict';
/**
 * Ressources pédagogiques.
 * — Enseignant : catalogue filtrable, grille ou liste, filtres avancés.
 * — Élève : disciplines, recommandations, parcours et nouveautés.
 * Les deux espaces partagent la même adresse ; le rôle décide de la vue.
 */
const { html, raw, each, when, number, compact } = require('../lib/html');
const { icon } = require('../lib/icons');
const B = require('../components/blocks');
const store = require('../services/api/diffusion');

const PAR_PAGE = 8;

module.exports = async function ressourcesPedagogiques(ctx) {
  return ctx.role === 'eleve' ? vueEleve(ctx) : vueEnseignant(ctx);
};

/* ========================================================================= */
/* Enseignant                                                                */
/* ========================================================================= */
async function vueEnseignant(ctx) {
  const { query } = ctx;
  const meta = await store.read('ressources-pedagogiques-meta', ctx.identite, {});
  const onglet = query.public === 'eleves' ? 'eleves' : 'enseignants';
  const grille = query.affichage !== 'liste';

  const totalFonds = (await store.read('ressources-pedagogiques', ctx.identite, {})).length;
  const toutes = await store.query('ressources-pedagogiques', {
    discipline: query.discipline,
    niveau: query.niveau,
    type: query.type,
    format: query.format,
    famille: query.famille,
  }, ctx.identite);

  const trouvees = toutes
    .filter((r) => r.public === onglet || onglet === 'enseignants')
    .filter((r) => {
      const mots = (query.mots || query.q || '').toLowerCase().trim();
      return !mots || `${r.titre} ${r.discipline} ${r.type}`.toLowerCase().includes(mots);
    });

  const page = Math.max(1, parseInt(query.page, 10) || 1);
  const pages = Math.max(1, Math.ceil(trouvees.length / PAR_PAGE));
  const visibles = trouvees.slice((page - 1) * PAR_PAGE, page * PAR_PAGE);

  /** Conserve les filtres actifs quand on change d'onglet ou d'affichage. */
  const lien = (modif) => {
    const params = new URLSearchParams(
      Object.entries({ ...query, ...modif }).filter(([, v]) => v && v !== 'toutes' && v !== 'tous')
    );
    const s = params.toString();
    return `/ressources-pedagogiques${s ? '?' + s : ''}`;
  };

  const main = html`
    <!-- En-tête clair -->
    <div class="page-head">
      <span class="page-head__mark">${icon('cap', { size: 26 })}</span>
      <div>
        <h1>Ressources pédagogiques – Enseignant</h1>
        <p>Accédez à des ressources de qualité pour planifier vos cours, créer des activités et améliorer vos pratiques pédagogiques.</p>
      </div>
      <div class="page-head__aside">
        <a class="btn btn--ghost" href="/aide/ressources-pedagogiques">
          ${icon('help', { size: 18 })} Guide d'utilisation
        </a>
      </div>
    </div>

    ${B.tabs([
      { label: 'Pour les enseignants', href: lien({ public: null, page: null }), icon: 'users', active: onglet === 'enseignants' },
      { label: 'Pour les élèves', href: lien({ public: 'eleves', page: null }), icon: 'cap', active: onglet === 'eleves' },
    ])}

    <!-- Familles de ressources -->
    <div class="type-cards">
      ${each(meta.familles, (f) => html`
        <a class="type-card" href="${lien({ famille: f.label, page: null })}">
          <span style="${raw(`color:${f.couleur}`)}">${icon(f.icon, { size: 30, stroke: 1.6 })}</span>
          <span class="type-card__label">${f.label}</span>
          <span class="type-card__count">${number(f.valeur)}</span>
        </a>`)}
    </div>

    <!-- Barre d'outils -->
    <form class="toolbar" method="get" action="/ressources-pedagogiques">
      ${when(onglet === 'eleves', () => html`<input type="hidden" name="public" value="eleves">`)}
      ${each(
        [
          { name: 'discipline', label: 'Discipline', options: meta.disciplines },
          { name: 'niveau', label: 'Niveau scolaire', options: meta.niveaux },
          { name: 'type', label: 'Type de ressource', options: meta.types },
          { name: 'format', label: 'Format', options: meta.formats },
        ],
        (f) => html`
          <label class="select">
            <select name="${f.name}" onchange="this.form.requestSubmit()">
              <option value="">${f.label}</option>
              ${each(f.options, (o) => html`
                <option value="${o}" ${raw(query[f.name] === o ? 'selected' : '')}>${o}</option>`)}
            </select>
            ${icon('chevronDown', { size: 15 })}
          </label>`
      )}
      <label class="select">
        <select name="tri" onchange="this.form.requestSubmit()">
          <option value="recentes">Tri : Plus récentes</option>
          <option value="vues" ${raw(query.tri === 'vues' ? 'selected' : '')}>Tri : Plus consultées</option>
          <option value="note" ${raw(query.tri === 'note' ? 'selected' : '')}>Tri : Mieux notées</option>
        </select>
        ${icon('chevronDown', { size: 15 })}
      </label>
      <button class="btn btn--ghost" type="submit">${icon('filter', { size: 17 })} Filtres</button>
      <span class="viewtoggle">
        <a href="${lien({ affichage: null })}" aria-current="${grille ? 'true' : 'false'}" aria-label="Affichage en grille">${icon('grid')}</a>
        <a href="${lien({ affichage: 'liste' })}" aria-current="${grille ? 'false' : 'true'}" aria-label="Affichage en liste">${icon('list')}</a>
      </span>
    </form>

    <p class="result-count">${number(trouvees.length === totalFonds ? meta.total : trouvees.length)} ressources trouvées</p>

    ${grille
      ? html`<div class="rgrid">${each(visibles, fiche)}</div>`
      : B.list({
          title: 'Ressources',
          count: trouvees.length,
          rows: visibles.map((r) => ({
            title: r.titre,
            description: `${r.type} • ${r.format}`,
            href: `/ressources-pedagogiques/${r.id}`,
            image: r.image,
            tags: [{ label: r.discipline, tone: 'blue' }, { label: r.niveau, tone: 'gray' }],
            facts: [{ label: 'Auteur', value: r.auteur }, { label: 'Note', value: `${r.note} (${r.avis})` }],
            actions: [
              { icon: 'bookmark', label: 'Enregistrer', href: `/mes-favoris/ajouter?ressource=${r.id}` },
              { icon: 'download', label: 'Télécharger', href: `/ressources-pedagogiques/${r.id}/fichier` },
            ],
            views: r.vues,
          })),
        })}

    ${when(visibles.length === 0, () => html`<div class="list">${B.empty({
      title: 'Aucune ressource pour ces filtres',
      text: 'Élargissez la recherche, ou déposez la première ressource de cette catégorie.',
      action: { label: 'Déposer une ressource', href: '/partage-de-ressources/nouveau' },
    })}</div>`)}

    ${when(pages > 1 && grille, () => B.pager({ page, pages, href: lien({ page: null }) }))}`;

  const rail = html`
    <!-- Filtres avancés -->
    ${B.railCard({
      title: 'Filtres avancés',
      link: { label: 'Réinitialiser', href: '/ressources-pedagogiques' },
      body: html`
        <form class="filter-form" method="get" action="/ressources-pedagogiques">
          ${each(
            [
              { name: 'discipline', label: 'Discipline', options: meta.disciplines },
              { name: 'niveau', label: 'Niveau scolaire', options: meta.niveaux },
              { name: 'type', label: 'Type de ressource', options: meta.types },
              { name: 'format', label: 'Format', options: meta.formats },
            ],
            (f) => html`
              <label class="field field--select">
                <span>${f.label}</span>
                <select name="${f.name}">
                  <option value="">Sélectionner</option>
                  ${each(f.options, (o) => html`
                    <option value="${o}" ${raw(query[f.name] === o ? 'selected' : '')}>${o}</option>`)}
                </select>
                ${icon('chevronDown', { size: 16 })}
              </label>`
          )}
          <label class="field">
            <span>Mots-clés</span>
            <input type="search" name="mots" value="${query.mots || ''}" placeholder="Ex : fractions, écosystème…">
          </label>
          <button class="btn btn--primary btn--block" type="submit">Appliquer les filtres</button>
        </form>`,
    })}

    <!-- Intégration par QR code -->
    ${B.railCard({
      title: 'Intégration facile',
      body: html`
        <div class="embed-card">
          <div>
            <p>Chaque ressource possède un lien et un QR code uniques, à partager ou à intégrer dans vos documents imprimés.</p>
            <a class="btn btn--primary btn--sm" href="/aide/qr-codes">En savoir plus ${icon('arrowRight', { size: 15 })}</a>
          </div>
          <div class="embed-card__art">
            <img src="/qr.svg?texte=${encodeURIComponent('https://diffusion.educa.ht/r/rp-001')}&taille=84" width="84" height="84" alt="Exemple de QR code de ressource">
            <span class="rail__hint">Exemple</span>
          </div>
        </div>`,
    })}

    <!-- Ressources populaires -->
    ${B.railCard({
      title: 'Ressources populaires',
      items: meta.populaires.map((p, i) => ({
        rank: i + 1, label: p.titre, hint: `${p.discipline} • ${p.niveau}`, views: p.vues, href: p.href,
      })),
      foot: html`<a href="/ressources-pedagogiques?tri=vues">Voir plus ${icon('arrowRight', { size: 15 })}</a>`,
    })}`;

  return {
    title: 'Ressources pédagogiques',
    active: '/ressources-pedagogiques',
    search: 'Rechercher une ressource, un thème, une discipline…',
    styles: ['resources'],
    topAction: { label: 'Créer', href: '/partage-de-ressources/nouveau', icon: 'plus' },
    main,
    rail,
  };
};

/* --- Fiche de ressource --------------------------------------------------- */
function fiche(r) {
  return html`
    <article class="rcard">
      <div class="rcard__frame">
        <img src="${r.image}" alt="" loading="lazy">
        <span class="rcard__type" style="${raw(`background:${r.typeTone}`)}">${r.type}</span>
        <button class="rcard__save" type="button" aria-pressed="false" aria-label="Enregistrer « ${r.titre} »">
          ${icon('bookmark', { size: 16 })}
        </button>
        <span class="rcard__format" style="${raw(`background:${r.formatTone}`)}">${r.format}</span>
        ${when(r.action, () => html`
          <a class="rcard__start" href="/ressources-pedagogiques/${r.id}/lancer">${r.action}</a>`)}
      </div>
      <div class="rcard__body">
        <h3 class="rcard__title"><a href="/ressources-pedagogiques/${r.id}">${r.titre}</a></h3>
        <p class="rcard__sub">${r.discipline} • ${r.niveau}</p>
      </div>
      <div class="rcard__meta">
        <span class="rcard__author">
          <img src="/img/avatar-enseignant.svg" alt="" width="22" height="22">${r.auteur}
        </span>
        <span class="push" style="display:flex;align-items:center;gap:4px">${icon('eye', { size: 14 })} ${compact(r.vues)}</span>
        <span style="display:flex;align-items:center;gap:4px">${icon('download', { size: 14 })} ${number(r.telechargements)}</span>
      </div>
      <div class="rcard__foot">
        ${etoiles(r.note)}
        <span>${String(r.note).replace('.', ',')} (${r.avis})</span>
        <button class="rcard__more" type="button" aria-label="Autres actions">${icon('list', { size: 16 })}</button>
      </div>
    </article>`;
}

/** Cinq étoiles, remplies selon la note arrondie au demi-point près. */
function etoiles(note) {
  const pleines = Math.round(note);
  return html`
    <span class="stars" role="img" aria-label="Note : ${String(note).replace('.', ',')} sur 5">
      ${each([1, 2, 3, 4, 5], (i) => html`
        <span class="${i <= pleines ? '' : 'is-empty'}">${icon('star', { size: 13, stroke: 1 })}</span>`)}
    </span>`;
}

/* ========================================================================= */
/* Élève                                                                     */
/* ========================================================================= */
async function vueEleve(ctx) {
  const { query } = ctx;
  const d = await store.read('ressources-eleves', ctx.identite, {});
  const niveau = query.niveau || ctx.user.niveau || 'Secondaire 2';
  const discipline = query.discipline || '';

  const recommandees = d.recommandees.filter((r) => !discipline || r.discipline === discipline);

  const lien = (modif) => {
    const params = new URLSearchParams(
      Object.entries({ ...query, ...modif }).filter(([, v]) => v)
    );
    const s = params.toString();
    return `/ressources-pedagogiques${s ? '?' + s : ''}`;
  };

  const enTete = (titre, href) => html`
    <div class="block-head">
      <h2>${titre}</h2>
      <a href="${href}">Voir tout ${icon('arrowRight', { size: 15 })}</a>
    </div>`;

  const main = html`
    <div class="page-head">
      <span class="page-head__mark">${icon('cap', { size: 26 })}</span>
      <div>
        <h1>Ressources pédagogiques – Pour les élèves</h1>
        <p>Explore, apprends et réussis avec des ressources adaptées à ton niveau.</p>
      </div>
    </div>

    <!-- Disciplines -->
    <div class="chips">
      ${each(d.disciplines, (c) => html`
        <a class="chip" href="${c.valeur === 'plus' ? '/par-disciplines' : lien({ discipline: c.valeur })}"
           aria-current="${(c.valeur || '') === discipline ? 'true' : 'false'}">
          <span style="${raw(`color:${c.couleur}`)}">${icon(c.icon, { size: 24, stroke: 1.7 })}</span>
          ${c.label}
        </a>`)}
    </div>

    <!-- Filtres -->
    <form class="toolbar" method="get" action="/ressources-pedagogiques">
      ${when(discipline, () => html`<input type="hidden" name="discipline" value="${discipline}">`)}
      <label class="select">
        <span class="muted">Niveau scolaire</span>
        <select name="niveau" onchange="this.form.requestSubmit()">
          ${each(['Secondaire 1', 'Secondaire 2', 'Secondaire 3', 'Secondaire 4'], (n) => html`
            <option value="${n}" ${raw(n === niveau ? 'selected' : '')}>${n}</option>`)}
        </select>
        ${icon('chevronDown', { size: 15 })}
      </label>
      <label class="select">
        <span class="muted">Type de ressource</span>
        <select name="type" onchange="this.form.requestSubmit()">
          <option value="">Tous</option>
          ${each(['Vidéo', 'Activité', 'Présentation', 'Quiz', 'Carte'], (t) => html`
            <option value="${t}" ${raw(query.type === t ? 'selected' : '')}>${t}</option>`)}
        </select>
        ${icon('chevronDown', { size: 15 })}
      </label>
      <label class="select">
        <span class="muted">Format</span>
        <select name="format" onchange="this.form.requestSubmit()">
          <option value="">Tous</option>
          ${each(['PDF', 'PPTX', 'Vidéo', 'HTML5'], (f) => html`
            <option value="${f}" ${raw(query.format === f ? 'selected' : '')}>${f}</option>`)}
        </select>
        ${icon('chevronDown', { size: 15 })}
      </label>
      <label class="select">
        <span class="muted">Tri</span>
        <select name="tri" onchange="this.form.requestSubmit()">
          <option value="recents">Plus récents</option>
          <option value="populaires" ${raw(query.tri === 'populaires' ? 'selected' : '')}>Plus consultés</option>
        </select>
        ${icon('chevronDown', { size: 15 })}
      </label>
      <button class="btn btn--ghost push" type="submit">${icon('filter', { size: 17 })} Filtres</button>
    </form>

    <!-- Recommandations -->
    <section>
      ${enTete('Ressources recommandées pour toi', '/nouveautes')}
      <div class="carousel">
        <div class="carousel__track" id="recommandees">
          ${each(recommandees, carteEleve)}
        </div>
        <button class="carousel__next" type="button" data-scroll="#recommandees" aria-label="Voir les ressources suivantes">
          ${icon('chevronRight', { size: 18 })}
        </button>
      </div>
      ${when(recommandees.length === 0, () => html`<div class="list">${B.empty({
        title: 'Aucune ressource pour cette discipline',
        text: 'Choisis une autre discipline, ou explore les nouveautés du mois.',
        action: { label: 'Voir les nouveautés', href: '/nouveautes' },
      })}</div>`)}
    </section>

    <!-- Parcours -->
    <section>
      ${enTete("Parcours d'apprentissage", '/parcours')}
      <div class="paths">
        ${each(d.parcours, (p) => html`
          <a class="path" href="${p.href}" style="${raw(`background:${p.fond}`)}">
            <span class="path__title" style="${raw(`color:${p.texte}`)}">${p.titre}</span>
            <span class="path__sub">${p.sous_titre}</span>
            <span class="path__count">${p.total} ressources</span>
            <span class="path__bar">
              <span class="meter"><span class="meter__fill" style="${raw(`width:${p.progres}%;background:${p.texte}`)}"></span></span>
              <span>${p.progres} %</span>
            </span>
          </a>`)}
      </div>
    </section>

    <!-- Nouveautés -->
    <section>
      ${enTete('Nouveautés', '/nouveautes')}
      <div class="news">
        ${each(d.nouveautes, (n) => html`
          <a class="news-card" href="${n.href}">
            <img src="${n.image}" alt="" loading="lazy">
            <span>
              <span class="news-card__type" style="${raw(`color:${n.typeTone}`)}">${n.type}</span>
              <span class="news-card__title">${n.titre}</span>
              <span class="news-card__sub">${n.discipline} • ${n.niveau}</span>
              <span class="tag tag--green" style="margin-top:6px">Nouveau</span>
            </span>
          </a>`)}
      </div>
    </section>`;

  const rail = html`
    <!-- Reprise -->
    ${B.railCard({
      title: 'Continue ton apprentissage',
      body: html`
        <div class="ring">
          ${anneau(d.encours.progres)}
          <div>
            <b>${d.encours.titre}</b>
            <span>${d.encours.discipline} • ${d.encours.niveau}</span>
            <a class="btn btn--green btn--sm" href="${d.encours.href}">Continuer</a>
          </div>
        </div>`,
    })}

    <!-- Populaires -->
    ${B.railCard({
      title: 'Ressources populaires',
      link: { label: 'Voir tout', href: '/ressources-pedagogiques?tri=populaires' },
      items: d.populaires.map((p, i) => ({
        rank: i + 1, label: p.titre, hint: `${p.discipline} • ${p.niveau}`, views: p.vues, href: p.href,
      })),
    })}

    <!-- Entraide -->
    <aside class="help-card">
      <h3>Besoin d'aide ?</h3>
      <p>Pose ta question à ton enseignant ou à la communauté.</p>
      <a class="btn btn--violet btn--sm" href="/forum/nouvelle-question">Poser une question</a>
      <span class="help-card__art">${icon('message', { size: 44, stroke: 1.4 })}</span>
    </aside>`;

  return {
    title: 'Ressources pédagogiques',
    active: '/ressources-pedagogiques',
    search: 'Rechercher une ressource, une leçon, une activité…',
    styles: ['resources'],
    topAction: { label: 'Espace de travail', href: '/mes-activites', icon: 'target' },
    main,
    rail: html`${railFavoris(d.favoris)}${rail}`,
  };
}

/** Carte de ressource, version élève : note et vues, sans auteur. */
function carteEleve(r) {
  return html`
    <article class="rcard">
      <div class="rcard__frame">
        <img src="${r.image}" alt="" loading="lazy">
        <span class="rcard__type" style="${raw(`background:${r.typeTone}`)}">${r.type}</span>
        <button class="rcard__save" type="button" aria-pressed="false" aria-label="Ajouter « ${r.titre} » à mes favoris">
          ${icon('bookmark', { size: 16 })}
        </button>
        ${when(r.format, () => html`
          <span class="rcard__format" style="${raw(`background:${r.formatTone}`)}">${r.format}</span>`)}
        ${when(r.duree, () => html`<span class="res-card__time">${r.duree}</span>`)}
      </div>
      <div class="rcard__body">
        <h3 class="rcard__title"><a href="/ressources-pedagogiques/${r.id}">${r.titre}</a></h3>
        <p class="rcard__sub">${r.discipline} • ${r.niveau}</p>
      </div>
      <div class="rcard__meta">
        <span style="display:flex;align-items:center;gap:5px">
          ${icon('eye', { size: 14 })} ${compact(r.vues)} ${r.uniteVues || 'vues'}
        </span>
        <span class="push" style="display:flex;align-items:center;gap:5px">
          <span class="stars">${icon('star', { size: 13, stroke: 1 })}</span>
          ${String(r.note).replace('.', ',')} (${r.avis})
        </span>
      </div>
    </article>`;
}

/** Carte des favoris : vignette, titre, discipline, retrait du favori. */
function railFavoris(favoris) {
  return html`
    <section class="card">
      <div class="card__head">
        <h3 style="display:flex;align-items:center;gap:8px;color:var(--blue-600)">
          ${icon('heart', { size: 18 })} Mes favoris
        </h3>
        <a class="card__link" href="/mes-favoris">Voir tout</a>
      </div>
      ${each(favoris, (f) => html`
        <div class="fav">
          <img src="${f.image}" alt="">
          <span>
            <b>${f.titre}</b>
            <span>${f.discipline} • ${f.niveau}</span>
          </span>
          <a href="/mes-favoris/retirer?ressource=${f.titre}" aria-label="Retirer « ${f.titre} » des favoris">
            ${icon('bookmark', { size: 17 })}
          </a>
        </div>`)}
      <div class="card__foot">
        <a class="btn btn--ghost btn--sm btn--block" href="/mes-favoris">Voir tous mes favoris</a>
      </div>
    </section>`;
}

/** Anneau de progression : cercle tracé par pourcentage. */
function anneau(pourcent) {
  const r = 26; const c = 2 * Math.PI * r;
  return raw(
    `<svg width="72" height="72" viewBox="0 0 72 72" role="img" aria-label="Progression : ${pourcent} %">` +
      `<circle cx="36" cy="36" r="${r}" fill="none" stroke="#e6eaf2" stroke-width="7"/>` +
      `<circle cx="36" cy="36" r="${r}" fill="none" stroke="#0e9f6e" stroke-width="7" stroke-linecap="round" ` +
      `stroke-dasharray="${c.toFixed(1)}" stroke-dashoffset="${(c * (1 - pourcent / 100)).toFixed(1)}" ` +
      `transform="rotate(-90 36 36)"/>` +
      `<text x="36" y="41" text-anchor="middle" class="ring__value">${pourcent} %</text></svg>`
  );
}
