'use strict';
/** Système de design — inventaire vivant des jetons et des composants. */
const { html, each, raw } = require('../lib/html');
const { icon, names } = require('../lib/icons');
const B = require('../components/blocks');

const COULEURS = [
  ['--blue-600', 'Bleu primaire — boutons, liens, état actif'],
  ['--blue-50', 'Bleu pâle — pilule active, fonds d’icônes'],
  ['--navy-900', 'Marine — bannières de l’espace enseignant'],
  ['--orange-500', 'Orange — « DIFFUSION », compteurs d’alerte'],
  ['--ink-900', 'Encre — titres'],
  ['--ink-500', 'Encre pâle — libellés et métadonnées'],
  ['--bg', 'Fond de page'],
  ['--border', 'Bord de carte'],
];
const TONS = ['blue', 'green', 'purple', 'orange', 'pink', 'teal', 'gray'];

module.exports = async function systeme() {
  const main = html`
    ${B.hero({
      tone: 'dark', mark: 'grid',
      title: 'Système de design',
      lede: 'Les jetons et les composants extraits des vingt maquettes. Chaque écran de la plateforme se compose à partir de cet inventaire.',
    })}

    <section class="card">
      <div class="card__head"><h3>Couleurs</h3></div>
      <div class="card__body">
        <div class="grid-2">
          ${each(COULEURS, ([token, role]) => html`
            <div class="cluster">
              <span style="${raw(`width:44px;height:44px;border-radius:var(--r-md);border:1px solid var(--border);background:var(${token})`)}"></span>
              <span>
                <code style="font-size:var(--fs-sm);font-weight:600;color:var(--ink-900)">${token}</code>
                <span class="rail__hint">${role}</span>
              </span>
            </div>`)}
        </div>
      </div>
    </section>

    <section class="card">
      <div class="card__head"><h3>Échelle typographique</h3></div>
      <div class="card__body stack">
        <p style="font-size:var(--fs-hero);font-weight:700;color:var(--ink-900);letter-spacing:-.02em">Titre de bannière — 32 px</p>
        <p style="font-size:var(--fs-xl);font-weight:700;color:var(--ink-900)">Titre de page — 22 px</p>
        <p style="font-size:var(--fs-2xl);font-weight:700;color:var(--ink-900)">1 248 — compteur, 28 px</p>
        <p style="font-size:var(--fs-md);font-weight:600;color:var(--ink-900)">Titre de carte — 16 px</p>
        <p>Texte courant de l’application — 14 px, la taille de lecture par défaut de toutes les listes.</p>
        <p class="muted" style="font-size:var(--fs-xs)">Métadonnée — 12 px</p>
        <p class="eyebrow">Libellé de section — 11 px</p>
      </div>
    </section>

    <section class="card">
      <div class="card__head"><h3>Boutons et pastilles</h3></div>
      <div class="card__body stack">
        <div class="cluster">
          <button class="btn btn--primary">${icon('plus', { size: 17 })} Créer un travail dirigé</button>
          <button class="btn btn--ghost">${icon('filter', { size: 17 })} Filtres</button>
          <button class="btn btn--ghost btn--sm">Plus récents</button>
          <span class="icon-btn">${icon('bookmark')}</span>
        </div>
        <div class="cluster">
          ${each(TONS, (t) => html`<span class="tag tag--${t}">${t}</span>`)}
        </div>
      </div>
    </section>

    ${B.stats([
      { label: 'Compteur, ton bleu', value: 132, icon: 'flask', tone: 'blue', delta: '+ 12 ce mois' },
      { label: 'Ton vert', value: 48, icon: 'checkCircle', tone: 'green' },
      { label: 'Ton violet', value: 36, icon: 'sparkle', tone: 'purple' },
      { label: 'Ton orange', value: '92 %', icon: 'chart', tone: 'orange' },
    ])}

    ${B.tabs([
      { label: 'Onglet actif', href: '/systeme', active: true },
      { label: 'Avec compteur', href: '/systeme', count: 18 },
      { label: 'Avec icône', href: '/systeme', icon: 'heart' },
    ])}

    ${B.filters({
      action: '/systeme',
      selects: [{ label: 'Niveau', name: 'niveau', value: 'tous', options: [{ label: 'Tous', value: 'tous' }] }],
      search: { placeholder: 'Barre de filtres complète…' },
    })}

    ${B.list({
      title: 'Ligne de liste',
      count: 2,
      rows: [
        { title: 'Ligne avec vignette, étiquettes, métadonnées et actions', description: 'Le patron dominant : il couvre les TD, TP, exposés, dissertations et examens.',
          icon: 'file', tone: 'blue', tags: [{ label: 'Étiquette', tone: 'blue' }, { label: 'Niveau', tone: 'gray' }],
          facts: [{ label: 'Durée', value: '45 min' }, { label: 'Type', value: 'Guide' }],
          actions: [{ icon: 'eye', label: 'Voir', href: '#' }, { icon: 'pencil', label: 'Modifier', href: '#' }], views: 1240 },
        { title: 'Ligne minimale', icon: 'book', tone: 'green' },
      ],
      pager: { page: 1, pages: 4, href: '/systeme' },
    })}

    <section class="card">
      <div class="card__head"><h3>Jeu d’icônes — ${names.length} tracés</h3></div>
      <div class="card__body">
        <div style="display:flex;flex-wrap:wrap;gap:14px">
          ${each(names, (n) => html`
            <span title="${n}" style="display:grid;place-items:center;width:40px;height:40px;border:1px solid var(--border);border-radius:var(--r-md);color:var(--ink-700)">
              ${icon(n, { size: 20 })}
            </span>`)}
        </div>
      </div>
    </section>`;

  const rail = html`
    ${B.railCard({
      title: 'Carte de rail',
      link: { label: 'Voir tout', href: '/systeme' },
      items: [
        { label: 'Élément avec icône', hint: 'Et une précision en dessous', icon: 'plus', tone: 'blue', href: '/systeme' },
        { rank: 1, label: 'Élément classé', hint: 'Avec compteur de vues', views: 3200, href: '/systeme' },
      ],
      foot: html`<a class="btn btn--ghost btn--sm btn--block" href="/systeme">Pied de carte</a>`,
    })}
    ${B.railCard({
      title: 'Règles',
      body: html`
        <ul class="checklist">
          ${each(['Un seul patron de page pour les listes.', 'Le rail droit reste secondaire, jamais indispensable.', 'Les couleurs de discipline viennent des jetons de ton.'],
            (r) => html`<li>${icon('check', { size: 16 })}<span>${r}</span></li>`)}
        </ul>`,
    })}
    ${B.note({ title: 'Encadré conseil', text: 'Fond ambré, réservé aux conseils pédagogiques et aux « bon à savoir ».', link: { label: 'En savoir plus', href: '/systeme' } })}
    ${B.note({ tone: 'info', iconName: 'sparkle', title: 'Encadré information', text: 'Fond bleu pâle, pour les rappels neutres.' })}`;

  return { title: 'Système de design', active: '/systeme', search: 'Rechercher un composant…', main, rail };
};
