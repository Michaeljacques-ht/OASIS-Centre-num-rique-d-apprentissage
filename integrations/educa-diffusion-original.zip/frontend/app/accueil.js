'use strict';
/**
 * Page d'accueil publique — mise en page en grandes cartes arrondies.
 * Tout le contenu vient de data/accueil.json.
 */
const { html, raw, each, when } = require('../lib/html');
const { icon } = require('../lib/icons');
const store = require('../services/api/diffusion');

module.exports = async function accueil(ctx = {}) {
  const c = await store.read('accueil', ctx.identite, {});
  const h = c.hero;
  const m = c.manifeste;

  const body = html`
    <div class="wrap">

      <!-- Bannière -->
      <section class="panel">
        <div class="banner">
          <div class="banner__left">
            <div class="banner__lockup">
              <span class="brand__word">
                <span class="brand__educa">EDUCA</span>
                <span class="brand__diffusion">DIFFUSION</span>
              </span>
              <span class="banner__rule"></span>
              <span class="banner__tagline">${h.tagline}</span>
            </div>

            <h1>${h.salutation}</h1>
            <p class="banner__claim">${h.claim}<em>${h.claim_accent}</em></p>
            <p class="banner__lede">${h.lede}</p>

            <div class="banner__cta">
              <a class="btn ${h.actions[0].variante}" href="${h.actions[0].href}">
                ${icon(h.actions[0].icon, { size: 19 })} ${h.actions[0].label}
              </a>
              <a class="play-link" href="${h.actions[1].href}">
                <span>${icon('play', { size: 18 })}</span> ${h.actions[1].label}
              </a>
            </div>
          </div>

          <div class="banner__right">
            <span class="banner__blue"></span>
            <img class="banner__photo" src="${h.image}" alt="${h.alt}" width="620" height="520">
            ${each(h.pastilles, (pin, i) => html`
              <span class="pin pin--${raw(['a', 'b', 'c'][i] || 'a')}">
                <span class="pin__icon" style="${raw(`background:${pin.couleur}`)}">${icon(pin.icon, { size: 17 })}</span>
                <span class="pin__text">
                  <b>${pin.titre}</b>
                  <span>${pin.detail}</span>
                  ${when(pin.progres, () => html`
                    <span class="meter"><span class="meter__fill" style="${raw(`width:${pin.progres}%;background:${pin.couleur}`)}"></span></span>`)}
                </span>
              </span>`)}
            <p class="banner__quote">
              ${h.citation}
              <b>${h.citation_auteur}</b>
            </p>
          </div>
        </div>

        <!-- Atouts -->
        <div class="perks">
          ${each(h.atouts, (a) => html`
            <div class="perk-item">
              <span class="perk-item__icon" style="${raw(`background:${a.fond};color:${a.couleur}`)}">${icon(a.icon, { size: 21 })}</span>
              <span class="perk-item__text">
                <b>${a.titre}</b>
                <span>${a.detail}</span>
              </span>
            </div>`)}
        </div>
      </section>

      <!-- Manifeste -->
      <section class="panel panel--plain panel--edged">
        <p class="eyebrow-pill">${m.eyebrow}</p>
        <h2 class="big-title">${m.titre}<em>${m.titre_accent}</em></h2>
        <p class="big-lede">${m.lede}</p>

        <div class="counters">
          ${each(m.compteurs, (k) => html`
            <div class="counter">
              <b>${k.valeur}</b>
              <span>${k.label}</span>
            </div>`)}
        </div>

        <div class="audiences">
          ${each(m.publics, (pub) => html`
            <a class="audience" href="${pub.href}">
              <span class="audience__title">
                <span style="${raw(`color:${pub.couleur}`)}">${icon(pub.icon, { size: 20 })}</span>
                ${pub.titre}
              </span>
              <p>${pub.texte}</p>
              <span class="audience__go">${pub.lien} ${icon('arrowRight', { size: 16 })}</span>
            </a>`)}
        </div>
      </section>

      <!-- Outils d'apprentissage -->
      <section class="panel panel--plain">
        <div class="split">
          <div>
            <div class="section__head"><h2>Outils d'apprentissage</h2></div>
            <div class="tiles-4">
              ${each(c.outils, (o) => html`
                <article class="tile">
                  <div class="tile__top">
                    <span class="tile__icon" style="${raw(`background:${o.couleur}`)}">${icon(o.icon, { size: 22 })}</span>
                    <h3 class="tile__title">${o.titre}</h3>
                  </div>
                  <p class="tile__text">${o.texte}</p>
                  <a class="tile__link" href="${o.href}">${o.lien} ${icon('arrowRight', { size: 15 })}</a>
                </article>`)}
            </div>
          </div>

          <div>
            <div class="formats">
              <h3>${c.formats.titre}</h3>
              <p>${c.formats.sous_titre}</p>
              <a class="format-row" href="${c.formats.numerique.href}">
                <span class="rail__icon" style="background:var(--t-blue-bg);color:var(--t-blue-fg)">${icon('phone', { size: 20 })}</span>
                <span>
                  <b>${c.formats.numerique.titre}</b>
                  <span>${c.formats.numerique.texte}</span>
                </span>
                <span class="rail__chevron">${icon('chevronRight', { size: 18 })}</span>
              </a>
            </div>

            <div class="qr-card">
              <span class="rail__icon" style="background:#fff;color:var(--blue-600);width:56px;height:56px">${icon('qr', { size: 28 })}</span>
              <div>
                <h3>${c.formats.qr.titre}</h3>
                <p>${c.formats.qr.texte}</p>
                <a class="btn btn--primary btn--sm" href="${c.formats.qr.href}">
                  ${icon('camera', { size: 17 })} ${c.formats.qr.action}
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Ressources -->
      <section class="panel panel--plain">
        <div class="section__head">
          <h2>Ressources</h2>
          <a href="/ressources">Voir toutes les ressources ${icon('arrowRight', { size: 15 })}</a>
        </div>
        <div class="tiles-5">
          ${each(c.ressources, (r) => html`
            <article class="tile">
              <div class="tile__top">
                <span class="tile__icon" style="${raw(`background:${r.couleur}`)}">${icon(r.icon, { size: 22 })}</span>
                <h3 class="tile__title">${r.titre}</h3>
              </div>
              <p class="tile__text">${r.texte}</p>
              <a class="tile__link" href="${r.href}">Voir plus ${icon('arrowRight', { size: 15 })}</a>
            </article>`)}
        </div>
      </section>

      <!-- Catégories -->
      <section class="panel panel--plain">
        <div class="section__head">
          <h2>Découvrir par catégorie</h2>
          <a href="/categories">Voir toutes les catégories ${icon('arrowRight', { size: 15 })}</a>
        </div>
        <div class="cats">
          ${each(c.categories, (cat) => html`
            <a class="cat" href="${cat.href}">
              <img class="cat__img" src="${cat.image}" alt="" width="400" height="300" loading="lazy">
              <span class="cat__body">
                <span class="cat__title" style="color:var(--ink-900);font-weight:700">${cat.titre}</span>
                <span class="cat__text">${cat.texte}</span>
                <span class="cat__link">Voir plus ${icon('arrowRight', { size: 15 })}</span>
              </span>
            </a>`)}
        </div>
      </section>

    </div>`;

  return {
    chrome: 'site',
    title: 'Diffuser le savoir autrement',
    description: 'EDUCA Diffusion : contenus et ressources pédagogiques numériques pour apprendre, enseigner et progresser chaque jour.',
    styles: ['home'],
    bodyClass: 'home',
    body,
  };
};
