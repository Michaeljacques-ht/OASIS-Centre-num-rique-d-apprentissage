'use strict';
/**
 * Écran encore à construire. Chaque entrée de navigation mène ici avec sa
 * bannière et son état vide : l'ossature est complète et navigable avant que
 * le module ne soit développé.
 */
const { html } = require('../lib/html');
const B = require('../components/blocks');

module.exports = async function chantier(ctx, module_) {
  const main = html`
    ${B.hero({
      tone: ctx.role === 'eleve' ? 'blue' : 'dark',
      mark: module_.icon,
      title: module_.label,
      lede: module_.lede || 'Ce module reprend le patron commun : bannière, compteurs, filtres, liste et rail droit.',
    })}
    <section class="list">
      ${B.empty({
        title: 'Module à construire',
        text: 'L’ossature, les jetons et les composants sont prêts. Il reste à brancher les données et les écrans de création.',
        action: { label: 'Voir le système de design', href: '/systeme' },
      })}
    </section>`;

  const rail = html`
    ${B.note({
      tone: 'info', iconName: 'layers',
      title: 'Patron disponible',
      text: 'Deux écrans de référence sont déjà câblés : Travaux dirigés côté enseignant, Ressources méthodologiques côté élève.',
      link: { label: 'Ouvrir Travaux dirigés', href: '/travaux-diriges' },
    })}`;

  return { title: module_.label, active: module_.href, main, rail };
};
