'use strict';
/**
 * Ressources méthodologiques.
 * — Enseignant : catalogue de méthodes, guides et stratégies d'enseignement.
 * — Élève : méthodes de travail et d'organisation, adaptées à son niveau.
 */
const { html, raw, each, when, number, compact } = require('../lib/html');
const { icon } = require('../lib/icons');
const B = require('../components/blocks');
const store = require('../services/api/diffusion');

module.exports = async function ressourcesMethodologiques(ctx) {
  return ctx.role === 'eleve' ? vueEleve(ctx) : vueEnseignant(ctx);
};

/* ========================================================================= */
/* Élève                                                                     */
/* ========================================================================= */
async function vueEleve(ctx) {
  const { query } = ctx;
  const d = await store.read('methodologiques-eleve', ctx.identite, {});
  const theme = query.theme || '';

  const trouvees = (d.ressources || []).filter((r) => {
    if (theme && r.theme !== theme) return false;
    if (query.niveau && query.niveau !== 'Tous niveaux' && r.niveau !== query.niveau) return false;
    if (query.type && r.type !== query.type) return false;
    if (query.duree === 'Moins de 10 min' && r.duree >= 10) return false;
    if (query.duree === '10 à 20 min' && (r.duree < 10 || r.duree > 20)) return false;
    if (query.duree === 'Plus de 20 min' && r.duree <= 20) return false;
    const mots = (query.mots || '').toLowerCase().trim();
    return !mots || `${r.titre} ${r.theme}`.toLowerCase().includes(mots);
  });

  const filtre = Boolean(theme || query.niveau || query.type || query.duree || query.mots);
  const grille = query.affichage !== 'liste';

  const lien = (modif) => {
    const params = new URLSearchParams(
      Object.entries({ ...query, ...modif }).filter(([, v]) => v)
    );
    const s = params.toString();
    return `/ressources-methodologiques${s ? '?' + s : ''}`;
  };

  const boite = (nom, libelle, options, defaut) => html`
    <label class="filter-box">
      <span>${libelle}</span>
      <span class="filter-box__control">
        <select name="${nom}" onchange="this.form.requestSubmit()">
          <option value="">${defaut}</option>
          ${each(options || [], (o) => html`
            <option value="${o}" ${raw(query[nom] === o ? 'selected' : '')}>${o}</option>`)}
        </select>
        ${icon('chevronDown', { size: 16 })}
      </span>
    </label>`;

  const main = html`
    <div class="page-head">
      <span class="page-head__mark">${icon('cap', { size: 26 })}</span>
      <div>
        <h1>Ressources méthodologiques – Pour les élèves</h1>
        <p>Apprends à mieux travailler : prendre des notes, t'organiser, mémoriser et aborder tes évaluations sereinement.</p>
      </div>
      <div class="page-head__aside">
        <a class="btn btn--ghost" href="/aide/methodologie">
          ${icon('play', { size: 18 })} Comment ça marche ?
        </a>
      </div>
    </div>

    <!-- Thèmes -->
    <section>
      <div class="block-head"><h2>Choisir un thème</h2></div>
      <div class="chips">
        ${each(d.themes, (t) => html`
          <a class="chip" href="${t.valeur === 'plus' ? '/par-competences' : lien({ theme: t.valeur })}"
             aria-current="${(t.valeur || '') === theme ? 'true' : 'false'}">
            <span style="${raw(`color:${t.couleur}`)}">${icon(t.icon, { size: 26, stroke: 1.7 })}</span>
            ${t.label}
          </a>`)}
      </div>
    </section>

    <!-- Filtres -->
    <form method="get" action="/ressources-methodologiques">
      ${when(theme, () => html`<input type="hidden" name="theme" value="${theme}">`)}
      <div class="filter-boxes">
        ${boite('niveau', 'Niveau scolaire', d.niveaux, 'Tous niveaux')}
        ${boite('type', 'Type de ressource', d.types, 'Tous')}
        ${boite('duree', 'Durée', d.durees, 'Toutes')}
        ${boite('format', 'Format', d.formats, 'Tous les formats')}
        <button class="btn btn--tint" type="submit" style="height:52px">
          ${icon('filter', { size: 17 })} Filtres
        </button>
      </div>
    </form>

    <!-- Résultats -->
    <div class="result-row">
      <p class="result-count">${number(filtre ? trouvees.length : d.total)} méthodes à explorer</p>
      <form class="cluster push" method="get" action="/ressources-methodologiques">
        <span class="muted">Trier par :</span>
        <label class="select">
          <select name="tri" onchange="this.form.requestSubmit()">
            <option value="recentes">Plus récentes</option>
            <option value="vues" ${raw(query.tri === 'vues' ? 'selected' : '')}>Plus consultées</option>
            <option value="courtes" ${raw(query.tri === 'courtes' ? 'selected' : '')}>Les plus courtes</option>
          </select>
          ${icon('chevronDown', { size: 15 })}
        </label>
      </form>
      <span class="viewtoggle" style="margin-left:0">
        <a href="${lien({ affichage: null })}" aria-current="${grille ? 'true' : 'false'}" aria-label="Affichage en grille">${icon('grid')}</a>
        <a href="${lien({ affichage: 'liste' })}" aria-current="${grille ? 'false' : 'true'}" aria-label="Affichage en liste">${icon('list')}</a>
      </span>
    </div>

    ${grille
      ? html`<div class="rgrid">${each(trouvees, carteMethodeEleve)}</div>`
      : B.list({
          title: 'Méthodes de travail',
          count: trouvees.length,
          rows: trouvees.map((r) => ({
            title: r.titre,
            description: `${r.type} • ${r.duree} min`,
            href: `/ressources-methodologiques/${r.id}`,
            image: r.image,
            tags: [{ label: r.theme, tone: 'blue' }, { label: r.niveau, tone: 'gray' }],
            actions: [{ icon: 'bookmark', label: 'Ajouter à mes favoris', href: `/mes-favoris/ajouter?ressource=${r.id}` }],
            views: r.vues,
          })),
        })}

    ${when(trouvees.length === 0, () => html`<div class="list">${B.empty({
      title: 'Aucune méthode ne correspond à ces filtres',
      text: 'Essaie un autre thème, ou repars de toutes les méthodes.',
      action: { label: 'Voir toutes les méthodes', href: '/ressources-methodologiques' },
    })}</div>`)}`;

  const rail = html`
    <!-- Progression -->
    ${B.railCard({
      title: 'Ma progression',
      body: html`
        <div class="ring">
          ${anneauMethodo(d.progression.pourcent)}
          <div>
            <b>${d.progression.faites} méthodes sur ${d.progression.total}</b>
            <span>Continue : tu y es presque à la moitié.</span>
            <a class="btn btn--green btn--sm" href="/mes-activites">Reprendre</a>
          </div>
        </div>`,
    })}

    <!-- Outils pratiques -->
    ${B.railCard({
      title: 'Outils pratiques',
      items: d.outils,
    })}

    <!-- Méthodes populaires -->
    ${B.railCard({
      title: 'Méthodes populaires',
      link: { label: 'Voir tout', href: '/ressources-methodologiques?tri=vues' },
      items: (d.populaires || []).map((p, i) => ({
        rank: i + 1, label: p.titre, views: p.vues, href: p.href,
      })),
    })}

    ${B.note({ tone: 'info', iconName: 'bulb', title: 'Conseil du jour', text: d.conseil })}`;

  return {
    title: 'Ressources méthodologiques',
    active: '/ressources-methodologiques',
    search: 'Rechercher une méthode, une technique, un conseil…',
    styles: ['resources'],
    topAction: { label: 'Espace de travail', href: '/mes-activites', icon: 'target' },
    main,
    rail,
  };
}

/** Fiche de méthode, version élève : durée de lecture plutôt que téléchargements. */
function carteMethodeEleve(r) {
  return html`
    <article class="rcard">
      <div class="rcard__frame">
        <img src="${r.image}" alt="" loading="lazy">
        <span class="rcard__type" style="${raw(`background:${r.typeTone}`)}">${r.type}</span>
        <button class="rcard__save" type="button" aria-pressed="false"
                aria-label="Ajouter « ${r.titre} » à mes favoris">${icon('bookmark', { size: 16 })}</button>
      </div>
      <div class="rcard__body">
        <h3 class="rcard__title"><a href="/ressources-methodologiques/${r.id}">${r.titre}</a></h3>
        <p class="rcard__sub">${r.theme} • ${r.niveau}</p>
      </div>
      <div class="rcard__meta">
        <span style="display:flex;align-items:center;gap:5px">${icon('clock', { size: 14 })} ${r.duree} min</span>
        <span class="push" style="display:flex;align-items:center;gap:5px">${icon('eye', { size: 14 })} ${compact(r.vues)}</span>
      </div>
    </article>`;
}

/** Anneau de progression, teinte de l'espace élève. */
function anneauMethodo(pourcent) {
  const r = 26; const c = 2 * Math.PI * r;
  return raw(
    `<svg width="72" height="72" viewBox="0 0 72 72" role="img" aria-label="Progression : ${pourcent} %">` +
      `<circle cx="36" cy="36" r="${r}" fill="none" stroke="#e6eaf2" stroke-width="7"/>` +
      `<circle cx="36" cy="36" r="${r}" fill="none" stroke="#0e9f6e" stroke-width="7" stroke-linecap="round" ` +
      `stroke-dasharray="${c.toFixed(1)}" stroke-dashoffset="${(c * (1 - pourcent / 100)).toFixed(1)}" ` +
      `transform="rotate(-90 36 36)"/>` +
      `<text x="36" y="41" text-anchor="middle" class="ring__value">${pourcent} %</text></svg>`
  );
}

/* ========================================================================= */
/* Enseignant                                                                */
/* ========================================================================= */
async function vueEnseignant(ctx) {
  const { query } = ctx;
  const d = await store.read('methodologiques-enseignant', ctx.identite, {});
  const discipline = query.discipline || '';

  const trouvees = (d.ressources || []).filter((r) => {
    if (discipline && r.discipline !== discipline) return false;
    if (query.niveau && query.niveau !== 'Tous les niveaux' && r.niveau !== query.niveau) return false;
    if (query.type && r.type !== query.type) return false;
    if (query.approche && r.approche !== query.approche) return false;
    const mots = (query.mots || '').toLowerCase().trim();
    return !mots || `${r.titre} ${r.approche} ${r.discipline}`.toLowerCase().includes(mots);
  });

  const filtre = Boolean(discipline || query.niveau || query.type || query.approche || query.mots);
  const grille = query.affichage !== 'liste';

  const lien = (modif) => {
    const params = new URLSearchParams(
      Object.entries({ ...query, ...modif }).filter(([, v]) => v)
    );
    const s = params.toString();
    return `/ressources-methodologiques${s ? '?' + s : ''}`;
  };

  const boite = (nom, libelle, options, defaut) => html`
    <label class="filter-box">
      <span>${libelle}</span>
      <span class="filter-box__control">
        <select name="${nom}" onchange="this.form.requestSubmit()">
          <option value="">${defaut}</option>
          ${each(options || [], (o) => html`
            <option value="${o}" ${raw(query[nom] === o ? 'selected' : '')}>${o}</option>`)}
        </select>
        ${icon('chevronDown', { size: 16 })}
      </span>
    </label>`;

  const main = html`
    <div class="page-head">
      <span class="page-head__mark">${icon('cap', { size: 26 })}</span>
      <div>
        <h1>Ressources méthodologiques – Enseignant</h1>
        <p>Des méthodes, guides et stratégies d'enseignement pour améliorer vos pratiques pédagogiques et accompagner efficacement vos élèves.</p>
      </div>
      <div class="page-head__aside">
        <a class="btn btn--ghost" href="/aide/ressources-methodologiques">
          ${icon('help', { size: 18 })} Guide d'utilisation
        </a>
      </div>
    </div>

    <!-- Disciplines -->
    <section>
      <div class="block-head"><h2>Choisir une discipline</h2></div>
      <div class="chips">
        ${each(d.disciplines, (c) => html`
          <a class="chip" href="${c.valeur === 'plus' ? '/par-disciplines' : lien({ discipline: c.valeur })}"
             aria-current="${(c.valeur || '') === discipline ? 'true' : 'false'}">
            <span style="${raw(`color:${c.couleur}`)}">${icon(c.icon, { size: 26, stroke: 1.7 })}</span>
            ${c.label}
          </a>`)}
      </div>
    </section>

    <!-- Filtres -->
    <form method="get" action="/ressources-methodologiques">
      ${when(discipline, () => html`<input type="hidden" name="discipline" value="${discipline}">`)}
      <div class="filter-boxes">
        ${boite('niveau', 'Niveau scolaire', d.niveaux, 'Tous les niveaux')}
        ${boite('type', 'Type de ressource', d.types, 'Toutes')}
        ${boite('approche', 'Approche pédagogique', d.approches, 'Toutes')}
        ${boite('format', 'Format', d.formats, 'Tous les formats')}
        <button class="btn btn--tint" type="submit" style="height:52px">
          ${icon('filter', { size: 17 })} Filtres avancés
        </button>
      </div>
    </form>

    <!-- Résultats -->
    <div class="result-row">
      <p class="result-count">
        ${number(filtre ? trouvees.length : d.total)} ressources méthodologiques trouvées
      </p>
      <form class="cluster push" method="get" action="/ressources-methodologiques">
        <span class="muted">Trier par :</span>
        <label class="select">
          <select name="tri" onchange="this.form.requestSubmit()">
            <option value="recentes">Plus récentes</option>
            <option value="vues" ${raw(query.tri === 'vues' ? 'selected' : '')}>Plus consultées</option>
            <option value="telechargements" ${raw(query.tri === 'telechargements' ? 'selected' : '')}>Plus téléchargées</option>
          </select>
          ${icon('chevronDown', { size: 15 })}
        </label>
      </form>
      <span class="viewtoggle" style="margin-left:0">
        <a href="${lien({ affichage: null })}" aria-current="${grille ? 'true' : 'false'}" aria-label="Affichage en grille">${icon('grid')}</a>
        <a href="${lien({ affichage: 'liste' })}" aria-current="${grille ? 'false' : 'true'}" aria-label="Affichage en liste">${icon('list')}</a>
      </span>
    </div>

    ${grille
      ? html`<div class="rgrid">${each(trouvees, carteMethode)}</div>`
      : B.list({
          title: 'Ressources méthodologiques',
          count: trouvees.length,
          rows: trouvees.map((r) => ({
            title: r.titre,
            description: `${r.type} • ${r.approche}`,
            href: `/ressources-methodologiques/${r.id}`,
            image: r.image,
            tags: [{ label: r.discipline, tone: 'blue' }, { label: r.niveau, tone: 'gray' }],
            facts: [{ label: 'Téléchargements', value: number(r.telechargements) }],
            actions: [{ icon: 'bookmark', label: 'Enregistrer', href: `/mes-favoris/ajouter?ressource=${r.id}` }],
            views: r.vues,
          })),
        })}

    ${when(trouvees.length === 0, () => html`<div class="list">${B.empty({
      title: 'Aucune méthode ne correspond à ces filtres',
      text: 'Élargissez la recherche, ou proposez la vôtre à la communauté enseignante.',
      action: { label: 'Déposer une ressource', href: '/partage-de-ressources/nouveau' },
    })}</div>`)}`;

  const rail = html`
    ${B.railCard({
      title: 'Filtres avancés',
      link: { label: 'Réinitialiser', href: '/ressources-methodologiques' },
      body: html`
        <form class="filter-form" method="get" action="/ressources-methodologiques">
          ${each(
            [
              { name: 'niveau', label: 'Niveau scolaire', options: d.niveaux },
              { name: 'approche', label: 'Approche pédagogique', options: d.approches },
              { name: 'competence', label: 'Compétence visée', options: d.competences },
              { name: 'duree', label: "Durée d'application", options: d.durees },
            ],
            (f) => html`
              <label class="field field--select">
                <span>${f.label}</span>
                <select name="${f.name}">
                  <option value="">Sélectionner</option>
                  ${each(f.options || [], (o) => html`
                    <option value="${o}" ${raw(query[f.name] === o ? 'selected' : '')}>${o}</option>`)}
                </select>
                ${icon('chevronDown', { size: 16 })}
              </label>`
          )}
          <label class="field">
            <span>Mots-clés</span>
            <input type="search" name="mots" value="${query.mots || ''}" placeholder="Ex : différenciation, motivation…">
          </label>
          <button class="btn btn--primary btn--block" type="submit">Appliquer les filtres</button>
        </form>`,
    })}

    ${B.railCard({
      title: 'Ressources méthodologiques populaires',
      link: { label: 'Voir tout', href: '/ressources-methodologiques?tri=vues' },
      items: (d.populaires || []).map((p, i) => ({
        rank: i + 1, label: p.titre, views: p.vues, href: p.href,
      })),
    })}

    <aside class="help-card help-card--blue">
      <h3>Besoin d'aide ?</h3>
      <p>Consultez notre guide méthodologique ou contactez un expert.</p>
      <a class="btn btn--ghost btn--sm" href="/aide/methodologie">Obtenir de l'aide</a>
      <span class="help-card__art">${icon('headphones', { size: 44, stroke: 1.4 })}</span>
    </aside>`;

  return {
    title: 'Ressources méthodologiques',
    active: '/ressources-methodologiques',
    search: 'Rechercher une méthode, une discipline, une technique…',
    styles: ['resources'],
    topAction: { label: 'Créer', href: '/partage-de-ressources/nouveau', icon: 'plus' },
    main,
    rail,
  };
}

/** Fiche méthodologique : illustration, étiquette de type, vues et téléchargements. */
function carteMethode(r) {
  return html`
    <article class="rcard">
      <div class="rcard__frame">
        <img src="${r.image}" alt="" loading="lazy">
        <span class="rcard__type" style="${raw(`background:${r.typeTone}`)}">${r.type}</span>
      </div>
      <div class="rcard__body">
        <h3 class="rcard__title"><a href="/ressources-methodologiques/${r.id}">${r.titre}</a></h3>
        <p class="rcard__sub">${r.discipline} • ${r.niveau}</p>
      </div>
      <div class="rcard__meta">
        <span style="display:flex;align-items:center;gap:5px">${icon('eye', { size: 14 })} ${compact(r.vues)}</span>
        <span style="display:flex;align-items:center;gap:5px">${icon('download', { size: 14 })} ${compact(r.telechargements)}</span>
        <button class="rcard__more push" type="button" aria-pressed="false"
                aria-label="Enregistrer « ${r.titre} »">${icon('bookmark', { size: 17 })}</button>
      </div>
    </article>`;
}
