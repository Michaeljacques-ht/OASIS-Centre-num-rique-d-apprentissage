'use strict';
/** Travaux dirigés — espace enseignant (maquette : bannière sombre + liste). */
const { html, each, when, number } = require('../lib/html');
const { icon } = require('../lib/icons');
const B = require('../components/blocks');
const store = require('../services/api/diffusion');

const PAR_PAGE = 5;

const DISCIPLINES = [
  { label: 'Mathématiques', value: 124, icon: 'sigma', tone: 'purple' },
  { label: 'Sciences physiques', value: 98, icon: 'atom', tone: 'blue' },
  { label: 'Sciences de la vie', value: 76, icon: 'leaf', tone: 'green' },
  { label: 'Français', value: 89, icon: 'book', tone: 'orange' },
  { label: 'Histoire-Géo', value: 67, icon: 'globe', tone: 'teal' },
  { label: 'Anglais', value: 54, icon: 'message', tone: 'pink' },
];

module.exports = async function travauxDiriges(ctx) {
  const { query } = ctx;
  const tous = (await store.query('travaux-diriges', {
    niveau: query.niveau,
    discipline: query.discipline,
    difficulte: query.difficulte,
  }, ctx.identite)).filter((td) =>
    !query.q || td.titre.toLowerCase().includes(String(query.q).toLowerCase())
  );

  const populaires = (await store.read('travaux-diriges', ctx.identite, {})).slice(0, 5);
  const page = Math.max(1, parseInt(query.page, 10) || 1);
  const pages = Math.max(1, Math.ceil(tous.length / PAR_PAGE));
  const visibles = tous.slice((page - 1) * PAR_PAGE, page * PAR_PAGE);

  const main = html`
    ${B.hero({
      tone: 'dark', mark: 'file',
      title: 'Travaux dirigés',
      lede: 'Concevez des travaux dirigés structurés pour guider vos élèves, développer leurs compétences et suivre leur progression.',
      actions: [{ label: "Guide d'utilisation", href: '/aide/travaux-diriges', icon: 'help', variant: 'btn--onDark' }],
    })}

    ${B.tabs([
      { label: 'Tous les TD', href: '/travaux-diriges', active: true },
      { label: 'Par discipline', href: '/travaux-diriges?vue=discipline', icon: 'list' },
      { label: 'Par niveau', href: '/travaux-diriges?vue=niveau', icon: 'layers' },
      { label: 'Mes TD', href: '/travaux-diriges?vue=mes-td', icon: 'users' },
      { label: 'Partagés avec moi', href: '/travaux-diriges?vue=partages', icon: 'share' },
      { label: 'Favoris', href: '/travaux-diriges?vue=favoris', icon: 'heart' },
    ])}

    ${B.stats(DISCIPLINES.map((d) => ({ ...d, label: `${d.label} — TD publiés` })))}

    ${B.filters({
      action: '/travaux-diriges',
      selects: [
        { label: 'Niveau scolaire', name: 'niveau', value: query.niveau || 'tous', options: [
          { label: 'Tous', value: 'tous' },
          { label: 'Secondaire 2', value: 'Secondaire 2' },
          { label: 'Secondaire 3', value: 'Secondaire 3' },
          { label: 'Secondaire 4', value: 'Secondaire 4' },
        ]},
        { label: 'Discipline', name: 'discipline', value: query.discipline || 'toutes', options: [
          { label: 'Toutes', value: 'toutes' },
          ...DISCIPLINES.map((d) => ({ label: d.label, value: d.label })),
        ]},
        { label: 'Difficulté', name: 'difficulte', value: query.difficulte || 'toutes', options: [
          { label: 'Toutes', value: 'toutes' },
          { label: 'Facile', value: 'Facile' },
          { label: 'Moyenne', value: 'Moyenne' },
          { label: 'Difficile', value: 'Difficile' },
        ]},
      ],
      search: { value: query.q, placeholder: 'Rechercher dans mes TD…' },
    })}

    ${B.list({
      title: 'Travaux dirigés',
      count: tous.length,
      tools: html`
        <a class="btn btn--ghost btn--sm" href="/travaux-diriges?tri=recents">${icon('clock', { size: 16 })} Plus récents</a>
        <a class="icon-btn" href="/travaux-diriges?affichage=grille" aria-label="Affichage en grille">${icon('grid')}</a>
        <a class="icon-btn" href="/travaux-diriges" aria-label="Affichage en liste">${icon('list')}</a>`,
      rows: visibles.map((td) => ({
        title: td.titre,
        href: `/travaux-diriges/${td.id}`,
        icon: td.icon, tone: td.tone,
        tags: [
          { label: td.discipline, tone: td.tone },
          { label: td.niveau, tone: 'blue' },
          { label: td.chapitre, tone: 'gray' },
        ],
        facts: [
          { value: `${td.exercices} exercices` },
          { value: `Difficulté : ${td.difficulte}` },
          { value: `${td.duree} min` },
          { value: `Modifié le ${fr(td.modifie)}` },
        ],
        actions: [
          { icon: 'eye', label: 'Prévisualiser', href: `/travaux-diriges/${td.id}` },
          { icon: 'pencil', label: 'Modifier', href: `/travaux-diriges/${td.id}/modifier` },
          { icon: 'copy', label: 'Dupliquer', href: `/travaux-diriges/${td.id}/dupliquer` },
          { icon: 'share', label: 'Partager', href: `/travaux-diriges/${td.id}/partager` },
        ],
      })),
      pager: pages > 1 ? { page, pages, href: `/travaux-diriges${queryString(query)}` } : null,
    })}`;

  const rail = html`
    ${B.railCard({
      title: 'Mes statistiques', link: { label: 'Voir le rapport', href: '/rapports/travaux-diriges' },
      body: html`
        <div class="grid-2">
          ${each([
            { value: 428, label: 'TD créés' },
            { value: 76, label: 'TD partagés' },
            { value: 1248, label: 'Utilisations' },
            { value: '92 %', label: "Taux d'engagement" },
          ], (s) => html`
            <div>
              <span class="stat__value" style="font-size:var(--fs-lg)">${typeof s.value === 'number' ? number(s.value) : s.value}</span>
              <span class="stat__label">${s.label}</span>
            </div>`)}
        </div>`,
    })}

    ${B.railCard({
      title: 'Actions rapides',
      items: [
        { label: 'Créer un nouveau TD', hint: 'Partir d’une page blanche', icon: 'plus', tone: 'blue', href: '/travaux-diriges/nouveau' },
        { label: 'Importer un TD', hint: 'Depuis Word, PDF ou Excel', icon: 'upload', tone: 'green', href: '/travaux-diriges/importer' },
        { label: 'Dupliquer un TD existant', hint: 'Repartir d’un modèle', icon: 'copy', tone: 'purple', href: '/travaux-diriges?vue=mes-td' },
        { label: 'Partager une collection', hint: 'Plusieurs TD à la fois', icon: 'share', tone: 'orange', href: '/collections/nouvelle' },
      ],
    })}

    ${B.railCard({
      title: 'TD populaires', link: { label: 'Voir tout', href: '/travaux-diriges?tri=populaires' },
      items: populaires.map((td, i) => ({
        rank: i + 1, label: td.titre.replace(/^TD : /, ''), hint: td.discipline, views: td.vues,
        href: `/travaux-diriges/${td.id}`,
      })),
    })}

    ${B.note({
      title: 'Conseil pédagogique',
      text: 'Variez les types d’exercices et proposez des situations-problèmes : les élèves développent leur autonomie quand la consigne les oblige à choisir une démarche.',
      link: { label: 'En savoir plus', href: '/aide/pedagogie' },
    })}`;

  return { title: 'Travaux dirigés', active: '/travaux-diriges', search: 'Rechercher un travail dirigé, une matière, un thème…', main, rail };
};

function fr(iso) {
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}
function queryString(query) {
  const parts = Object.entries(query).filter(([k]) => k !== 'page');
  return parts.length ? '?' + parts.map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&') : '';
}
