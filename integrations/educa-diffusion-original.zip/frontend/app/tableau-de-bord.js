'use strict';
/**
 * Tableau de bord.
 * — Enseignant : bibliothèque, ressources récentes, disciplines, partage QR.
 * — Élève : journée en cours, à faire, raccourcis.
 */
const { html, raw, each, when, number, compact } = require('../lib/html');
const { icon } = require('../lib/icons');
const B = require('../components/blocks');
const store = require('../services/api/diffusion');

module.exports = async function tableauDeBord(ctx) {
  return ctx.role === 'eleve' ? vueEleve(ctx) : vueEnseignant(ctx);
};

/* ========================================================================= */
/* Enseignant                                                                */
/* ========================================================================= */
async function vueEnseignant(ctx) {
  const d = await store.read('tableau-de-bord', ctx.identite, {});
  const jour = d.ressourceDuJour;
  const qrSrc = `/qr.svg?texte=${encodeURIComponent(jour.lien)}&taille=190&logo=1`;

  const titreBloc = (titre, lien) => html`
    <div class="block-head">
      <h2>${titre}</h2>
      ${when(lien, () => html`<a href="${lien.href}">${lien.label} ${icon('arrowRight', { size: 15 })}</a>`)}
    </div>`;

  const main = html`
    <!-- Bandeau d'accueil -->
    <section class="welcome">
      <div>
        <h1>${d.accueil.titre}</h1>
        <p>${d.accueil.lede}</p>
        <form class="welcome__search" action="/recherche" method="get" role="search">
          <label class="sr-only" for="recherche-accueil">Rechercher une ressource</label>
          <input id="recherche-accueil" name="q" type="search" placeholder="${d.accueil.placeholder}">
          <button type="submit">Rechercher</button>
        </form>
      </div>
      <img class="welcome__art" src="${d.accueil.image}" alt="" width="460" height="280">
    </section>

    <!-- Familles de contenus -->
    <div class="quick-cards">
      ${each(d.familles, (f) => html`
        <a class="quick-card" href="${f.href}" style="${raw(`background:var(--t-${f.tone}-bg)`)}">
          <span class="quick-card__icon" style="${raw(`color:var(--t-${f.tone}-fg)`)}">${icon(f.icon, { size: 21 })}</span>
          <span class="quick-card__label">${f.label}</span>
          <span class="quick-card__value">${number(f.valeur)}</span>
        </a>`)}
    </div>

    <!-- Ressources récentes -->
    <section>
      ${titreBloc('Ressources récentes', { label: 'Voir tout', href: '/ressources-pedagogiques' })}
      <div class="res-grid">
        ${each(d.recentes, (r) => html`
          <a class="res-card" href="/ressources-pedagogiques/${r.id}">
            <span class="res-card__frame">
              <img src="${r.image}" alt="" loading="lazy">
              <span class="res-card__badge" style="${raw(`background:${r.couleur}`)}">${r.type}</span>
              ${when(r.duree, () => html`
                <span class="res-card__play">${icon('play', { size: 22 })}</span>
                <span class="res-card__time">${r.duree}</span>`)}
            </span>
            <span class="res-card__body">
              <span class="res-card__title">${r.titre}</span>
              <span class="res-card__sub">${r.discipline} • ${r.niveau}</span>
            </span>
            <span class="res-card__foot">
              <span class="res-card__author">
                <img src="/img/avatar-enseignant.svg" alt="" width="22" height="22">
                ${r.auteur}
              </span>
              <span class="push res-card__stat">${icon('eye', { size: 14 })} ${compact(r.vues)}</span>
              <span class="res-card__stat">${icon('download', { size: 14 })} ${number(r.telechargements)}</span>
            </span>
          </a>`)}
      </div>
    </section>

    <!-- Disciplines populaires -->
    <section>
      ${titreBloc('Disciplines populaires')}
      <div class="disc-row">
        <div class="disc-scroll" id="disciplines">
          ${each(d.disciplines, (disc) => html`
            <a class="disc" href="${disc.href}">
              <span class="rail__icon" style="${raw(`background:var(--t-${disc.tone}-bg);color:var(--t-${disc.tone}-fg)`)}">
                ${icon(disc.icon, { size: 20 })}
              </span>
              <b>${disc.nom}</b>
              <span>${number(disc.total)} ressources</span>
            </a>`)}
        </div>
        <button class="disc-next" type="button" data-scroll="#disciplines" aria-label="Faire défiler les disciplines">
          ${icon('chevronRight', { size: 18 })}
        </button>
      </div>
    </section>`;

  const rail = html`
    <!-- Ressource du jour -->
    ${B.railCard({
      title: 'Ma ressource du jour',
      body: html`
        <span class="day-card__frame">
          <img src="${jour.image}" alt="">
          <span class="res-card__badge" style="${raw(`background:${jour.couleur}`)}">${jour.type}</span>
        </span>
        <h4 style="margin-top:12px;font-size:var(--fs-md)">${jour.titre}</h4>
        <p class="rail__hint">${jour.discipline} • ${jour.niveau}</p>
        <div class="day-card__meta">
          <span>${icon('eye', { size: 15 })} ${compact(jour.vues)} vues</span>
          <span>${icon('download', { size: 15 })} ${number(jour.telechargements)} téléchargements</span>
        </div>
        <a class="btn btn--primary btn--block" style="margin-top:16px" href="${jour.href}">Voir la ressource</a>`,
    })}

    <!-- Partage -->
    ${B.railCard({
      title: 'Partager cette ressource',
      body: html`
        <p class="eyebrow" style="color:var(--ink-500)">Lien de partage</p>
        <div class="copy-field" style="margin-top:8px">
          <input value="${jour.lien}" readonly aria-label="Lien de partage">
          <button type="button" data-copy="${jour.lien}" aria-label="Copier le lien">${icon('copy', { size: 17 })}</button>
        </div>

        <p class="eyebrow" style="color:var(--ink-500);margin-top:18px">QR Code</p>
        <div class="qr-block">
          <img src="${qrSrc}" width="190" height="190" alt="QR code de la ressource ${jour.titre}">
          <a class="btn btn--primary btn--sm" href="${qrSrc}&telecharger=1" download="qr-${jour.id}.svg">
            ${icon('download', { size: 16 })} Télécharger le QR Code
          </a>
        </div>

        <p class="eyebrow" style="color:var(--ink-500);margin-top:18px">Partager sur</p>
        <div class="share-row">
          ${each(d.reseaux, (r) => html`
            <a class="share-btn" style="${raw(`background:${r.couleur}`)}"
               href="${r.url === '#copier' ? '#' : r.url + encodeURIComponent(jour.lien)}"
               ${raw(r.url === '#copier' ? `data-copy="${jour.lien}"` : 'rel="noopener"')}
               aria-label="${r.label}" title="${r.label}">
              ${icon(r.icon, { size: 18 })}
            </a>`)}
        </div>`,
    })}

    <!-- Statistiques -->
    ${B.railCard({
      title: 'Statistiques',
      link: { label: 'Voir détails', href: '/rapports/ressources' },
      body: html`
        <div class="stat-lines">
          ${each(d.statistiques.lignes, (l) => html`
            <div class="stat-line">
              <span class="stat-line__icon" style="${raw(`background:var(--t-${l.tone}-bg);color:var(--t-${l.tone}-fg)`)}">
                ${icon(l.icon, { size: 16 })}
              </span>
              <span>${l.label}</span>
              <b>${number(l.valeur)}</b>
            </div>`)}
        </div>
        ${sparkline(d.statistiques.serie)}`,
    })}`;

  return {
    title: 'Tableau de bord',
    active: '/tableau-de-bord',
    search: 'Rechercher une ressource, un outil, une discipline…',
    styles: ['dashboard'],
    main,
    rail,
  };
}

/** Courbe compacte : aire + ligne, tracées à partir d'une série de nombres. */
function sparkline(serie) {
  const w = 280; const h = 62; const pad = 4;
  const max = Math.max(...serie); const min = Math.min(...serie);
  const x = (i) => pad + (i * (w - pad * 2)) / (serie.length - 1);
  const y = (v) => h - pad - ((v - min) / (max - min || 1)) * (h - pad * 2);
  const ligne = serie.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(v).toFixed(1)}`).join('');
  return raw(
    `<svg class="sparkline" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">` +
      `<path d="${ligne}L${w - pad} ${h} L${pad} ${h}Z" fill="rgba(29,78,216,.12)"/>` +
      `<path d="${ligne}" fill="none" stroke="#1d4ed8" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/></svg>`
  );
}

/* ========================================================================= */
/* Élève                                                                     */
/* ========================================================================= */
async function vueEleve(ctx) {
  const prenom = ctx.user.name.split(' ')[0];

  const main = html`
    ${B.hero({
      tone: 'blue', mark: 'home',
      title: `Bonjour ${prenom}`,
      lede: 'Voici ce qui t’attend aujourd’hui : tes cours du jour, tes devoirs à rendre et les ressources conseillées pour ton niveau.',
      actions: [{ label: 'Voir mon agenda', href: '/mon-agenda', icon: 'calendar' }],
    })}
    ${B.stats([
      { label: 'Cours suivis', value: 8, icon: 'book', tone: 'blue' },
      { label: 'Devoirs à rendre', value: 3, icon: 'pencil', tone: 'orange' },
      { label: 'Quiz terminés', value: 24, icon: 'checkCircle', tone: 'green' },
      { label: 'Moyenne générale', value: '14,2', icon: 'chart', tone: 'purple' },
    ])}
    ${B.list({
      title: 'À faire cette semaine',
      rows: [
        { title: 'Devoir de mathématiques : équations du premier degré', description: 'À remettre vendredi 17 h', icon: 'sigma', tone: 'purple',
          tags: [{ label: 'Mathématiques', tone: 'purple' }, { label: 'À rendre', tone: 'orange' }], href: '/exercices-et-devoirs' },
        { title: 'Quiz de sciences : la photosynthèse', description: '15 questions, 20 minutes', icon: 'leaf', tone: 'green',
          tags: [{ label: 'Sciences', tone: 'green' }], href: '/quiz-et-evaluations' },
        { title: 'Lecture : méthode SQ3R', description: 'Conseillée avant le contrôle de jeudi', icon: 'sparkle', tone: 'blue',
          tags: [{ label: 'Méthodologie', tone: 'blue' }], href: '/ressources-methodologiques/rm-003' },
      ],
    })}`;

  const rail = html`
    ${B.railCard({
      title: 'Raccourcis',
      items: [
        { label: 'Mes cours', hint: 'Leçons et supports', icon: 'book', tone: 'blue', href: '/mes-cours' },
        { label: 'Laboratoire virtuel', hint: 'Simulations à explorer', icon: 'flask', tone: 'purple', href: '/laboratoire-virtuel' },
        { label: 'Bibliothèque numérique', hint: 'Manuels et lectures', icon: 'archive', tone: 'green', href: '/bibliotheque-numerique' },
      ],
    })}
    ${B.note({
      title: 'Astuce',
      text: 'Commence par la tâche la plus difficile quand ton attention est encore fraîche.',
    })}`;

  return { title: 'Tableau de bord', active: '/tableau-de-bord', search: 'Rechercher un cours, un devoir…', main, rail };
}
