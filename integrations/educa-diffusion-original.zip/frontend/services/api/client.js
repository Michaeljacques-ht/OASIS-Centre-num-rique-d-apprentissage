'use strict';
/**
 * Client HTTP vers diffusion-service.
 *
 * Le frontend n'accède jamais à PostgreSQL : il passe par l'API, comme le
 * prescrit l'architecture EDUCA (frontend → gateway → service → base).
 * En attendant le gateway, l'URL du service est directe et configurable.
 */
const http = require('http');
const https = require('https');

const BASE = process.env.API_DIFFUSION || 'http://127.0.0.1:4001/api/v1';
const DELAI = Number(process.env.API_DELAI) || 5000;

/** Identité de développement, en attendant le jeton du gateway. */
function enteteIdentite(identite) {
  if (!identite) return {};
  return { 'X-Dev-Identite': Buffer.from(JSON.stringify(identite)).toString('base64') };
}

function appeler(chemin, { identite, methode = 'GET', corps } = {}) {
  const url = new URL(BASE + chemin);
  const transport = url.protocol === 'https:' ? https : http;

  return new Promise((resoudre, rejeter) => {
    const req = transport.request(url, {
      method: methode,
      headers: {
        accept: 'application/json',
        ...(corps ? { 'content-type': 'application/json' } : {}),
        ...enteteIdentite(identite),
      },
      timeout: DELAI,
    }, (res) => {
      const morceaux = [];
      res.on('data', (d) => morceaux.push(d));
      res.on('end', () => {
        const texte = Buffer.concat(morceaux).toString('utf8');
        if (res.statusCode >= 400) {
          let message = texte;
          try { message = JSON.parse(texte).erreur.message; } catch { /* réponse non JSON */ }
          return rejeter(Object.assign(new Error(message), { statut: res.statusCode }));
        }
        try { resoudre(JSON.parse(texte)); }
        catch { resoudre(texte); }
      });
    });
    req.on('timeout', () => req.destroy(new Error('diffusion-service ne répond pas')));
    req.on('error', rejeter);
    if (corps) req.write(JSON.stringify(corps));
    req.end();
  });
}

module.exports = { appeler, BASE };
