'use strict';
/**
 * Adaptateur de données du frontend.
 *
 * Il expose les mêmes signatures que l'ancienne couche de persistance, mais
 * chaque appel part désormais vers diffusion-service. Les gabarits n'ont donc
 * pas eu à être réécrits lors du passage à l'architecture de l'écosystème.
 */
const { appeler } = require('./client');

/** Documents éditoriaux servis par le service. */
const DOCUMENTS = new Set([
  'nav', 'accueil', 'tableau-de-bord', 'methodologiques-eleve',
  'methodologiques-enseignant', 'ressources-eleves', 'ressources-pedagogiques-meta',
]);

const parametres = (filtres = {}) => {
  const p = new URLSearchParams();
  for (const [cle, valeur] of Object.entries(filtres)) {
    if (valeur && valeur !== 'tous' && valeur !== 'toutes') p.set(cle, valeur);
  }
  const s = p.toString();
  return s ? `?${s}` : '';
};

async function read(collection, identite, defaut = []) {
  if (DOCUMENTS.has(collection)) {
    const r = await appeler(`/public/documents/${collection}`);
    return r.donnees ?? defaut;
  }
  if (collection === 'ressources-pedagogiques') {
    const r = await appeler('/ressources?limite=200', { identite });
    return r.donnees;
  }
  if (collection === 'travaux-diriges') {
    const r = await appeler('/travaux-diriges?limite=200', { identite });
    return r.donnees;
  }
  throw new Error(`collection inconnue du frontend : ${collection}`);
}

async function query(collection, filtres, identite) {
  if (collection === 'ressources-pedagogiques') {
    const r = await appeler(`/ressources${parametres({ ...filtres, limite: 200 })}`, { identite });
    return r.donnees;
  }
  if (collection === 'travaux-diriges') {
    const r = await appeler(`/travaux-diriges${parametres({ ...filtres, limite: 200 })}`, { identite });
    return r.donnees;
  }
  return read(collection, identite);
}

module.exports = { read, query };
