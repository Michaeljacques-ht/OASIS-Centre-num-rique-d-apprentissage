'use strict';
/** Table des écrans. Les entrées de navigation sans écran mènent au chantier. */
const PAGES = {
  '/': require('../app/accueil'),
  '/tableau-de-bord': require('../app/tableau-de-bord'),
  '/ressources-pedagogiques': require('../app/ressources-pedagogiques'),
  '/ressources-methodologiques': require('../app/ressources-methodologiques'),
  '/travaux-diriges': require('../app/travaux-diriges'),
  '/systeme': require('../app/systeme'),
};
const chantier = require('../app/chantier');

function modules(nav) {
  const out = new Map();
  for (const espace of Object.values(nav || {})) {
    for (const groupe of espace.groups || []) {
      for (const item of groupe.items) if (!out.has(item.href)) out.set(item.href, item);
    }
  }
  return out;
}

function resoudre(pathname, nav) {
  if (PAGES[pathname]) return { page: PAGES[pathname] };
  const item = modules(nav).get(pathname);
  if (item) return { page: (ctx) => chantier(ctx, item), module: item };
  return null;
}

module.exports = { resoudre, PAGES, modules };
