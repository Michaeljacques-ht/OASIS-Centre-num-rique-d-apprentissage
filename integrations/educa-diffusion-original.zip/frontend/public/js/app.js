'use strict';
/* Comportements de l'ossature. Aucun cadriciel : trois interactions ciblées. */

// 1. Barre latérale escamotable sous 960 px
document.addEventListener('click', (event) => {
  const toggle = event.target.closest('[data-nav-toggle]');
  if (toggle) {
    const open = document.body.classList.toggle('nav-open');
    toggle.setAttribute('aria-expanded', String(open));
    return;
  }
  // Fermer en cliquant hors de la barre
  if (document.body.classList.contains('nav-open') && !event.target.closest('.sidebar')) {
    document.body.classList.remove('nav-open');
    document.querySelector('[data-nav-toggle]')?.setAttribute('aria-expanded', 'false');
  }
});

// 2. Échappe ferme la navigation mobile
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') document.body.classList.remove('nav-open');
});

// 3. Raccourci « / » pour atteindre la recherche
document.addEventListener('keydown', (event) => {
  const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName || '');
  if (event.key === '/' && !typing) {
    event.preventDefault();
    document.getElementById('q')?.focus();
  }
});

// 4. Copier un lien de partage dans le presse-papiers
document.addEventListener('click', async (event) => {
  const bouton = event.target.closest('[data-copy]');
  if (!bouton) return;
  event.preventDefault();
  const texte = bouton.dataset.copy;
  try {
    await navigator.clipboard.writeText(texte);
  } catch {
    const champ = document.createElement('textarea');
    champ.value = texte;
    document.body.append(champ);
    champ.select();
    document.execCommand('copy');
    champ.remove();
  }
  const avant = bouton.getAttribute('aria-label');
  bouton.setAttribute('aria-label', 'Lien copié');
  bouton.classList.add('est-copie');
  setTimeout(() => { bouton.setAttribute('aria-label', avant); bouton.classList.remove('est-copie'); }, 1600);
});

// 5. Défilement horizontal des disciplines
document.addEventListener('click', (event) => {
  const bouton = event.target.closest('[data-scroll]');
  if (!bouton) return;
  const piste = document.querySelector(bouton.dataset.scroll);
  if (piste) piste.scrollBy({ left: piste.clientWidth * 0.8, behavior: 'smooth' });
});
