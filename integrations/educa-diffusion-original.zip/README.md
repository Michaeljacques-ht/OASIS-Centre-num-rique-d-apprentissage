# EDUCA Diffusion — ossature et système de design

Plateforme éducative en **Node.js pur, zéro dépendance npm** — client
PostgreSQL compris, écrit pour ce projet. Cette première étape livre l'ossature commune et le système de design
extraits des vingt maquettes ; les modules se branchent ensuite dessus.

## Démarrer

Deux processus : le service de domaine et le frontend.

```bash
npm run dev            # lance les deux (service 4001, frontend 3000)
```

Ou séparément :

```bash
cd services/diffusion-service && PORT=4001 node src/server.js
cd frontend && API_DIFFUSION=http://127.0.0.1:4001/api/v1 node server.js
```

`PORT` n'a pas de valeur par défaut côté service : le numéro doit être
attribué dans le plan de ports de l'écosystème EDUCA.

### Avec PostgreSQL

```bash
cd services/diffusion-service
export DATABASE_URL="postgres://educa:secret@localhost:5432/diffusion"
psql "$DATABASE_URL" -f migrations/001_schema_initial.sql
psql "$DATABASE_URL" -f migrations/002_multi_tenant.sql
npm run migrer          # importe les collections JSON
```

Sans `DATABASE_URL`, le service lit les collections JSON de `data/` : le projet
reste lançable sans serveur de base.

## Base de données

36 tables réparties en sept domaines, décrites dans `docs/Modele-Donnees.md` :
carte des domaines, relations, matrice de cloisonnement, garanties portées par
la base, stratégie d'index.

```bash
cd services/diffusion-service
npm run schema      # rejoue les migrations sans serveur et vérifie dix règles
```

## Environnement de développement

`docs/INSTALLATION.md` détaille l'installation de VS Code, de PostgreSQL et de
pgAdmin, la création du rôle et de la base, et le branchement du projet.

Le dossier `.vscode/` est déjà configuré : `F5` → « Tout lancer » démarre le
service et le frontend avec points d'arrêt, et `requests.http` contient toutes
les requêtes de l'API pour l'extension REST Client.

## Architecture

```
educa-diffusion/
├── services/diffusion-service/     service de domaine
│   ├── src/
│   │   ├── config/                 environnement, accès base
│   │   ├── routes/                 contrat d'API v1
│   │   ├── middleware/             jeton, cloisonnement, erreurs
│   │   ├── controllers/            traduction HTTP ↔ métier
│   │   ├── services/               règles de gestion
│   │   ├── repositories/           SQL, clause de cloisonnement
│   │   ├── models/                 projections SQL ↔ objets
│   │   ├── validators/             validation des entrées
│   │   ├── events/                 publication d'événements
│   │   └── utils/                  client PostgreSQL, encodeur QR, HTTP
│   ├── migrations/                 7 migrations · 36 tables · 3 vues
│   └── tests/                      schéma, client PostgreSQL, QR, cloisonnement
├── frontend/                       rendu, navigation, session (transitoire)
│   ├── app/                        un écran par fichier
│   ├── components/                 ossatures et blocs de page
│   ├── services/api/               client HTTP vers le service
│   ├── lib/                        gabarits et icônes
│   └── public/                     CSS, JS, images
├── data/                           collections JSON (socle de repli)
├── docs/                           documents de projet
└── tools/                          aperçus, visuels, documentation
```

Le frontend n'accède jamais à la base : `grep -r "require.*pg" frontend/` ne
renvoie rien. Le détail de la réorganisation et les points restants figurent
dans `docs/Alignement-Architecture-EDUCA.md`.

## Le client PostgreSQL, sans dépendance

`lib/pg/` implémente le protocole v3 : message de démarrage, authentification
en clair, md5 et **SCRAM-SHA-256**, TLS, requêtes simples et préparées avec
paramètres, transactions, réserve de connexions, erreurs converties en
exceptions portant leur code SQLSTATE.

```js
const pg = require('./lib/pg');
const bd = pg.reserve(process.env.DATABASE_URL);
const { lignes } = await bd.requete(
  'SELECT * FROM ressources WHERE niveau = $1', ['Secondaire 2']
);
```

`npm test` dans le service le contrôle en trois niveaux : SCRAM confronté au
vecteur de test de la **RFC 7677** (preuve client et signature serveur), cadrage
et conversion des types en isolation, puis un aller-retour complet contre un
serveur factice (`tests/mock-pg.js`) qui parle réellement le protocole —
authentification, requêtes paramétrées, erreurs, transactions, épuisement de la
réserve.

**À confirmer contre un vrai serveur PostgreSQL avant la production.** Ces
contrôles valident le protocole tel que je l'ai implémenté ; ils ne remplacent
pas une session contre PostgreSQL lui-même.

## Le QR code, sans dépendance

`lib/qr.js` encode un QR complet : Reed-Solomon sur GF(256), les huit masques
avec calcul de pénalité, l'information de format en BCH(15,5). Niveau de
correction M, versions 1 à 6, soit 106 octets — largement de quoi coder une URL
de ressource.

```js
const qr = require('./lib/qr');
qr.svg('https://diffusion.educa.ht/r/RES-12564', { size: 220, logo: dataUri });
```

Le serveur expose `/qr.svg?texte=…` pour l'afficher, et `&telecharger=1` pour
l'obtenir en fichier. Le logo central occupe 18 % de la largeur, ce que le
niveau M absorbe sans perte de lecture.

`npm test` contrôle aussi l'encodeur : syndromes de Reed-Solomon nuls,
reste BCH nul sur l'information de format, et relecture module par module de la
trame qui doit redonner le texte de départ. **À confirmer une fois avec un
téléphone** : ces contrôles valident l'algorithme, pas la lecture optique.

## Images du site public

Les visuels livrés sont des **SVG d'attente** générés par
`node tools/make-placeholders.js`. Pour passer aux vraies images, deux
possibilités :

- déposer vos fichiers sous `public/img/` et changer les chemins dans
  `data/accueil.json` (`hero.image`, `categories[].image`) ;
- ou garder les mêmes noms de fichier en `.jpg` et corriger l'extension dans le
  même fichier JSON.

Les formats attendus : bannière 4/3 (800 × 600 minimum), vignettes de
catégorie 4/3 (400 × 300).

## Suite

1. Écrans de création : l'assistant en 5 étapes (TD, examens, laboratoires) avec
   aperçu live à droite — le patron est identique dans quatre maquettes.
2. Écriture des données : `store.write()` et `store.insert()` sont prêts ; il
   reste à traiter les requêtes POST dans `server.js`.
3. Authentification et sessions, en remplacement du cookie de rôle.
4. Modules restants, un fichier de page à la fois.
5. Pages publiques restantes : catalogue, fiche produit, panier, connexion et
   inscription — l'en-tête les annonce déjà.
