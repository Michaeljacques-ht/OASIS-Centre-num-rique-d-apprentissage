# Tester EDUCA Diffusion — pas à pas

Aucune installation : `npm install` n'a rien à installer.
Prérequis : Node.js 18 ou plus (`node -v`).

---

## Étape 1 — La suite automatique

```bash
cd services/diffusion-service
npm test
```

Trois séries, 60 contrôles au total :

| Série | Ce qu'elle vérifie |
| --- | --- |
| `verify-pg.js` | Client PostgreSQL : SCRAM contre la RFC 7677, cadrage du protocole, types, aller-retour contre un serveur factice |
| `verify-qr.js` | Encodeur QR : Reed-Solomon, information de format, relecture de la trame |
| `tenant-isolation.js` | Jeton, rôles, cloisonnement par école, injections SQL |

Attendu : `Tous les contrôles passent` trois fois. Un échec nomme le contrôle
et la valeur attendue.

---

## Étape 2 — Démarrer les deux processus

```bash
cd ../..          # racine du projet
npm run dev
```

Attendu :

```
[service ] diffusion-service — http://localhost:4001/api/v1
[service ]   socle de données  : collections JSON (DATABASE_URL absent)
[frontend] EDUCA Diffusion — frontend : http://localhost:3000
```

Le service refuse de démarrer sans `PORT` : c'est voulu, le numéro doit venir
du plan de ports de l'écosystème.

---

## Étape 3 — Le service répond

Dans un second terminal :

```bash
curl -s http://127.0.0.1:4001/api/v1/sante
```

→ `{"donnees":{"service":"diffusion-service","socle":"json","etat":"ok"}}`

Routes ouvertes, sans compte — ce sont celles qu'un élève atteint en scannant
un manuel :

```bash
curl -s http://127.0.0.1:4001/api/v1/public/r/rp-001 | head -c 200
curl -s "http://127.0.0.1:4001/api/v1/public/qr?texte=https://diffusion.educa.ht/r/rp-001" | head -c 80
curl -s http://127.0.0.1:4001/api/v1/public/documents/nav | head -c 120
```

---

## Étape 4 — L'authentification bloque bien

```bash
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:4001/api/v1/ressources
```

→ `401`. Le fonds n'est pas ouvert sans identité.

En développement, sans contrat JWT configuré, une identité de test suffit :

```bash
ID=$(printf '%s' '{"sub":"usr_1","role":"enseignant","school_id":"eco_A","academic_year_id":"an_2026"}' | base64 -w0)
curl -s -H "X-Dev-Identite: $ID" "http://127.0.0.1:4001/api/v1/ressources?limite=2" | head -c 300
```

→ `200` avec `{ donnees: [...], meta: { total, limite, decalage } }`.

---

## Étape 5 — Le cloisonnement, à la main

C'est le contrôle le plus important. Forcez une autre école par l'URL :

```bash
curl -s -H "X-Dev-Identite: $ID" "http://127.0.0.1:4001/api/v1/travaux-diriges?school_id=eco_B"
```

→ `403 TENANT_REFUSE`. L'école vient du jeton, jamais du client.

Un compte sans école n'atteint pas le travail de classe :

```bash
SANS=$(printf '%s' '{"sub":"u","role":"enseignant"}' | base64 -w0)
curl -s -H "X-Dev-Identite: $SANS" http://127.0.0.1:4001/api/v1/travaux-diriges
```

→ `403 ECOLE_ABSENTE`. Mais le fonds commun, lui, reste lisible :

```bash
curl -s -o /dev/null -w "%{http_code}\n" -H "X-Dev-Identite: $SANS" http://127.0.0.1:4001/api/v1/ressources
```

→ `200`.

Un élève ne peut pas créer un travail dirigé :

```bash
ELEVE=$(printf '%s' '{"sub":"e","role":"eleve","school_id":"eco_A"}' | base64 -w0)
curl -s -X POST -H "X-Dev-Identite: $ELEVE" -H "content-type: application/json" \
  -d '{"titre":"Test","discipline":"Mathématiques","niveau":"Secondaire 3","cycle":"secondaire"}' \
  http://127.0.0.1:4001/api/v1/travaux-diriges
```

→ `403 ROLE_INSUFFISANT`.

Validation des entrées :

```bash
curl -s -X POST -H "X-Dev-Identite: $ID" -H "content-type: application/json" \
  -d '{"titre":"","niveau":"Zorglub","cycle":"lunaire"}' \
  http://127.0.0.1:4001/api/v1/travaux-diriges
```

→ `422` avec le détail par champ.

---

## Étape 6 — Avec un vrai jeton signé

Dès qu'une clé est configurée, l'en-tête de développement est refusé.

```bash
cd services/diffusion-service
PORT=4001 JWT_SECRET=secret-de-test node src/server.js
```

Fabriquez un jeton :

```bash
JETON=$(node -e "
const c=require('crypto');const b=o=>Buffer.from(JSON.stringify(o)).toString('base64url');
const h=b({alg:'HS256',typ:'JWT'});
const p=b({sub:'u',role:'enseignant',school_id:'eco_A',academic_year_id:'an_2026',
           exp:Math.floor(Date.now()/1000)+600});
console.log(h+'.'+p+'.'+c.createHmac('sha256','secret-de-test').update(h+'.'+p).digest('base64url'));")

curl -s -o /dev/null -w "jeton signé : %{http_code}\n" -H "Authorization: Bearer $JETON" \
  http://127.0.0.1:4001/api/v1/ressources
curl -s -o /dev/null -w "en-tête dev : %{http_code}\n" -H "X-Dev-Identite: $ID" \
  http://127.0.0.1:4001/api/v1/ressources
```

→ `200` puis `401`.

---

## Étape 7 — Le frontend

Ouvrez `http://localhost:3000` et parcourez :

| Adresse | Attendu |
| --- | --- |
| `/` | Accueil public en panneaux |
| `/tableau-de-bord` | Espace enseignant |
| `/tableau-de-bord?role=eleve` | Espace élève |
| `/ressources-pedagogiques?discipline=Sciences` | Catalogue filtré |
| `/travaux-diriges` | Liste, compteurs, rail |
| `/qr.svg?texte=abc` | QR code relayé par le service |
| `/systeme` | Système de design |
| `/inconnu` | Page introuvable, code 404 |

**Le test décisif de l'architecture** : arrêtez le service seul, laissez le
frontend. Rechargez une page — vous devez obtenir « Le service de diffusion
est injoignable ». Si une page continue de s'afficher avec des données, c'est
que le frontend lit encore la base, ce que l'architecture interdit.

Deux vérifications complémentaires, qui doivent ne rien renvoyer :

```bash
grep -r "DATABASE_URL" frontend/
grep -rn "require.*utils/pg" frontend/
```

---

## Étape 8 — Avec PostgreSQL

```bash
cd services/diffusion-service
export DATABASE_URL="postgres://educa:secret@localhost:5432/diffusion"
psql "$DATABASE_URL" -f migrations/001_schema_initial.sql
psql "$DATABASE_URL" -f migrations/002_multi_tenant.sql
npm run migrer
PORT=4001 node src/server.js
```

Le démarrage doit annoncer `socle de données : PostgreSQL`, et
`/api/v1/sante` renvoyer `"socle":"postgres"`.

Deux contrôles que seul un vrai serveur permet :

```sql
-- Le déclencheur doit refuser la suppression d'une ressource imprimée
UPDATE ressources SET manuel_id = 'man_test' WHERE id = 'rp-001';
DELETE FROM ressources WHERE id = 'rp-001';   -- doit échouer

-- Un dépôt renvoyé sans motif doit être refusé
INSERT INTO depots (id, ressource_id, statut) VALUES ('dep_1', 'rp-001', 'renvoye');
```

Puis relancez `npm test` : les contrôles de cloisonnement vérifient cette fois
le SQL réellement exécuté.

---

## Étape 9 — Aperçus hors ligne

Avec le service démarré :

```bash
npm run apercus
```

Huit fichiers autonomes dans `preview/`, ouvrables par double-clic, sans
serveur — pratique pour montrer les écrans à quelqu'un.

---

## Ce qui reste hors de portée de ces tests

- Le contrat réel du gateway : les revendications lues (`sub`, `role`,
  `school_id`, `academic_year_id`) viennent de votre document d'architecture,
  pas d'un jeton observé.
- La lecture optique des QR codes : à vérifier au téléphone sur une épreuve
  imprimée avant tout tirage.
- PostgreSQL en conditions réelles tant que l'étape 8 n'a pas été jouée.
