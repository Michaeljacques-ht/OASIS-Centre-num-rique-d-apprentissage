# ÉDUCA Diffusion — architecture de la base de données

**PostgreSQL · 36 tables · 3 vues · 7 migrations**
Vérifiée par `npm run schema` dans le service.

---

## 1. Analyse de l'écart

Le schéma initial couvrait 11 tables pour 14 modules documentés. Les domaines
suivants n'existaient pas en base :

| Module du document de projet | État avant | Apporté par |
| --- | --- | --- |
| Banque de questions et quiz | absent | 003 |
| Travaux pratiques, exposés, dissertations, examens | seuls les TD | 003 |
| Assignations et remises | absent | 003 |
| Compétences | absent | 004 |
| Parcours et progression | absent | 004 |
| Avis et reprise de lecture | colonnes agrégées seulement | 004 |
| Laboratoire numérique | absent | 005 |
| Groupes, forum, signalements, annonces | absent | 005 |
| Chapitres, liens courts, scans | `manuels` seule | 006 |
| Commandes et abonnements | absent | 007 |

---

## 2. Principes de conception

**Une table par cycle de vie, pas une table par écran.** Les cinq formes de
travail — TD, TP, exposé, dissertation, examen — partagent le même cycle
(brouillon → publié → assigné → corrigé), la même assignation et la même
remise. Elles forment donc **une** table `travaux` avec un discriminant `type`,
et ce qui leur est propre vit dans `details` en JSONB. Une vue
`travaux_diriges` préserve le code applicatif existant.

**Les identités restent à leur propriétaire.** Aucune clé étrangère ne pointe
vers `utilisateurs`, `etablissements` ou `classes` : ces domaines appartiennent
à `utilisateur-service` et `ecole-service`. Les colonnes `auteur_id`,
`ecole_id`, `classe_id` sont des identifiants de référence, contrôlés par le
service propriétaire, pas par cette base.

**Les valeurs dérivées sont calculées par la base.** La note moyenne d'une
ressource est recalculée par déclencheur à chaque avis ; le pourcentage de
progression est une colonne générée. Aucun code applicatif ne peut les
désynchroniser.

**Le cloisonnement est une contrainte, pas une convention.** Une ressource non
commune sans `ecole_id` est refusée en base. Un travail publié sans école est
refusé. Une remise corrigée sans note ni correcteur est refusée.

---

## 3. Carte des domaines

```
┌─ FONDS DOCUMENTAIRE ──────────┐   ┌─ DIFFUSION IMPRIMÉE ───────────┐
│ ressources                    │──▶│ manuels ─ chapitres            │
│ documents                     │   │ manuel_ressources              │
│ ressource_competences         │   │ liens_courts ─ scans           │
│ avis · lectures · favoris     │   └────────────────────────────────┘
│ usages · depots               │
└───────────┬───────────────────┘   ┌─ COMMERCE ─────────────────────┐
            │                       │ commandes ─ commande_lignes    │
┌─ APPRENTISSAGE ───────────────┐   │ abonnements                    │
│ competences                   │   └────────────────────────────────┘
│ parcours ─ parcours_etapes    │
│ progressions                  │   ┌─ COMMUNAUTÉ ───────────────────┐
└───────────┬───────────────────┘   │ groupes ─ groupe_membres       │
            │                       │ sujets ─ messages              │
┌─ ÉVALUATION ──────────────────┐   │ signalements · annonces        │
│ travaux ─ exercices           │   └────────────────────────────────┘
│ questions ─ quiz ─ quiz_quest.│
│ assignations ─ remises        │   ┌─ LABORATOIRE ──────────────────┐
└───────────────────────────────┘   │ laboratoires                   │
                                    │ laboratoire_sessions           │
┌─ TRANSVERSE ──────────────────┐   └────────────────────────────────┘
│ journal_audit                 │
└───────────────────────────────┘
```

---

## 4. Relations principales

```
                      ┌──────────────┐
                      │  ressources  │◀──────────┐
                      ├──────────────┤           │
              ┌──────▶│ PK id        │           │ ON DELETE RESTRICT
              │       │ visibilite   │           │ (une ressource imprimée
   1 ┌────────┴───┐   │ ecole_id     │           │  ne se supprime pas)
     │ avis       │   │ lien_court U │           │
     │ lectures   │   └───┬───┬──────┘   ┌───────┴────────┐
     │ favoris    │       │1  │1         │ manuel_ressou. │
     └────────────┘       │*  │*         ├────────────────┤
                   ┌──────▼─┐ │ ┌────────│ PK manuel_id   │
                   │ usages │ │ │        │ PK ressource_id│
                   └────────┘ │ │        └───────┬────────┘
                              │ │                │*
                   ┌──────────▼─▼──┐      ┌──────▼─────┐ 1   * ┌───────────┐
                   │ ressource_    │      │  manuels   │───────│ chapitres │
                   │ competences   │      └──────┬─────┘       └───────────┘
                   └───────┬───────┘             │1
                           │*                    │*
                   ┌───────▼───────┐      ┌──────▼───────┐ 1  * ┌─────────┐
                   │  competences  │      │ liens_courts │──────│  scans  │
                   └───────────────┘      └──────────────┘      └─────────┘

   ┌──────────┐ 1  * ┌────────────────┐        ┌─────────────┐ 1  * ┌──────────┐
   │ parcours │──────│ parcours_etapes│        │   travaux   │──────│exercices │
   └────┬─────┘      └────────────────┘        └──────┬──────┘      └──────────┘
        │1                                            │
        │*                                     ┌──────▼────────┐ 1  * ┌─────────┐
   ┌────▼─────────┐                            │ assignations  │──────│ remises │
   │ progressions │                            └───────────────┘      └─────────┘
   └──────────────┘                                   ▲
                                                      │  (objet_type/objet_id :
   ┌────────┐ 1  * ┌────────────────┐                 │   travail, quiz, parcours,
   │  quiz  │──────│ quiz_questions │─────▶ questions │   ressource, laboratoire)
   └────────┘      └────────────────┘

   ┌─────────┐ 1  * ┌────────────────┐     ┌────────┐ 1  * ┌──────────┐
   │ groupes │──────│ groupe_membres │     │ sujets │──────│ messages │
   └─────────┘      └────────────────┘     └────────┘      └──────────┘

   ┌───────────┐ 1  * ┌─────────────────┐  ┌───────────┐ 1  * ┌──────────────────┐
   │ commandes │──────│ commande_lignes │  │laboratoires│─────│ labo_sessions    │
   └───────────┘      └─────────────────┘  └───────────┘      └──────────────────┘
```

---

## 5. Matrice de cloisonnement

| Table | `ecole_id` | `annee_academique_id` | `cycle` | Portée |
| --- | :---: | :---: | :---: | --- |
| `ressources` | facultatif | — | oui | Commun, ou école si `visibilite = 'ecole'` |
| `questions` | facultatif | — | oui | Idem |
| `parcours` | facultatif | — | oui | Idem |
| `laboratoires` | facultatif | — | oui | Idem |
| `travaux` | **obligatoire si publié** | oui | oui | École |
| `quiz` | oui | oui | oui | École |
| `assignations` | **NOT NULL** | **NOT NULL** | — | École |
| `remises` | **NOT NULL** | — | — | École |
| `groupes` | **NOT NULL** | oui | — | École |
| `annonces` | **NOT NULL** | oui | — | École |
| `abonnements` | **NOT NULL** | — | — | École |
| `manuels`, `chapitres`, `liens_courts`, `scans` | — | — | — | Écosystème (contenu édité) |
| `documents`, `competences` | — | — | oui | Écosystème |

La règle : **le contenu édité est commun, le travail de classe est cloisonné.**

---

## 6. Garanties portées par la base

| Garantie | Mécanisme |
| --- | --- |
| Une ressource liée à un manuel imprimé ne peut pas être supprimée | Déclencheur `trg_ressources_suppression` |
| Un code QR imprimé ne peut pas être supprimé | Déclencheur `trg_liens_suppression` |
| Un code inactif a toujours une cible ou une redirection | `lien_cible_obligatoire` |
| Une ressource non commune nomme son école | `ressources_ecole_obligatoire` |
| Un dépôt renvoyé porte un motif | `commentaire_obligatoire_si_renvoi` |
| Un modérateur ne valide pas son propre dépôt | `moderateur_distinct_de_auteur` |
| Une note ne dépasse pas son barème | `remises_note_dans_bareme` |
| Une remise corrigée a une note et un correcteur | `remises_correction_complete` |
| Une commande payée porte sa transaction | `commandes_paiement_trace` |
| La note moyenne d'une ressource reste exacte | Déclencheur `trg_avis_note` |
| Le pourcentage de progression ne peut pas diverger | Colonne générée |
| Le journal d'audit reste borné à 5 000 entrées | Déclencheur `trg_audit_elagage` |
| Les cycles sont limités aux trois de l'écosystème | `CHECK` sur chaque colonne `cycle` |

---

## 7. Index

71 index, selon trois règles :

1. **Toute clé étrangère est indexée** — vérifié automatiquement.
2. **Les filtres de l'interface sont indexés**, y compris en index
   d'expression : `unaccent_simple(discipline)` sert les comparaisons sans
   accent ni casse du catalogue.
3. **Les colonnes de cloisonnement sont indexées en tête** : `(ecole_id,
   annee_academique_id)`, puisque aucune requête de travail de classe ne part
   sans elles.

---

## 8. Vues

| Vue | Usage |
| --- | --- |
| `travaux_diriges` | Compatibilité : le dépôt applicatif existant continue de fonctionner après la fusion des cinq formes de travail |
| `vue_couverture_fonds` | Ressources publiées par discipline, niveau et cycle — montre les trous du catalogue |
| `vue_usage_manuels` | Scans par manuel, par chapitre et par mois |

---

## 9. Contrôle automatique du schéma

```bash
cd services/diffusion-service
npm run schema
```

`tests/schema-lint.js` rejoue les sept migrations **sans serveur**, reconstruit
l'état final et vérifie dix règles : transactions équilibrées, aucune table en
double, cibles d'`ALTER` existantes, renommages cohérents, clés étrangères
valides, frontières de service respectées, clé primaire partout, cloisonnement
présent, index sur chaque clé étrangère, contrainte de cycle complète.

Cet outil a trouvé quatre anomalies réelles lors de sa première exécution :
trois colonnes `cycle` sans contrainte de valeurs, et deux clés étrangères sans
index.

---

## 10. Appliquer

```bash
cd services/diffusion-service
export DATABASE_URL="postgres://educa:secret@localhost:5432/educa_diffusion"
for f in migrations/0*.sql; do psql "$DATABASE_URL" -f "$f" || break; done
npm run migrer     # importe les collections JSON de démonstration
```

Les migrations sont idempotentes (`IF NOT EXISTS`, `DROP CONSTRAINT IF EXISTS`)
et peuvent être rejouées sans dommage.

---

## 11. Ce qui reste

- **Non exécuté contre un vrai PostgreSQL.** L'analyseur valide la cohérence
  du schéma, pas son acceptation par le moteur. La première exécution de
  `psql` reste à faire.
- **Les dépôts applicatifs ne couvrent que `ressources` et `travaux`.** Les
  30 autres tables existent en base mais n'ont pas encore de code d'accès :
  elles suivront module par module, selon le planning du document de projet.
- **Pas de partitionnement.** `scans` et `journal_audit` grossiront ; un
  partitionnement par mois sera à envisager au-delà de quelques millions de
  lignes.
