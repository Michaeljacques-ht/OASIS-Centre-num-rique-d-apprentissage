# Installer et configurer l'environnement de développement

Deux outils à poser : **Visual Studio Code** pour écrire, **PostgreSQL** pour
la base. L'outil d'administration graphique de PostgreSQL s'appelle **pgAdmin**
— phpMyAdmin est son équivalent du monde MySQL, il ne gère pas PostgreSQL.
Sur Windows et macOS, pgAdmin est fourni avec l'installateur de PostgreSQL.

---

## 1. Node.js

Le projet ne fonctionne qu'avec Node 18 ou plus.

| Système | Commande |
| --- | --- |
| Windows | Télécharger la version LTS sur nodejs.org, installateur `.msi` |
| macOS | `brew install node` |
| Ubuntu / Debian | `sudo apt install nodejs npm` |

Vérification : `node -v` doit afficher `v18` ou plus.

---

## 2. Visual Studio Code

Téléchargement sur `code.visualstudio.com`, ou :

| Système | Commande |
| --- | --- |
| macOS | `brew install --cask visual-studio-code` |
| Ubuntu / Debian | `sudo snap install code --classic` |

**Sur Windows, cochez « Ajouter à PATH » pendant l'installation** : sans cela,
la commande `code .` ne fonctionnera pas depuis un terminal.

### Ouvrir le projet

```bash
cd educa-diffusion
code .
```

VS Code proposera d'installer les extensions conseillées — acceptez. Elles
sont déclarées dans `.vscode/extensions.json` :

| Extension | À quoi elle sert ici |
| --- | --- |
| **REST Client** | Exécuter les requêtes de `requests.http` sans quitter l'éditeur |
| **SQLTools** + pilote PostgreSQL | Interroger la base depuis l'éditeur |
| **EditorConfig** | Respecter les retraits du projet |
| **Code Spell Checker** (+ français) | Repérer les fautes dans les commentaires et l'interface |

Le projet n'ayant aucune dépendance npm, aucun outillage de bundler,
de transpileur ou de framework n'est nécessaire.

### Ce qui est déjà configuré

- **`.vscode/launch.json`** — touche `F5` puis « Tout lancer » démarre le
  service et le frontend ensemble, avec points d'arrêt actifs. Deux
  configurations lancent directement les suites de tests.
- **`.vscode/tasks.json`** — `Ctrl+Maj+P` → « Exécuter la tâche » : tests,
  application du schéma, import des collections, régénération des aperçus.
- **`.vscode/settings.json`** — fins de ligne, encodage, connexion SQLTools
  vers la base locale. **Le mot de passe n'y figure pas** : il est demandé à
  la connexion.

---

## 3. PostgreSQL et pgAdmin

### Windows

1. Installateur EDB sur `postgresql.org/download/windows`.
2. Pendant l'installation, gardez cochés **PostgreSQL Server**, **pgAdmin 4**
   et **Command Line Tools** — ce dernier fournit `psql`, utilisé par les
   scripts du projet.
3. Notez le mot de passe du superutilisateur `postgres` : il n'est pas
   récupérable.
4. Laissez le port `5432`.

### macOS

```bash
brew install postgresql@16
brew services start postgresql@16
brew install --cask pgadmin4
```

### Ubuntu / Debian

```bash
sudo apt install postgresql postgresql-client
sudo systemctl enable --now postgresql
# pgAdmin : dépôt officiel, voir pgadmin.org/download
```

Vérification : `psql --version`.

---

## 4. Créer le rôle et la base

Ne travaillez pas avec le compte `postgres` : créez un rôle dédié au projet.

**Depuis un terminal**, avec `psql` :

```bash
# Windows : ouvrez « SQL Shell (psql) » depuis le menu Démarrer
# macOS / Linux :
sudo -u postgres psql
```

Puis, dans `psql` :

```sql
CREATE ROLE educa WITH LOGIN PASSWORD 'choisissez_un_mot_de_passe';
CREATE DATABASE educa_diffusion OWNER educa;
\c educa_diffusion
GRANT ALL ON SCHEMA public TO educa;
\q
```

**Ou depuis pgAdmin** : clic droit sur *Login/Group Roles* → *Create* → *Login
Role*, onglet *Definition* pour le mot de passe, onglet *Privileges* → *Can
login ?* à **Yes**. Puis clic droit sur *Databases* → *Create* → *Database*,
propriétaire `educa`.

---

## 5. Brancher le projet

L'URL de connexion suit ce format :

```
postgres://educa:MOT_DE_PASSE@localhost:5432/educa_diffusion
```

Si le mot de passe contient `@`, `:` ou `/`, encodez-les (`@` devient `%40`).

**Windows, PowerShell :**

```powershell
cd services\diffusion-service
$env:DATABASE_URL = "postgres://educa:secret@localhost:5432/educa_diffusion"
psql $env:DATABASE_URL -f migrations\001_schema_initial.sql
psql $env:DATABASE_URL -f migrations\002_multi_tenant.sql
npm run migrer
$env:PORT = "4001"
node src\server.js
```

**macOS / Linux :**

```bash
cd services/diffusion-service
export DATABASE_URL="postgres://educa:secret@localhost:5432/educa_diffusion"
psql "$DATABASE_URL" -f migrations/001_schema_initial.sql
psql "$DATABASE_URL" -f migrations/002_multi_tenant.sql
npm run migrer
PORT=4001 node src/server.js
```

Le démarrage doit annoncer `socle de données : PostgreSQL`.

Pour que `F5` déboguez aussi sur PostgreSQL, ajoutez `DATABASE_URL` dans le
bloc `env` de la configuration `diffusion-service` de `.vscode/launch.json`.

---

## 6. Vérifier dans pgAdmin

Connectez un serveur : clic droit sur *Servers* → *Register* → *Server*.

| Champ | Valeur |
| --- | --- |
| Name | EDUCA Diffusion |
| Host | `localhost` |
| Port | `5432` |
| Maintenance database | `educa_diffusion` |
| Username | `educa` |

Dépliez ensuite *Schemas → public → Tables* : onze tables doivent apparaître,
dont `ressources`, `travaux_diriges`, `documents` et `journal_audit`.

Deux requêtes à lancer dans l'outil de requête pour confirmer que les règles
du schéma sont bien actives :

```sql
-- Le déclencheur doit refuser la suppression d'une ressource imprimée
UPDATE ressources SET manuel_id = 'man_test' WHERE id = 'rp-001';
DELETE FROM ressources WHERE id = 'rp-001';   -- doit échouer

-- Un dépôt renvoyé sans motif doit être refusé
INSERT INTO depots (id, ressource_id, statut) VALUES ('dep_1', 'rp-001', 'renvoye');
```

Les deux doivent produire une erreur. Si elles réussissent, la migration 002
n'a pas été appliquée.

---

## 7. Deux précautions

**Le mot de passe ne va jamais dans le dépôt.** Ni dans `.vscode/settings.json`,
ni dans un fichier suivi par Git. Utilisez une variable d'environnement, ou un
fichier `.env` local exclu du dépôt — `services/diffusion-service/.env.example`
liste les variables attendues, sans valeur.

**pgAdmin n'est pas nécessaire au fonctionnement.** C'est un outil de confort
pour inspecter les données. Le projet n'en dépend pas : `psql` et l'extension
SQLTools suffisent, et SQLTools évite de quitter l'éditeur.
