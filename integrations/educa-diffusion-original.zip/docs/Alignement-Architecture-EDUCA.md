# EDUCA Diffusion — alignement sur l'architecture de l'écosystème

**Document de réorganisation · août 2026**
Établi à partir du *EDUCA Master Development Context*, en suivant la méthode
imposée par sa section 15 : analyser, tracer, vérifier le cloisonnement,
mesurer l'impact, implémenter, tester, rapporter.

---

## 1. Analyse — état constaté

EDUCA Diffusion avait été construit comme un monolithe autonome : un processus
Node rendant du HTML, lisant directement ses données. Confronté au contexte de
développement de l'écosystème, l'écart portait sur six points.

| Exigence de l'écosystème | État constaté | Gravité |
| --- | --- | --- |
| Séparation frontend / backend | Le rendu lisait la base directement | Bloquant |
| Architecture en services | Monolithe unique | Structurant |
| Multi-école (`school_id`) | Aucune notion d'école | Bloquant |
| Année académique (`academic_year_id`) | Absente | Bloquant |
| Cycles (maternelle / primaire / secondaire) | Absents ; niveaux « Secondaire n » seulement | Important |
| Authentification JWT du gateway | Cookie de rôle, aucune vérification | Bloquant |
| Frontières de service | Tables `utilisateurs`, `etablissements`, `classes` détenues localement | Structurant |

**Point le plus grave.** La plateforme possédait ses propres tables
d'utilisateurs, d'établissements et de classes — domaines qui appartiennent
à `utilisateur-service` et `ecole-service`. Conservées, elles auraient produit
deux sources de vérité sur les mêmes personnes.

---

## 2. Traçage — chaîne complète après réorganisation

```
Navigateur
   ↓
frontend/ (rendu, session, navigation)
   ↓  services/api/client.js
HTTP  →  [gateway, à l'intégration]
   ↓
services/diffusion-service/
   ↓  routes/v1.routes.js
   ↓  middleware/auth.middleware.js      vérification du jeton
   ↓  middleware/tenant.middleware.js    école, année, cycle
   ↓  controllers/                       traduction HTTP ↔ métier
   ↓  services/                          règles de gestion
   ↓  repositories/                      SQL, clause de cloisonnement
   ↓  utils/pg/                          client PostgreSQL
PostgreSQL
```

Le frontend n'importe plus aucun module d'accès aux données. Vérifiable :
`grep -r "require.*pg\|DATABASE_URL" frontend/` ne renvoie rien.

---

## 3. Décisions prises

### 3.1 Un service, pas plusieurs
Diffusion devient **`diffusion-service`**, un service de domaine parmi les
autres. Le découper davantage n'aurait pas de sens : fonds documentaire,
travaux et QR codes partagent le même modèle de données.

### 3.2 Les identités restent à leur propriétaire
Les tables `utilisateurs`, `etablissements` et `classes` sont supprimées par la
migration 002. Le service ne conserve que des identifiants de référence
(`auteur_id`, `ecole_id`, `classe_id`), **sans clé étrangère inter-service**.
Les comptes de démonstration deviennent une fixture du frontend.

### 3.3 Le fonds commun n'est pas une entorse au cloisonnement
La règle « une école ne doit jamais recevoir les données d'une autre école »
rencontre ici une particularité : le fonds documentaire est partagé par
construction. La réponse est une **visibilité explicite** portée par chaque
ressource :

| Visibilité | Portée | Contrainte |
| --- | --- | --- |
| `commun` | Tout l'écosystème | Contenu édité et validé, sans donnée d'école |
| `ecole` | Les comptes de `ecole_id` | `ecole_id` obligatoire |
| `prive` | L'auteur seul | `ecole_id` obligatoire |

La contrainte `ressources_ecole_obligatoire` interdit en base une ressource non
commune sans école. Le travail de classe — travaux dirigés, dépôts, favoris —
est cloisonné sans exception.

### 3.4 Le port et le préfixe d'API ne sont pas inventés
`PORT` n'a **aucune valeur par défaut** : le service refuse de démarrer sans
elle. Le numéro doit être attribué dans le plan de ports de l'écosystème.
Le préfixe est configurable, l'écosystème n'étant pas homogène
(`activity-service` expose `/api/v1`, `calendar-service` expose `/api`).

### 3.5 Le frontend Next.js reste à faire
Le serveur de rendu actuel est **transitoire**. Il consomme déjà l'API : le
remplacement de la couche de présentation par Next.js est désormais
indépendant du backend et peut se faire écran par écran.

---

## 4. Impact — ce qui a bougé

| Avant | Après |
| --- | --- |
| `server.js` | `frontend/server.js` + `services/diffusion-service/src/server.js` |
| `lib/store.js` | `repositories/` (service) + `frontend/services/api/` |
| `lib/pg/` | `services/diffusion-service/src/utils/pg/` |
| `lib/qr.js` | `services/diffusion-service/src/utils/qr.js` |
| `lib/router.js` | `frontend/services/routeur.js` |
| `views/pages/` | `frontend/app/` |
| `views/components/` | `frontend/components/` |
| `public/` | `frontend/public/` |
| `db/schema.sql` | `services/diffusion-service/migrations/001_schema_initial.sql` |
| — | `migrations/002_multi_tenant.sql` |
| `data/users.json` | `frontend/data/comptes-demo.json` |
| `tools/verify-*.js` | `services/diffusion-service/tests/` |

Aucun gabarit d'affichage n'a été réécrit : l'adaptateur
`frontend/services/api/diffusion.js` expose les mêmes signatures que l'ancienne
couche de données.

---

## 5. Contrat d'API

| Méthode | Route | Accès |
| --- | --- | --- |
| GET | `/api/v1/sante` | Ouvert |
| GET | `/api/v1/public/r/:id` | Ouvert — adresse courte imprimée |
| GET | `/api/v1/public/qr` · `/public/qr/:id` | Ouvert |
| GET | `/api/v1/public/documents/:cle` | Ouvert — liste de clés fermée |
| GET | `/api/v1/ressources` | Authentifié, école facultative |
| GET | `/api/v1/ressources/familles` · `/ressources/:id` | Authentifié |
| GET | `/api/v1/documents/:cle` | Authentifié |
| GET | `/api/v1/travaux-diriges` · `/:id` | Authentifié, école obligatoire |
| POST | `/api/v1/travaux-diriges` | Enseignant ou éditeur |

Réponses normalisées : `{ donnees, meta }` en succès,
`{ erreur: { code, message, details } }` en échec.

---

## 6. Tests

`npm test` dans le service — 48 contrôles :

- **Client PostgreSQL** (29) — SCRAM contre le vecteur de la RFC 7677, cadrage
  du protocole, conversion des types, aller-retour contre un serveur factice.
- **Encodeur QR** (12) — Reed-Solomon, information de format, relecture de la
  trame.
- **Cloisonnement et autorisation** (19) — détaillés ci-dessous.

| Contrôle | Attendu |
| --- | --- |
| Requête sans jeton | 401 |
| Jeton `alg: none` | 401 |
| Jeton signé avec un autre secret | 401 |
| Jeton expiré | 401 |
| `?school_id=` fourni par le client | 403, **aucune requête n'atteint la base** |
| Jeton sans école sur le travail de classe | 403 |
| Jeton sans école sur le fonds commun | 200 |
| Élève créant un travail dirigé | 403 |
| Données invalides | 422 avec détails par champ |
| Ressource scannée sans compte | 200 |
| SQL des travaux | `ecole_id = $1 AND annee_academique_id = $2` |
| École B | ne reçoit jamais `eco_A` |
| Injection dans un filtre | transmise en paramètre, absente du texte SQL |

---

## 7. Problèmes restants

1. **Contrat du gateway non vérifié.** Les revendications lues (`sub`, `role`,
   `school_id`, `academic_year_id`) viennent du contexte de développement, pas
   d'un jeton réel. À confronter avant intégration.
2. **Port à attribuer.** Le service ne démarre pas sans `PORT`.
3. **Transport d'événements non défini.** `events/publier.js` journalise et
   expose un point d'abonnement ; le bus réel n'est pas inventé.
4. **Frontend Next.js à écrire.** Le rendu actuel est transitoire.
5. **Cycles à peupler.** La colonne existe et est contrainte ; les données de
   démonstration sont toutes « secondaire ».
6. **Écritures limitées.** Seule la création de travail dirigé est exposée.
   Dépôt, modération et favoris suivent au développement de leurs modules.
7. **PostgreSQL réel non testé.** Les contrôles valident le protocole tel
   qu'implémenté, contre un serveur factice.
