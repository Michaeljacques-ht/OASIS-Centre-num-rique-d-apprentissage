# EDUCA DIFFUSION

**EDUCA TECHNOLOGIE**

## Document de conception de projet

*Plateforme de diffusion de contenus pédagogiques pour Haïti*

| Rubrique | Information |
| --- | --- |
| Nom du projet | EDUCA Diffusion — plateforme de diffusion de contenus pédagogiques |
| Version du document | 1.0 |
| Auteur | Michael Jacques — fondateur, EDUCA Technologie |
| Date | Juillet 2026 |
| Statut | En construction — ossature, système de design et sept écrans de référence livrés ; modules restants au planning |
| Écosystème | EDUCA Technologie (Port-au-Prince, Haïti) |


## 2. Historique des versions

| Version | Date | Auteur | Description des modifications |
| --- | --- | --- | --- |
| 0.1 | Juillet 2026 | M. Jacques | Ossature applicative, système de design, deux écrans de référence |
| 0.2 | Juillet 2026 | M. Jacques | Site public : accueil, en-tête, catégories, pied de page, accent vert |
| 0.3 | Juillet 2026 | M. Jacques | Tableau de bord enseignant, encodeur QR interne, partage de ressource |
| 0.4 | Juillet 2026 | M. Jacques | Catalogue des ressources pédagogiques — espace enseignant |
| 0.5 | Juillet 2026 | M. Jacques | Catalogue des ressources pédagogiques — espace élève, parcours |
| 0.6 | Juillet 2026 | M. Jacques | Ressources méthodologiques dans les deux espaces |
| 1.0 | Juillet 2026 | M. Jacques | Périmètre complet, exigences, architecture, planning, documentation |


## 3. Table des matières

*(table des matières générée automatiquement dans la version Word)*


## 4. Introduction


### 4.1 Présentation du projet

EDUCA Diffusion est la plateforme de diffusion de contenus pédagogiques d'EDUCA Technologie. Elle réunit en un même lieu la production éditoriale de la maison d'édition et les usages de classe : un site public où l'on découvre et acquiert les contenus, un espace enseignant où l'on prépare, évalue et partage, un espace élève où l'on apprend, s'exerce et progresse. Chaque contenu imprimé porte un QR code qui ouvre sa version numérique enrichie.


### 4.2 Contexte

L'école haïtienne travaille avec des manuels rares, coûteux et rarement accompagnés de ressources d'appui. Les enseignants préparent leurs cours sans banque de documents partagée ; les élèves révisent sans support méthodologique. Dans le même temps, le téléphone mobile est largement diffusé et la lecture d'un QR code est devenue un geste courant. Le manuel imprimé reste le support de référence en classe, mais il peut désormais servir de porte d'entrée vers des vidéos, des exercices interactifs et des laboratoires virtuels.

EDUCA Diffusion s'inscrit dans l'écosystème EDUCA Technologie, aux côtés d'EDUCA Librairie, de la Bibliothèque Numérique, d'EDUCA Formation et de Randevou.ht, avec lesquels elle partage identité visuelle, socle technique et passerelle de paiement.


### 4.3 Problématique

Comment donner à un enseignant haïtien une bibliothèque de ressources exploitables sans connexion permanente, à un élève un accompagnement méthodologique qui ne dépende pas d'un adulte disponible, et à un éditeur local un canal de diffusion qui relie l'imprimé au numérique — dans un environnement de connectivité intermittente et de faible bancarisation ?


### 4.4 Vision globale

Faire d'EDUCA Diffusion la bibliothèque de référence de l'école haïtienne : un fonds de ressources vérifiées, alimenté par la maison d'édition et par les enseignants eux-mêmes, accessible depuis un manuel imprimé comme depuis un navigateur, et suffisamment léger pour fonctionner sur les connexions dont dispose réellement le pays.


## 5. Objectifs du projet


### 5.1 Objectif général

Concevoir et déployer une plateforme de diffusion de contenus pédagogiques reliant l'édition imprimée aux ressources numériques, utilisable en basse connectivité, et servant trois publics distincts : le grand public, les enseignants et les élèves.


### 5.2 Objectifs spécifiques

- OS1 — constituer un fonds structuré de ressources : pédagogiques, méthodologiques, multimédias et cartographiques, classées par discipline, niveau, type et format.
- OS2 — relier chaque contenu imprimé à sa version numérique par un QR code unique, produit par la plateforme elle-même.
- OS3 — outiller la préparation de classe : banque de questions, quiz, travaux dirigés et pratiques, exposés, dissertations, examens.
- OS4 — accompagner l'élève dans sa méthode de travail : thèmes, parcours, progression mesurée, favoris.
- OS5 — ouvrir la contribution aux enseignants, sous modération éditoriale avant publication.
- OS6 — proposer un laboratoire numérique : simulations et expériences guidées, exécutées dans le navigateur.
- OS7 — fonctionner sur une infrastructure légère, sans dépendance externe, à coût d'exploitation minimal.


## 6. Justification du projet


### 6.1 Pourquoi ce projet ?

Aucune offre existante ne réunit un fonds contextualisé au programme haïtien, une passerelle entre l'imprimé et le numérique, une contribution enseignante modérée et une tolérance réelle aux connexions lentes. Les plateformes internationales proposent des contenus hors programme, dans des langues et à des tarifs inadaptés. EDUCA Diffusion comble ce vide en s'appuyant sur un socle technique déjà éprouvé dans l'écosystème.


### 6.2 Problèmes résolus

| Problème constaté | Réponse apportée |
| --- | --- |
| Manuels sans ressources d'accompagnement | QR code sur chaque contenu imprimé, ouvrant la ressource numérique |
| Enseignants sans banque de documents | Catalogue filtrable par discipline, niveau, type et format |
| Préparation de classe artisanale | Modules TD, TP, exposés, dissertations, examens et banque de questions |
| Élèves sans méthode de travail | Espace méthodologique par thème, avec parcours et progression |
| Ressources de qualité inégale | Dépôt enseignant soumis à vérification avant publication |
| Connexions lentes et coupures | Pages rendues côté serveur, sans framework, moins de 100 Ko hors médias |
| Expériences scientifiques impossibles faute de matériel | Laboratoire numérique : simulations et expériences guidées |


### 6.3 Bénéfices attendus

- Pour les enseignants — une bibliothèque prête à l'emploi et un outil de préparation, sans installation ni abonnement logiciel.
- Pour les élèves — des ressources à leur niveau, une méthode de travail explicite, un suivi de leur progression.
- Pour la maison d'édition — un canal de diffusion qui prolonge l'imprimé et en mesure l'usage réel.
- Pour les établissements — un fonds commun accessible à toutes les classes, sans licence par poste.
- Pour le pays — la valorisation d'une production pédagogique nationale, conforme au programme.


## 7. Périmètre du projet


### 7.1 Fonctionnalités incluses

- Site public — accueil, catégories de contenus, familles de ressources, outils d'apprentissage, lecture de QR code, panier et compte.
- Espace enseignant — tableau de bord, ressources pédagogiques et méthodologiques, ressources multimédias, cartes géographiques, banque de questions, quiz, travaux dirigés et pratiques, exposés, dissertations, examens, outils éducatifs, logiciels par discipline, laboratoire numérique, tuteur intelligent, partage, forum, groupes.
- Espace élève — tableau de bord, ressources par thème et par discipline, parcours d'apprentissage, cours et activités, vidéos, exercices interactifs, cartes et atlas, laboratoires virtuels, quiz, devoirs, examens blancs, corrections, forum d'entraide, groupes d'étude.
- Contribution — dépôt d'une ressource par un enseignant, soumission à vérification, publication après contrôle éditorial.
- Diffusion — QR code et lien unique par ressource, partage vers les réseaux, téléchargement du QR pour insertion dans un document imprimé.
- Administration — vérification des dépôts, gestion du fonds, paramétrage des familles et catégories, journal d'audit.


### 7.2 Fonctionnalités exclues de la version 1.0

- classes virtuelles en direct et visioconférence intégrée.
- application mobile native — la plateforme est responsive dès 360 px de large.
- notifications automatiques par courriel, SMS ou WhatsApp.
- correction automatique des productions écrites par intelligence artificielle.
- mode hors ligne complet (installation en application web progressive).
- API publique ouverte aux partenaires et aux éditeurs tiers.

> Ces exclusions sont des choix de séquencement, non des renoncements : elles figurent au planning des versions ultérieures (section 29).


## 8. Parties prenantes

| Partie prenante | Rôle dans le projet | Attentes principales |
| --- | --- | --- |
| Client / porteur | EDUCA Technologie — financement et orientation | Plateforme opérationnelle, alignée sur l'écosystème |
| Enseignants | Utilisateurs principaux et contributeurs | Ressources conformes au programme, dépôt simple, gain de temps |
| Élèves | Utilisateurs finaux | Contenus à leur niveau, méthode de travail, accès depuis un téléphone |
| Maison d’édition | Producteur des contenus de référence | Prolongement numérique de l’imprimé, mesure des usages |
| Établissements scolaires | Clients institutionnels | Fonds commun, comptes par classe, suivi |
| Administrateurs | Garants de la qualité éditoriale | Outils de vérification efficaces, traçabilité |
| Développeur | Conception et réalisation | Architecture simple à maintenir, code documenté en français |
| Testeurs | Validation fonctionnelle | Jeu de données de démonstration, aperçus autonomes |


## 9. Acteurs du système

| Acteur | Périmètre d'action |
| --- | --- |
| Visiteur | Consulte le site public, le catalogue et les catégories ; scanne un QR code ; crée un compte |
| Élève | Consulte les ressources de son niveau, suit des parcours, s’exerce, met en favori, participe au forum d’entraide |
| Enseignant | Consulte et dépose des ressources, prépare TD, TP, examens et quiz, anime le laboratoire, partage avec ses classes |
| Établissement | Crée les comptes de ses enseignants et de ses classes, consulte les usages |
| Éditeur | Publie les contenus de la maison d’édition, associe QR codes et manuels imprimés |
| Administrateur | Vérifie les dépôts, gère le fonds et les familles, consulte le journal d’audit |
| Passerelle PLOP PLOP | Acteur externe : encaisse les paiements des contenus payants |


## 10. Exigences fonctionnelles

| Réf. | Exigence | Acteur |
| --- | --- | --- |
| EF-01 | Parcourir le site public : accueil, catégories, familles de ressources | Visiteur |
| EF-02 | Rechercher un contenu par mot-clé depuis toute page | Tous |
| EF-03 | Ouvrir une ressource en scannant le QR code d’un contenu imprimé | Visiteur |
| EF-04 | Créer un compte et se connecter ; session persistante sécurisée | Tous |
| EF-05 | Accéder à un espace distinct selon le rôle (enseignant ou élève) | Enseignant, Élève |
| EF-06 | Filtrer le catalogue par discipline, niveau, type de ressource et format | Enseignant, Élève |
| EF-07 | Basculer l’affichage entre grille et liste, sans perdre les filtres | Enseignant, Élève |
| EF-08 | Consulter une fiche de ressource : aperçu, auteur, niveau, format, avis | Enseignant, Élève |
| EF-09 | Télécharger une ressource dans son format d’origine | Enseignant, Élève |
| EF-10 | Enregistrer une ressource en favori et retrouver ses favoris | Enseignant, Élève |
| EF-11 | Obtenir le lien et le QR code d’une ressource, et les partager | Enseignant |
| EF-12 | Télécharger le QR code d’une ressource pour l’insérer dans un document | Enseignant, Éditeur |
| EF-13 | Consulter le tableau de bord : volumes du fonds, ressources récentes, disciplines | Enseignant |
| EF-14 | Déposer une ressource (fichier ou lien) avec ses métadonnées | Enseignant |
| EF-15 | Soumettre un dépôt à vérification éditoriale | Enseignant |
| EF-16 | Créer un travail dirigé : objectifs, consignes, exercices, pièces jointes, barème | Enseignant |
| EF-17 | Créer un travail pratique, un exposé, une dissertation ou un examen | Enseignant |
| EF-18 | Alimenter et réutiliser une banque de questions | Enseignant |
| EF-19 | Composer un quiz à partir de la banque de questions | Enseignant |
| EF-20 | Créer un laboratoire numérique en cinq étapes, avec aperçu en direct | Enseignant |
| EF-21 | Partager une ressource ou une collection avec une ou plusieurs classes | Enseignant |
| EF-22 | Consulter les statistiques d’usage d’une ressource : vues, scans, téléchargements | Enseignant, Éditeur |
| EF-23 | Suivre un parcours d’apprentissage et voir sa progression | Élève |
| EF-24 | Consulter les méthodes de travail par thème et par durée | Élève |
| EF-25 | Reprendre une ressource là où elle avait été interrompue | Élève |
| EF-26 | Poser une question au forum d’entraide ou à son enseignant | Élève |
| EF-27 | Rejoindre un groupe d’étude ou un groupe de classe | Élève, Enseignant |
| EF-28 | Publier un sujet et répondre dans le forum | Enseignant, Élève |
| EF-29 | Vérifier un dépôt : approuver, ou renvoyer avec un commentaire | Administrateur |
| EF-30 | Gérer les familles, catégories, disciplines et niveaux du fonds | Administrateur |
| EF-31 | Associer un manuel imprimé à ses ressources numériques | Éditeur |
| EF-32 | Consulter le journal d’audit des actions sensibles | Administrateur |


## 11. Exigences non fonctionnelles

| Domaine | Exigence retenue |
| --- | --- |
| Performance | Page rendue côté serveur en moins de 100 ms ; poids inférieur à 150 Ko hors médias ; illustrations vectorielles compressibles |
| Sécurité | Échappement systématique de toute donnée affichée ; en-tête nosniff ; aucune traversée de chemin sur les fichiers statiques ; mots de passe en scrypt salé et cookies signés à l’ouverture des comptes |
| Disponibilité | Objectif 99 % sur le mois ; aucune dépendance externe bloquante ; le catalogue reste consultable même passerelle de paiement indisponible |
| Scalabilité | Architecture prête pour PostgreSQL ; seuil de bascule estimé à 5 000 ressources ou 20 000 comptes actifs |
| Accessibilité | Contrastes conformes WCAG 2.1 AA, navigation au clavier, focus visible, animations désactivables (prefers-reduced-motion), libellés d’images explicites |
| Compatibilité | Navigateurs récents sur ordinateur et mobile ; interface responsive dès 360 px ; barre latérale escamotable sous 960 px |
| Sobriété réseau | Aucun framework, aucune police distante, illustrations en SVG ; une page complète tient sous 150 Ko |
| Sauvegarde | Copie quotidienne des données et des téléversements hors serveur ; écriture atomique protégeant contre la corruption |
| Journalisation | Journal horodaté des actions sensibles, fenêtre glissante de 5 000 entrées, consultable par l’administration |
| Coût d’exploitation | Hébergement mensuel cible inférieur à 30 USD grâce à l’absence de dépendances lourdes |


## 12. Cas d’utilisation


### CU-01 — Trouver une ressource pour préparer un cours

| Rubrique | Contenu |
| --- | --- |
| Description | Un enseignant cherche un support pour sa prochaine séance |
| Acteurs | Enseignant |
| Préconditions | Compte enseignant actif ; fonds publié |
| Scénario | 1. L'enseignant ouvre le catalogue des ressources pédagogiques. 2. Il choisit une famille — fiche de préparation, présentation, guide. 3. Il restreint par discipline, niveau et format. 4. Il bascule en liste pour comparer. 5. Il ouvre la fiche, télécharge le document et l'ajoute à ses favoris. |
| Alternatives | 3a. Aucun résultat : l'écran vide propose d'élargir la recherche ou de déposer la première ressource de la catégorie. |
| Résultat attendu | Ressource téléchargée, filtres conservés dans l’adresse, favori enregistré |


### CU-02 — Ouvrir une ressource depuis un manuel imprimé

| Rubrique | Contenu |
| --- | --- |
| Description | Un élève scanne le QR code imprimé dans son manuel |
| Acteurs | Élève, Éditeur (producteur du manuel) |
| Préconditions | Ressource publiée ; QR code généré et imprimé |
| Scénario | 1. L'élève scanne le code avec l'appareil photo de son téléphone. 2. Le navigateur ouvre l'adresse courte de la ressource. 3. La plateforme enregistre le scan. 4. La ressource s'affiche, adaptée au petit écran. 5. L'élève la consulte ou la met en favori s'il est connecté. |
| Alternatives | 2a. Ressource dépubliée : page d'information proposant les ressources voisines du même chapitre. 5a. Visiteur non connecté : consultation possible, favori proposé après création de compte. |
| Résultat attendu | Ressource affichée sans compte requis ; scan comptabilisé pour l’éditeur |


### CU-03 — Déposer une ressource et la faire publier

| Rubrique | Contenu |
| --- | --- |
| Description | Un enseignant contribue au fonds commun ; l’administration contrôle |
| Acteurs | Enseignant, Administrateur |
| Préconditions | Compte enseignant actif |
| Scénario | 1. L'enseignant ouvre « Déposer une ressource ». 2. Il renseigne titre, discipline, niveau, type, format, mots-clés, puis joint un fichier ou un lien. 3. Il soumet à vérification : le dépôt quitte son brouillon et n'apparaît pas au catalogue. 4. L'administrateur prévisualise. 5. Il approuve — publication immédiate et QR code généré — ou renvoie avec un commentaire. 6. Le commentaire s'affiche à l'enseignant, qui corrige et resoumet. |
| Résultat attendu | Aucune ressource n’atteint le catalogue sans contrôle éditorial |


### CU-04 — Préparer et partager un travail dirigé

| Rubrique | Contenu |
| --- | --- |
| Description | Un enseignant conçoit un TD et le met à disposition de ses classes |
| Acteurs | Enseignant, Élèves |
| Préconditions | Compte enseignant actif ; au moins une classe rattachée |
| Scénario | 1. L'enseignant ouvre « Créer un travail dirigé ». 2. Il renseigne titre, discipline, niveau, durée et nombre d'exercices. 3. Il saisit objectifs et consignes, puis les exercices et les pièces jointes. 4. Il fixe le barème et la visibilité. 5. Il publie et partage avec ses classes. 6. Les élèves le retrouvent dans « Devoirs & TD ». |
| Alternatives | 5a. Enregistrement en brouillon : le TD reste privé et réapparaît dans « Mes TD ». |
| Résultat attendu | TD publié, partagé, visible côté élève, réutilisable par duplication |


## 13. Diagrammes UML

Les diagrammes sont présentés en notation textuelle, lisible sans outil externe et versionnable avec le code.


### 13.1 Diagramme de cas d'utilisation

```text
                    ┌──────────────────────────────────────────────┐
                    │            EDUCA DIFFUSION                   │
   ┌──────────┐     │                                              │
   │ Visiteur │────>│  Parcourir le catalogue · Scanner un QR      │
   └────┬─────┘     │  Créer un compte                             │   ┌────────────┐
        │           │                                              │   │ PLOP PLOP  │
   ┌────▼─────┐     │  Acheter un contenu ─────────────────────────────>│ (externe)  │
   │  Élève   │────>│  Suivre un parcours · S’exercer · Favoris     │   └────────────┘
   └──────────┘     │  Forum d’entraide · Groupes d’étude          │
   ┌──────────┐     │                                              │
   │Enseignant│────>│  Chercher · Déposer · Préparer TD, TP, examens│
   └──────────┘     │  Partager (lien et QR) · Laboratoire         │
   ┌──────────┐     │                                              │
   │ Éditeur  │────>│  Publier le fonds · Associer manuel et QR    │
   └──────────┘     │                                              │
   ┌──────────┐     │  Vérifier les dépôts · Gérer le fonds        │
   │  Admin   │────>│  Journal d’audit                             │
   └──────────┘     └──────────────────────────────────────────────┘
```


### 13.2 Diagramme de classes (simplifié)

```text
┌────────────────────┐        ┌─────────────────────┐       ┌──────────────┐
│    Utilisateur     │1     * │      Ressource      │1    * │   Fichier    │
├────────────────────┤────────├─────────────────────┤───────├──────────────┤
│ id, nom, email     │ dépose │ id, titre, resume   │       │ id, nom      │
│ role, pass(scrypt) │        │ famille, type       │       │ format, taille│
│ espace, niveau     │        │ discipline, niveau  │       │ url          │
│ favoris[]          │        │ statut, lien, qr    │       └──────────────┘
└─────────┬──────────┘        └──────────┬──────────┘
          │1                             │1
          │*                             │*
┌─────────▼──────────┐        ┌──────────▼──────────┐       ┌──────────────┐
│     Parcours       │        │       Usage         │       │    Manuel    │
├────────────────────┤        ├─────────────────────┤       ├──────────────┤
│ etapes[]           │        │ vues, scans         │       │ isbn, titre  │
│ progression        │        │ telechargements     │       │ ressources[] │
│ termineLe          │        │ periode             │       │ qrParPage[]  │
└────────────────────┘        └─────────────────────┘       └──────────────┘
```


### 13.3 Diagramme de séquence — ouverture par QR code

```text
Élève            Manuel imprimé      Plateforme            Base
  │                    │                  │                  │
  │  scanne le code    │                  │                  │
  ├───────────────────>│                  │                  │
  │  URL courte /r/:id │                  │                  │
  ├──────────────────────────────────────>│                  │
  │                    │   résoudre la ressource             │
  │                    │                  ├─────────────────>│
  │                    │                  │<── métadonnées ──┤
  │                    │   incrémenter le compteur de scans  │
  │                    │                  ├─────────────────>│
  │<── page ressource, rendue pour mobile ┤                  │
  │  met en favori (si connecté)          │                  │
  ├──────────────────────────────────────>├─────────────────>│
```


### 13.4 Diagramme d'états — cycle de vie d'une ressource

```text
            [dépôt]
               │
               ▼
        ┌──────────┐  soumettre   ┌──────────────────┐  approuver   ┌──────────┐
        │ brouillon├─────────────>│  en_verification ├─────────────>│ publiee  │
        └────▲─────┘              └────────┬─────────┘              └────┬─────┘
             │  renvoyer (commentaire)     │                             │
             └─────────────────────────────┘                             │ retirer
                                                                         ▼
                                                                  ┌──────────┐
                                                                  │ archivee │
                                                                  └──────────┘
        La publication déclenche la génération du lien court et du QR code.
```


### 13.5 Diagramme d'activités — dépôt d'une ressource

```text
   ● début
   │
   ▼ renseigner les métadonnées ──incomplet──> formulaire réaffiché, saisies conservées
   │ complet
   ▼ joindre un fichier ou un lien ──type refusé──> message explicite
   │ accepté
   ▼ enregistrer en brouillon
   │
   ▼ soumettre à vérification
   │
   ▼ contrôle éditorial ──renvoi──> commentaire à l’auteur ──> correction ──┐
   │ approbation                                                            │
   ▼ génération du lien court et du QR code <───────────────────────────────┘
   │
   ▼ publication au catalogue  ◉ fin
```


### 13.6 Diagramme de composants

```text
┌──────────────────── EDUCA DIFFUSION (processus Node.js) ─────────────────────┐
│  server.js ──> lib/router.js ──> views/pages/*.js (une fonction par écran)   │
│      │                                    │                                  │
│      │                                    ├──> views/layout.js (application) │
│      │                                    └──> views/site-layout.js (public) │
│      │                                              │                        │
│      │                                              └──> components/blocks.js│
│      ├──> lib/store.js   (persistance JSON, cache, requêtes)                 │
│      ├──> lib/html.js    (gabarits échappés par défaut)                      │
│      ├──> lib/icons.js   (67 icônes vectorielles internes)                   │
│      ├──> lib/qr.js      (encodeur QR : Reed-Solomon, masques, format BCH)   │
│      └──> lib/paiement.js ────────────> API PLOP PLOP (HTTPS externe)        │
└──────────────────────────────────────────────────────────────────────────────┘
```


### 13.7 Diagramme de déploiement

```text
┌────────────┐  HTTPS   ┌──────────────────────────┐  HTTPS   ┌───────────────┐
│ Navigateur │<────────>│  Hébergeur (Render/VPS)  │<────────>│   PLOP PLOP   │
│  ou mobile │          │   Node.js · port 3000    │          │  passerelle   │
└────────────┘          │  ┌────────────────────┐  │          └───────────────┘
      ▲                 │  │ Disque persistant  │  │
      │ scan QR         │  │ data/ · uploads/   │  │
┌─────┴──────┐          │  └────────────────────┘  │
│  Manuel    │          └──────────────────────────┘
│  imprimé   │
└────────────┘
```


## 14. Architecture du système


### 14.1 Architecture générale

EDUCA Diffusion repose sur un monolithe modulaire : un processus unique, découpé en modules aux responsabilités nettes — persistance, gabarits, icônes, QR, paiement, rendu. Le routeur reçoit la requête, détermine l'espace et le rôle, exécute la logique de la page, puis rend le HTML complet côté serveur. Aucun script de framework n'est envoyé au navigateur : le JavaScript client se limite à trois comportements (barre latérale escamotable, copie d'un lien, défilement horizontal).


### 14.2 Une adresse, deux espaces

Les modules communs aux deux publics — tableau de bord, ressources pédagogiques, ressources méthodologiques — sont servis par une seule adresse. Le fichier de page se termine par un choix explicite selon le rôle, et chaque espace obtient une mise en page distincte tout en partageant les composants et la feuille de style. Un lien transmis par un enseignant à ses élèves ouvre donc la version élève, sans redirection ni adresse parallèle à maintenir.


### 14.3 Position sur les microservices

Une architecture en microservices a été étudiée puis écartée pour la version 1.0. Le volume attendu ne justifie pas le coût d'exploitation d'un maillage de services, alors que l'hébergement local est contraint et l'équipe technique réduite. Le découpage interne constitue néanmoins la ligne de fracture d'une extraction future : le module de QR codes, le module de fichiers et le module de paiement sont déjà isolés derrière des interfaces stables.

> Ce choix est assumé : la simplicité opérationnelle prime tant que la charge ne l'exige pas. Le seuil de réexamen est fixé à 5 000 ressources publiées ou 20 000 comptes actifs.


### 14.4 Flux des données

```text
Requête ──> Routage ──> Rôle et espace (cookie) ──> Page (vue enseignant ou élève)
        ──> Lecture des collections JSON (cache mémoire) ──> Composition des blocs
        ──> Rendu HTML échappé ──> Réponse

QR      ──> lib/qr.js ──> encodage octet, Reed-Solomon, masque optimal
        ──> SVG servi par /qr.svg ──> affichage ou téléchargement

Dépôt   ──> contrôle du type et de la taille ──> data/uploads/
        ──> métadonnées en base ──> vérification éditoriale ──> publication
```


## 15. Architecture technique

| Élément | Choix retenu | Justification |
| --- | --- | --- |
| Serveur | Node.js 18+, module http natif | Aucune dépendance, démarrage instantané, faible empreinte mémoire |
| Hébergement | Render (service web) ou VPS Linux | Coût maîtrisé, disque persistant, déploiement par dépôt Git |
| Conteneurisation | Non requise en v1.0 | Le processus est autonome ; Docker sera introduit avec PostgreSQL |
| Orchestration | Sans objet en v1.0 | Kubernetes serait disproportionné pour un service unique |
| Reverse proxy | Assuré par l’hébergeur (TLS, HTTP/2) | Nginx prévu seulement en cas de VPS |
| Stockage | Disque persistant monté sur DATA_DIR | Données et téléversements doivent survivre aux redéploiements |
| Domaine | Sous-domaine d’educasoft.tech, TLS automatique | Cohérence avec l’écosystème EDUCA |
| Adresses courtes | Chemin /r/:id servi par le même processus | Un QR code doit rester court et stable dans le temps |


### 15.1 Environnements

| Environnement | Données | Passerelle | Usage |
| --- | --- | --- | --- |
| Développement | Collections JSON locales, relues à chaque requête | Simulateur local | Codage et essais quotidiens |
| Test | Jeu de démonstration | Clés de test | Recette fonctionnelle et aperçus autonomes |
| Production | Disque persistant, cache mémoire | Clés marchand réelles | Service aux utilisateurs |


## 16. Technologies utilisées

| Couche | Technologie | Remarque |
| --- | --- | --- |
| Frontend | HTML5 sémantique, CSS3 (variables, grid, flex), JavaScript natif | Aucun framework : chargement rapide en connexion lente |
| Système de design | Jetons CSS, 67 icônes vectorielles internes | Aucune police ni bibliothèque d’icônes distante |
| Backend | Node.js (modules http, fs, path, crypto natifs) | Zéro dépendance npm, aucune faille de chaîne d’approvisionnement |
| Gabarits | Moteur interne : littéraux étiquetés, échappement par défaut | 48 lignes ; raw() réservé aux fragments produits par les composants |
| QR codes | Encodeur interne : GF(256), Reed-Solomon, huit masques, BCH(15,5) | Niveau de correction M, versions 1 à 6, logo central toléré |
| Base de données | PostgreSQL via un client maison (lib/pg) | Protocole v3 complet, zéro dépendance npm ; repli JSON sans DATABASE_URL |
| Mobile | Interface responsive dès 360 px | Application native reportée en v2.0 |
| Cache | Collections en mémoire ; en-têtes HTTP sur les médias | Redis non nécessaire à ce volume |
| Paiement | API PLOP PLOP en HTTPS, signature HMAC-SHA256 | Mutualisée avec EDUCA Librairie et EDUCA Formation |
| CI/CD | Dépôt Git, déploiement automatique par branche | Aucune étape de compilation |
| Documentation | Markdown et Word générés par un script unique | Reproductible et versionnable avec le code |


## 17. Structure des modules

En l'absence de microservices, voici les modules internes et leurs responsabilités — futures frontières de service en cas d'extraction.

| Module | Responsabilité | Interface exposée |
| --- | --- | --- |
| lib/html.js | Gabarits sûrs : échappement automatique, composition de fragments | html, raw, when, each, number, compact |
| lib/icons.js | Jeu d’icônes vectorielles dessinées pour l’interface | icon(nom, options), names |
| lib/qr.js | Encodage QR complet et rendu SVG | encode, svg, remainder, generator |
| lib/store.js | Persistance JSON, cache, filtrage, écriture atomique | read, write, query, find, insert, slug |
| lib/router.js | Table des adresses, repli « module à construire » | resolve, modules |
| views/layout.js | Ossature de l’application : barre latérale, barre supérieure, rail | layout(vue) |
| views/site-layout.js | Ossature du site public : en-tête, pied de page | siteLayout(vue) |
| views/components/chrome.js | Marque, navigation, barre supérieure | brand, sidebar, topbar |
| views/components/blocks.js | Blocs de page réutilisables | hero, stats, filters, tabs, list, railCard, note, pager, empty |
| views/pages/*.js | Une fonction par écran, retournant titre, contenu et rail | page(contexte) |
| tools/*.js | Aperçus autonomes, visuels d’attente, contrôles du QR, documentation | exécutables en ligne de commande |


## 18. Modèle de données


### 18.1 Collections

| Collection | Clé | Champs principaux | Contraintes |
| --- | --- | --- | --- |
| utilisateurs | id (usr_) | nom, email, pass, role, espace, niveau, etablissement, favoris[] | email unique ; rôle parmi cinq valeurs |
| ressources | id (res_) | titre, resume, famille, type, format, discipline, niveau, auteurId, statut, lien, fichierId | auteur existant ; publication après vérification |
| fichiers | id (fic_) | nom d’origine, nom stocké, format, taille, empreinte | types et tailles contrôlés ; nom régénéré |
| manuels | id (man_) | isbn, titre, niveau, chapitres[], ressources[] | un QR par ressource associée |
| usages | — | ressourceId, vues, scans, telechargements, periode | agrégat quotidien, jamais transmis par le client |
| favoris | — | userId, ressourceId, ajouteLe | unicité du couple utilisateur/ressource |
| parcours | id (par_) | titre, theme, etapes[], niveau | au moins une étape |
| progressions | — | userId, parcoursId, etapesFaites[], pourcent | pourcent dérivé, jamais saisi |
| travaux | id (trv_) | type (TD, TP, exposé, dissertation, examen), titre, discipline, niveau, exercices[], bareme, statut | propriétaire unique ; partage par classe |
| questions | id (que_) | enonce, type, choix[], reponse, discipline, niveau, competence | réutilisable dans plusieurs quiz |
| laboratoires | id (lab_) | titre, discipline, type, scenario, ressources[], statut | assistant en cinq étapes |
| groupes | id (grp_) | nom, type (classe, collaboratif, personnel), membres[] | créateur membre de droit |
| sujetsForum | id (suj_) | categorie, userId, titre, resolu | catégorie existante |
| messagesForum | id (mfr_) | sujetId, userId, contenu | sujet parent existant |
| depots | id (dep_) | ressourceId, statut, commentaire, decidePar, decideLe | commentaire obligatoire en cas de renvoi |
| sessions | id | userId, createdAt | cookie signé, expiration |
| auditLog | — | at, userId, action, details | fenêtre glissante de 5 000 entrées |
| parametres | — | familles[], categories[], disciplines[], niveaux[], formats[] | valeurs par défaut si absentes |


### 18.2 Contraintes d'intégrité

- Références — un identifiant d'auteur, de ressource, de manuel ou de groupe référencé doit exister.
- Publication — une ressource n'atteint le catalogue que par la transition d'un dépôt approuvé ; elle ne peut être créée directement à l'état publié.
- Adresse courte et QR — dérivés de l'identifiant de la ressource à la publication, stables ensuite : un manuel déjà imprimé ne doit jamais pointer dans le vide.
- Compteurs d'usage — vues, scans et téléchargements sont incrémentés côté serveur uniquement.
- Favoris et progression — dérivés des actions de l'utilisateur, jamais saisis directement.
- Suppression — une ressource référencée par un manuel imprimé est archivée, jamais effacée.


## 19. Diagramme entité-relation

```text
┌──────────────┐            ┌──────────────┐            ┌──────────────┐
│ UTILISATEUR  │            │  RESSOURCE   │            │   FICHIER    │
├──────────────┤ 1        * ├──────────────┤ 1        1 ├──────────────┤
│ PK id        │────────────│ PK id        │────────────│ PK id        │
│ nom          │   dépose   │ FK auteur    │            │ nom, format  │
│ email      U │            │ titre        │            │ taille       │
│ pass         │            │ famille      │            └──────────────┘
│ role         │            │ discipline   │
│ espace       │            │ niveau       │            ┌──────────────┐
└──┬────────┬──┘            │ statut       │ *        1 │   MANUEL     │
   │1       │1              │ lienCourt  U │────────────├──────────────┤
   │*       │*              └───┬──────┬───┘            │ PK id        │
┌──▼──────┐ │                   │1     │1               │ isbn       U │
│ FAVORI  │ │              ┌────▼───┐  │                │ titre        │
├─────────┤ │              │ USAGE  │  │                └──────────────┘
│ FK user │ │              ├────────┤  │
│ FK ress │ │              │ vues   │  │                ┌──────────────┐
└─────────┘ │              │ scans  │  └───────────────>│    DÉPÔT     │
            │              │ téléch.│                   ├──────────────┤
┌───────────▼──┐           └────────┘                   │ PK id        │
│  PROGRESSION │                                        │ statut       │
├──────────────┤   ┌──────────┐ 1      * ┌──────────┐   │ commentaire  │
│ FK user      │   │ PARCOURS │──────────│  ÉTAPE   │   └──────────────┘
│ FK parcours  │   └──────────┘          └──────────┘
│ pourcent     │
└──────────────┘   ┌──────────┐ 1      * ┌──────────┐   ┌──────────────┐
                   │  SUJET   │──────────│ MESSAGE  │   │   TRAVAIL    │
                   └──────────┘          └──────────┘   │ TD/TP/examen │
                                                        └──────────────┘

U = unique      PK = clé primaire      FK = clé étrangère
```


## 20. Documentation des interfaces


### 20.1 Routes internes principales

| Méthode | Route | Rôle | Accès |
| --- | --- | --- | --- |
| GET | / | Site public : accueil | Public |
| GET | /categories/:slug | Contenus d’une catégorie | Public |
| GET | /r/:id | Adresse courte d’une ressource (cible des QR codes) | Public |
| GET | /qr.svg | QR code à la volée (taille, logo, téléchargement) | Public |
| GET | /tableau-de-bord | Tableau de bord de l’espace courant | Enseignant, Élève |
| GET | /ressources-pedagogiques | Catalogue, filtres, grille ou liste | Enseignant, Élève |
| GET | /ressources-methodologiques | Méthodes d’enseignement ou de travail | Enseignant, Élève |
| GET | /ressources-multimedias | Vidéos, audios, animations, podcasts | Enseignant, Élève |
| GET | /banque-de-questions | Banque de questions réutilisables | Enseignant |
| GET | /travaux-diriges | Liste des travaux dirigés | Enseignant |
| POST | /travaux-diriges | Création d’un travail dirigé | Enseignant |
| POST | /travaux-diriges/:id/partager | Partage avec une ou plusieurs classes | Propriétaire |
| GET | /laboratoires-virtuels | Catalogue des laboratoires numériques | Enseignant, Élève |
| POST | /laboratoires-virtuels | Création d’un laboratoire (assistant en cinq étapes) | Enseignant |
| POST | /partage-de-ressources/nouveau | Dépôt d’une ressource (fichier ou lien) | Enseignant |
| POST | /depots/:id/soumettre | Soumission à vérification éditoriale | Auteur |
| POST | /admin/depots/:id | Approbation ou renvoi commenté | Administrateur |
| POST | /mes-favoris/ajouter | Ajout aux favoris | Connecté |
| GET | /forum | Forum : catégories, sujets récents | Connecté |
| GET | /groupes | Groupes de classe, collaboratifs et personnels | Connecté |
| GET | /recherche | Recherche transversale | Public |


### 20.2 Interface interne — génération de QR codes

Le service /qr.svg encode n'importe quel texte en QR code et renvoie une image vectorielle. Il accepte quatre paramètres : texte (obligatoire), taille en pixels (80 à 1024), logo (insertion du logo EDUCA au centre) et telecharger (envoi en pièce jointe). L'encodage utilise le mode octet et le niveau de correction M, en versions 1 à 6, soit 106 octets utiles — largement suffisant pour une adresse courte.

| Paramètre | Valeurs | Effet |
| --- | --- | --- |
| texte | chaîne UTF-8, 106 octets maximum | Contenu encodé ; au-delà, réponse 413 |
| taille | 80 à 1024 (défaut 200) | Côté de l’image en pixels |
| logo | 1 ou absent | Réserve centrale de 18 % avec le logo EDUCA |
| telecharger | 1 ou absent | Envoi en pièce jointe plutôt qu’affichage |


### 20.3 Interface externe — PLOP PLOP

Les contenus payants réutilisent la passerelle déjà intégrée dans EDUCA Librairie et EDUCA Formation : ouverture de transaction, vérification serveur par sondage, finalisation idempotente. Le protocole, les signatures HMAC-SHA256 et les codes d'erreur sont ceux documentés pour l'écosystème ; aucune adaptation propre à EDUCA Diffusion n'est requise.


### 20.4 Erreurs renvoyées

| Code | Signification | Traitement dans la plateforme |
| --- | --- | --- |
| 400 | Paramètre manquant ou invalide | Message explicite nommant le champ en cause |
| 403 | Tentative de sortie du dossier public | Requête refusée, incident journalisé |
| 404 | Ressource ou page inexistante | Page « introuvable » avec retour au catalogue |
| 405 | Méthode non autorisée | En-tête Allow renvoyé |
| 413 | Contenu trop long pour un QR de version 6 | Message indiquant la limite de 106 octets |
| 500 | Exception non prévue | Réponse générique ; détail au journal serveur |


## 21. Sécurité


### 21.1 Authentification

- mots de passe hachés en scrypt avec sel unique par utilisateur, comparaison en temps constant.
- sessions matérialisées par un cookie HttpOnly signé, invalidé à la déconnexion.
- aucun mot de passe, aucune clé et aucun secret en clair dans le code ou les données.
- l'espace courant est déterminé côté serveur à partir de la session, jamais d'un paramètre fourni par le client.

> État à la version 1.0 : l'ossature bascule d'espace au moyen d'un cookie de démonstration, sans authentification. Le remplacement par des comptes et des sessions signées est la première tâche de la phase de mise en production (section 29).


### 21.2 Autorisation et permissions

| Ressource | Règle appliquée |
| --- | --- |
| Espace enseignant | Comptes de rôle enseignant, éditeur ou administrateur |
| Espace élève | Comptes de rôle élève, rattachés à un niveau |
| Modification d’une ressource | Auteur du dépôt uniquement, ou administrateur |
| Vérification d’un dépôt | Rôle administrateur exclusivement |
| Forum et groupes | Membres du groupe ou inscrits à la catégorie |
| Statistiques d’une ressource | Auteur et éditeur du contenu |
| Téléversement de fichiers | Enseignants et éditeurs, types et tailles contrôlés |


### 21.3 Audit

Chaque action sensible est journalisée avec horodatage, auteur et détails : décisions de vérification, publications et retraits de ressources, modifications de paramètres, suppressions, associations manuel-ressource, échecs d'accès répétés.


### 21.4 Protection des échanges et des contenus

- TLS de bout en bout, imposé par l'hébergeur, y compris vers la passerelle de paiement.
- échappement systématique de toute donnée affichée : le moteur de gabarits échappe par défaut, et seuls les fragments produits par les composants sont marqués comme sûrs.
- en-tête X-Content-Type-Options: nosniff sur toutes les réponses.
- aucune traversée de chemin possible sur les fichiers statiques : les chemins sont normalisés puis vérifiés comme appartenant au dossier public.
- noms de fichiers régénérés au téléversement ; types et tailles contrôlés avant écriture.
- aucune dépendance npm : la chaîne d'approvisionnement logicielle ne présente pas de surface d'attaque.


## 22. Interfaces utilisateur

Les écrans décrits ci-dessous sont livrés et fonctionnent sur le jeu de données de démonstration. Des aperçus autonomes, consultables sans serveur, sont fournis dans le dossier preview/.

| Écran | Espace | Ce qu’il montre |
| --- | --- | --- |
| Accueil du site public | Public | Bannière, outils d’apprentissage, familles de ressources, six catégories, chiffres clés, pied de page |
| Tableau de bord | Enseignant | Bandeau de recherche, six familles de contenus, ressources récentes, disciplines, ressource du jour, partage QR, statistiques |
| Tableau de bord | Élève | Journée en cours, travaux à rendre, raccourcis |
| Ressources pédagogiques | Enseignant | Familles, filtres croisés, grille ou liste, filtres avancés, ressources populaires |
| Ressources pédagogiques | Élève | Disciplines, recommandations, parcours d’apprentissage, nouveautés, favoris, progression |
| Ressources méthodologiques | Enseignant | Disciplines, approches pédagogiques, fiches de méthode, filtres avancés |
| Ressources méthodologiques | Élève | Thèmes de travail, durées, progression, outils pratiques, conseil du jour |
| Travaux dirigés | Enseignant | Compteurs par discipline, filtres, liste, statistiques, TD populaires |
| Système de design | Interne | Jetons, échelle typographique, composants, jeu d’icônes complet |


### 22.1 Deux ossatures distinctes

Le site public occupe toute la largeur : en-tête avec navigation, recherche, panier et comptes, puis pied de page complet. L'application adopte une barre latérale fixe, une barre supérieure et un rail droit d'informations secondaires. Un même champ dans la description d'une page suffit à basculer d'une ossature à l'autre.


### 22.2 Le patron de page dominant

Quatorze des vingt écrans maquettés reposent sur la même séquence : bannière ou en-tête clair, rangée de compteurs, barre de filtres, liste de résultats, rail droit. Ce patron est implémenté une fois, sous forme de blocs assemblables, et une page de module se résume à leur composition. C'est ce qui permet d'ajouter un module en un seul fichier.


### 22.3 Charte visuelle

- Bleu de marque pour l'action, orange du logo pour l'accent, vert réservé aux actions d'engagement du site public.
- Bannière sombre dans l'espace enseignant, bannière bleue dans l'espace élève, en-tête clair pour les catalogues.
- Sept tons pastel de discipline, appliqués aux vignettes, aux étiquettes et aux compteurs : une discipline garde la même couleur d'un écran à l'autre.
- Illustrations vectorielles produites pour la plateforme, sans banque d'images externe.


### 22.4 Principes d'interface

- Clarté — un seul objectif par écran, action principale visible sans défilement.
- Vocabulaire — les libellés décrivent l'effet réel : « Soumettre à vérification » et non « Publier ».
- États d'erreur — un échec explique ce qui s'est passé et propose une issue ; un écran vide invite à agir.
- Continuité — les filtres voyagent dans l'adresse : une recherche se partage par simple copie du lien.
- Accessibilité — contrastes conformes, navigation au clavier, focus visible, animations désactivables.


## 23. Gestion des erreurs

| Code HTTP | Situation | Réponse à l’utilisateur |
| --- | --- | --- |
| 200 | Succès | Page demandée |
| 302 | Redirection après action | Message de confirmation sur la page cible |
| 401 / 403 | Non authentifié ou accès refusé | Redirection vers la connexion ou l’accueil |
| 404 | Ressource inexistante | Page « introuvable » avec retour au catalogue |
| 405 | Méthode non autorisée | En-tête Allow et message court |
| 409 | Conflit (adresse courte ou email déjà utilisé) | Message précisant le champ en cause |
| 413 | Fichier ou contenu trop volumineux | Limite indiquée explicitement |
| 422 | Données invalides | Formulaire réaffiché, saisies conservées, motif indiqué |
| 500 | Exception non prévue | Réponse générique ; détail au journal serveur |
| 502 | Passerelle de paiement indisponible | Message d’attente ; le catalogue reste consultable |


### 23.1 Principes

- les erreurs ne s'excusent pas et ne restent jamais vagues : elles nomment le problème et la marche à suivre.
- aucune trace technique n'est exposée à l'utilisateur ; le détail part au journal serveur.
- toute exception non prévue est capturée : la plateforme répond, elle ne s'interrompt jamais.
- un écran vide n'est pas une erreur : il explique pourquoi il est vide et propose l'action suivante.
- une adresse courte imprimée ne renvoie jamais une page introuvable : une ressource retirée redirige vers son chapitre.


## 24. Performance

- Cache — collections, navigation et catalogues chargés en mémoire au démarrage en production ; relecture à chaque requête en développement.
- Poids — aucun script de framework, aucune police distante, feuilles de style découpées et chargées à la demande selon l'écran.
- Images — illustrations vectorielles générées à la bonne dimension ; vignettes chargées en différé (loading="lazy").
- Pagination — listes bornées et triées côté serveur pour limiter le volume rendu.
- Indexation — index en mémoire sur les identifiants au chargement ; index natifs lors du passage à PostgreSQL.
- Médias — vidéos servies par requêtes Range : lecture immédiate sans téléchargement complet.

| Indicateur | Cible | Mesure actuelle |
| --- | --- | --- |
| Temps de rendu serveur | < 100 ms | Conforme sur le jeu de démonstration |
| Poids d’une page hors médias | < 150 Ko | Conforme — 40 à 60 Ko de HTML, 35 Ko de CSS |
| Démarrage du service | < 1 s | Conforme |
| Empreinte mémoire | < 100 Mo | Conforme |
| Dépendances npm installées | 0 | Conforme |


## 25. Stratégie de tests

| Type de test | Portée | Méthode |
| --- | --- | --- |
| Unitaire | Échappement des gabarits, filtrage des collections, encodage QR | Scripts Node ciblés sur les fonctions pures |
| Intégration | Réponse de toutes les adresses, filtres croisés, bascule d’espace | Requêtes automatisées sur le serveur local |
| Fonctionnel | Parcours des cinq acteurs, du site public au dépôt publié | Scénarios de bout en bout sur le jeu de démonstration |
| Sécurité | Cloisonnement des espaces, traversée de chemin, injection HTML | Tentatives d’accès croisé et saisies hostiles |
| Performance | Temps de rendu, poids des pages | Mesures directes sous charge nominale |
| Rendu | Équilibre des balises, présence des blocs attendus | Contrôle automatique du HTML produit par chaque page |
| Accessibilité | Contrastes, ordre de tabulation, libellés | Revue manuelle assistée par le navigateur |


### 25.1 Cas de test critiques déjà validés

- Encodeur QR — les syndromes de Reed-Solomon d'un mot de code sont tous nuls, le reste BCH de l'information de format est nul, et la relecture module par module de la trame restitue exactement le texte encodé, accents compris.
- Échappement — une donnée contenant du HTML est rendue inerte à l'affichage.
- Structure — chaque page produit un HTML aux balises équilibrées.
- Adresses — les trente entrées de navigation répondent ; une adresse inconnue renvoie la page « introuvable ».
- Filtres — un filtre sans résultat produit un écran vide explicite, jamais une page blanche.
- Bascule d'espace — une même adresse sert la vue enseignante ou la vue élève selon le rôle, sans fuite de contenu d'un espace à l'autre.

> Le contrôle de l'encodeur QR valide l'algorithme, non la lecture optique : une vérification au téléphone reste requise avant l'impression d'un tirage.


## 26. Déploiement


### 26.1 Environnements et procédure

| Étape | Action |
| --- | --- |
| Développement | Exécution locale (node server.js) ; données relues à chaque requête ; aucune installation |
| Test | Déploiement sur une instance dédiée, jeu de démonstration, recette des scénarios critiques |
| Production | Service web, disque persistant monté sur DATA_DIR, domaine et TLS, cache mémoire activé |
| CI/CD | Poussée sur la branche principale : déploiement automatique, sans étape de compilation |
| Retour arrière | Redéploiement du commit précédent (moins de deux minutes) et restauration de la sauvegarde si les données ont évolué |


### 26.2 Liste de contrôle avant mise en production

- authentification et sessions signées en place ; cookie de démonstration retiré.
- DATA_DIR pointant vers le disque persistant ; données et téléversements préservés.
- BASE_URL renseignée et TLS actif sur le domaine ; adresses courtes /r/:id opérationnelles.
- NODE_ENV=production pour activer le cache mémoire et les en-têtes de cache.
- visuels d'attente remplacés par les illustrations définitives.
- sauvegarde automatique programmée et restauration testée au moins une fois.
- un QR code de production imprimé puis scanné avec deux téléphones différents.


## 27. Maintenance

| Type | Contenu | Rythme |
| --- | --- | --- |
| Corrective | Correction des anomalies signalées, priorisées par gravité | Continu ; incident bloquant sous 24 h |
| Éditoriale | Vérification des dépôts, actualisation du fonds, retrait des contenus obsolètes | Hebdomadaire |
| Préventive | Vérification des sauvegardes, de l’espace disque et des journaux | Hebdomadaire |
| Évolutive | Nouveaux modules issus de la feuille de route et des retours d’usage | Par versions trimestrielles |
| Sécurité | Mise à jour de Node.js, rotation des clés, revue du journal d’audit | Trimestrielle |


## 28. Gestion des risques

| Risque | Impact | Plan de mitigation |
| --- | --- | --- |
| QR codes imprimés pointant dans le vide | Critique — manuels inutilisables | Adresses courtes stables et immuables ; archivage au lieu de suppression ; redirection vers le chapitre |
| Fonds trop pauvre au lancement | Élevé — désaffection | Amorçage par la maison d’édition avant ouverture aux contributions |
| Contenus de qualité insuffisante | Élevé — réputation | Vérification éditoriale avant publication, commentaire de renvoi obligatoire |
| Corruption des données JSON | Critique — perte du fonds | Écriture atomique, sauvegardes quotidiennes hors serveur, restauration testée |
| Croissance dépassant le socle JSON | Moyen — lenteurs | Seuil de bascule défini ; migration PostgreSQL préparée |
| Coupures d’électricité et d’internet | Moyen — usage interrompu | Pages légères, aucun état perdu à la navigation, reprise immédiate |
| Droits sur les contenus déposés | Élevé — litige | Déclaration de paternité à chaque dépôt, contrôle éditorial, retrait sur signalement |
| Dépendance à un unique développeur | Élevé — continuité | Documentation complète, code commenté en français, absence de dépendances exotiques |


## 29. Planning du projet

| Phase | Livrables | Jalon |
| --- | --- | --- |
| 1. Cadrage | Périmètre, acteurs, exigences, vingt maquettes | Validé |
| 2. Ossature | Système de design, barre latérale, barre supérieure, rail, blocs de page | Validé |
| 3. Site public | Accueil, catégories, familles de ressources, pied de page | Validé |
| 4. Espace enseignant | Tableau de bord, ressources pédagogiques et méthodologiques, travaux dirigés | Validé |
| 5. Espace élève | Tableau de bord, ressources pédagogiques et méthodologiques, parcours | Validé |
| 6. Diffusion | Encodeur QR, adresses courtes, partage et statistiques d’usage | Validé |
| 7. Modules restants | Multimédias, cartes, banque de questions, quiz, TP, exposés, dissertations, examens, laboratoire, forum, groupes | À engager |
| 8. Comptes et contribution | Authentification, sessions, dépôt et vérification éditoriale | À engager |
| 9. Mise en production | Déploiement, domaine, sauvegardes, fonds réel, illustrations définitives | À planifier |
| 10. Lancement pilote | Trois établissements, cinquante enseignants, un manuel relié par QR | À planifier |
| 11. Version 2.0 | Mode hors ligne, application mobile, API partenaires, notifications | Trimestre suivant |


## 30. Budget indicatif

| Poste | Nature | Estimation mensuelle |
| --- | --- | --- |
| Hébergement | Service web et disque persistant | 20 à 30 USD |
| Nom de domaine et TLS | Sous-domaine d’educasoft.tech | Inclus |
| Stockage des médias | Vidéos et documents du fonds | 5 à 15 USD selon volume |
| Passerelle de paiement | Commission prélevée par PLOP PLOP | Proportionnelle au volume |
| Illustrations définitives | Production graphique, poste non récurrent | À budgéter au lancement |
| Ressources humaines | Développement et maintenance | Assurés en interne |
| Modération éditoriale | Vérification des dépôts | Assurée en interne |
| Sauvegardes | Stockage externe | Moins de 5 USD |
| Logiciels | Aucun — pile entièrement libre | 0 |

> Le coût d'exploitation reste volontairement minimal : l'absence de dépendances, de conteneurs et de services managés est un choix économique autant que technique.


## 31. Glossaire

| Terme | Définition |
| --- | --- |
| Adresse courte | Chemin bref et immuable d’une ressource, cible de son QR code imprimé |
| Bloc de page | Composant assemblable : bannière, compteurs, filtres, liste, carte de rail |
| Chantier | Écran dont l’ossature répond mais dont le module reste à construire |
| Espace | Vue complète destinée à un public : public, enseignant ou élève |
| Famille de ressources | Regroupement éditorial : fiche de préparation, présentation, guide, plan de leçon |
| Jeton de design | Variable CSS portant une décision visuelle réutilisable (couleur, espacement, rayon) |
| Niveau de correction M | Réglage QR tolérant environ 15 % de dégradation — compatible avec un logo central |
| Patron de page | Séquence bannière → compteurs → filtres → liste → rail, commune à la majorité des écrans |
| Rail droit | Colonne d’informations secondaires : actions rapides, populaires, conseils |
| Reed-Solomon | Code correcteur d’erreurs employé par les QR codes pour rester lisibles malgré une dégradation |
| Ressource méthodologique | Contenu portant sur la manière d’enseigner ou d’apprendre, non sur une matière |
| Écriture atomique | Enregistrement par fichier temporaire puis renommage, sans état intermédiaire |
| Vérification éditoriale | Contrôle d’un dépôt par l’administration avant publication au catalogue |


## 32. Références


### 32.1 Documents du projet

- README technique livré avec le code source (démarrage, arborescence, ajout d’un module).
- Aperçus autonomes des écrans livrés (dossier preview/).
- Inventaire du système de design, consultable à l’adresse /systeme.


### 32.2 Références externes

- Norme ISO/IEC 18004 — codes à barres bidimensionnels QR Code.
- Documentation officielle de Node.js (modules http, fs, crypto).
- Recommandations OWASP relatives à l’authentification et au stockage des mots de passe.
- Règles d’accessibilité WCAG 2.1, niveau AA, pour les contrastes et la navigation au clavier.
- Documentation de l’API PLOP PLOP — plopplop.solutionip.app/paiement-doc.


### 32.3 Écosystème EDUCA Technologie

- EDUCA Librairie — vente de livres, à l’origine de l’intégration PLOP PLOP.
- EDUCA Bibliothèque Numérique — référence de la charte visuelle.
- EDUCA Formation — plateforme de formation en ligne, modèle du présent document.
- Randevou.ht et Wout Konekte — autres plateformes de l’écosystème.


## 33. Annexes


### Annexe A — Comptes de démonstration

| Rôle | Nom affiché | Espace |
| --- | --- | --- |
| Enseignant | Jean Baptiste | Espace enseignant, toutes disciplines |
| Élève | Jonas Pierre | Espace élève, Secondaire 2 |

> Ces comptes sont des profils d'affichage : l'authentification n'est pas encore en place. Ils seront remplacés par de véritables comptes à la phase 8.


### Annexe B — Variables d'environnement

| Variable | Rôle |
| --- | --- |
| PORT | Port d’écoute (3000 par défaut) |
| NODE_ENV | production active le cache mémoire et les en-têtes de cache |
| BASE_URL | URL publique, utilisée pour composer les adresses courtes des QR codes |
| DATA_DIR | Dossier des données — disque persistant en production |
| PLOP_CLIENT_ID | Identifiant marchand (contenus payants) |
| PLOP_CLIENT_SECRET | Clé secrète marchand |


### Annexe C — Adresses de la plateforme

| Adresse | Écran |
| --- | --- |
| / | Site public — accueil |
| /tableau-de-bord | Tableau de bord de l’espace courant |
| /ressources-pedagogiques | Catalogue des ressources pédagogiques |
| /ressources-methodologiques | Méthodes d’enseignement ou de travail |
| /travaux-diriges | Travaux dirigés |
| /qr.svg?texte=… | Générateur de QR codes |
| /systeme | Système de design |


### Annexe D — Documents complémentaires

- Code source complet de la plateforme (archive educa-diffusion).
- Contrôles de l’encodeur QR (tools/verify-qr.js).
- Générateur des aperçus autonomes (tools/build-preview.js).
- Générateur du présent document (tools/doc-conception.js) — Markdown et Word depuis une source unique.
